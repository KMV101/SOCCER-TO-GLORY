import { useId, type ReactNode } from 'react';
import { audio } from '../game/audio';
import type { TeamDef } from '../game/config';

export const click = () => audio.play('click');

export function Btn({
  children, onClick, variant = 'default', disabled, className = '', style,
}: {
  children: ReactNode; onClick?: () => void; variant?: 'default' | 'primary' | 'danger'; disabled?: boolean; className?: string; style?: React.CSSProperties;
}) {
  return (
    <button
      className={`btn ${variant === 'primary' ? 'btn-primary' : variant === 'danger' ? 'btn-danger' : ''} ${className}`}
      disabled={disabled}
      style={style}
      onMouseEnter={() => !disabled && audio.play('hover')}
      onClick={() => {
        if (disabled) return;
        click();
        onClick?.();
      }}
    >
      {children}
    </button>
  );
}

export function Seg<T extends string | number>({
  value, options, onChange, label, disabledFn,
}: {
  value: T; options: { v: T; label: string }[]; onChange: (v: T) => void; label?: string; disabledFn?: (v: T) => boolean;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <span className="label">{label}</span>}
      <div className="seg">
        {options.map((o) => (
          <button
            key={String(o.v)}
            className={o.v === value ? 'on' : ''}
            disabled={disabledFn?.(o.v)}
            onClick={() => {
              click();
              onChange(o.v);
            }}
          >
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}

export function Toggle({ value, onChange, label, desc }: { value: boolean; onChange: (v: boolean) => void; label: string; desc?: string }) {
  return (
    <button
      className="setting-toggle flex w-full items-center justify-between gap-4 py-3 text-left transition"
      onClick={() => {
        click();
        onChange(!value);
      }}
    >
      <span>
        <span className="font-display block text-base">{label}</span>
        {desc && <span className="block text-sm text-slate-400">{desc}</span>}
      </span>
      <span className={`relative h-6 w-11 shrink-0 rounded-full transition ${value ? 'bg-cyan-400' : 'bg-white/20'}`}>
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${value ? 'left-[22px]' : 'left-0.5'}`} />
      </span>
    </button>
  );
}

export function Slider({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="label">{label}</span>
        <span className="font-display text-sm text-cyan-300">{Math.round(value * 100)}</span>
      </div>
      <input type="range" min={0} max={100} value={Math.round(value * 100)} onChange={(e) => onChange(Number(e.target.value) / 100)} onMouseUp={() => audio.play('tick', 0.4)} />
    </div>
  );
}

export function ScreenFrame({ title, subtitle, eyebrow = 'THE SETUP', onBack, children, right, wide }: { title: string; subtitle?: string; eyebrow?: string; onBack: () => void; children: ReactNode; right?: ReactNode; wide?: boolean }) {
  return (
    <div className="app-screen">
      <div className="screen-lines" aria-hidden="true" />
      <header className="screen-header">
        <div className="screen-topline">
          <button type="button" className="screen-back" onClick={() => { click(); onBack(); }}>
            <span aria-hidden="true">&larr;</span> BACK TO HOME
          </button>
          <span className="screen-edition">SIDENET / MATCHDAY EDITION</span>
        </div>
        <div className="screen-heading">
          <div className="min-w-0 flex-1">
            <div className="screen-overline">{eyebrow}</div>
            <h1>{title}<span>.</span></h1>
            {subtitle && <p>{subtitle}</p>}
          </div>
          {right && <div className="screen-heading-action">{right}</div>}
        </div>
      </header>
      <div className="screen-scroll scroll-thin">
        <div className={`screen-content ${wide ? 'screen-content-wide' : ''}`}>{children}</div>
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ colour helpers
function hexToRgb(hex: string): [number, number, number] {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function toHex(r: number, g: number, b: number) {
  return `#${[r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('')}`;
}
export function mix(a: string, b: string, t: number) {
  const A = hexToRgb(a);
  const B = hexToRgb(b);
  return toHex(A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t);
}
function lum(hex: string) {
  const [r, g, b] = hexToRgb(hex);
  return (r * 299 + g * 587 + b * 114) / 255000;
}
const contrast = (hex: string) => (lum(hex) > 0.55 ? '#10131a' : '#ffffff');

function star(cx: number, cy: number, R: number, r: number, n = 5) {
  let d = '';
  for (let i = 0; i < n * 2; i++) {
    const a = -Math.PI / 2 + (i * Math.PI) / n;
    const rad = i % 2 ? r : R;
    d += `${i ? 'L' : 'M'}${(cx + Math.cos(a) * rad).toFixed(2)} ${(cy + Math.sin(a) * rad).toFixed(2)} `;
  }
  return d + 'Z';
}
function poly(cx: number, cy: number, r: number, n = 5, rot = -Math.PI / 2) {
  return Array.from({ length: n }, (_, i) => `${(cx + Math.cos(rot + (i * 2 * Math.PI) / n) * r).toFixed(2)},${(cy + Math.sin(rot + (i * 2 * Math.PI) / n) * r).toFixed(2)}`).join(' ');
}

// ------------------------------------------------------------------ original team crests
const SHIELD = 'M32 2 C40 6 50 8 60 8 V40 C60 58 47 69 32 74 C17 69 4 58 4 40 V8 C14 8 24 6 32 2 Z';

function FlagArt({ flag, size, uid }: { flag: NonNullable<TeamDef['flag']>; size: number; uid: string }) {
  const [a, b, c] = flag.c;
  const W = 64;
  const H = 44;
  let art;
  switch (flag.kind) {
    case 'h3':
      art = (
        <>
          <rect width={W} height={H / 3 + 0.5} fill={a} />
          <rect y={H / 3} width={W} height={H / 3 + 0.5} fill={b} />
          <rect y={(H * 2) / 3} width={W} height={H / 3 + 0.5} fill={c} />
        </>
      );
      break;
    case 'v3':
      art = (
        <>
          <rect width={W / 3 + 0.5} height={H} fill={a} />
          <rect x={W / 3} width={W / 3 + 0.5} height={H} fill={b} />
          <rect x={(W * 2) / 3} width={W / 3 + 0.5} height={H} fill={c} />
        </>
      );
      break;
    case 'cross':
      art = (
        <>
          <rect width={W} height={H} fill={a} />
          <rect x={26} width={12} height={H} fill={b} />
          <rect y={16} width={W} height={12} fill={b} />
        </>
      );
      break;
    case 'disc':
      art = (
        <>
          <rect width={W} height={H} fill={a} />
          <circle cx={32} cy={22} r={11} fill={b} />
        </>
      );
      break;
    default:
      art = (
        <>
          <rect width={W} height={H} fill={a} />
          <polygon points="32,3 60,22 32,41 4,22" fill={b} />
          <circle cx={32} cy={22} r={9} fill={c ?? a} />
        </>
      );
  }
  return (
    <svg width={size * 1.25} height={(size * 1.25 * H) / W} viewBox={`0 0 ${W} ${H}`} className="shrink-0 drop-shadow-[0_3px_6px_rgba(0,0,0,0.5)]">
      <defs>
        <clipPath id={`fc${uid}`}>
          <rect width={W} height={H} rx="6" />
        </clipPath>
        <linearGradient id={`fg${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff" stopOpacity="0.35" />
          <stop offset="0.5" stopColor="#fff" stopOpacity="0" />
          <stop offset="1" stopColor="#000" stopOpacity="0.25" />
        </linearGradient>
      </defs>
      <g clipPath={`url(#fc${uid})`}>
        {art}
        <rect width={W} height={H} fill={`url(#fg${uid})`} />
      </g>
      <rect width={W} height={H} rx="6" fill="none" stroke="#fff" strokeOpacity="0.6" strokeWidth="2" />
    </svg>
  );
}

export function Crest({ team, size = 48 }: { team: Pick<TeamDef, 'primary' | 'secondary' | 'crest' | 'short' | 'flag'>; size?: number }) {
  const uid = useId().replace(/:/g, '');
  if (team.flag) return <FlagArt flag={team.flag} size={size} uid={uid} />;
  const p = team.primary;
  const s = team.secondary;
  // glyph colour: secondary if it contrasts with the shield, otherwise black/white
  const ink = Math.abs(lum(p) - lum(s)) > 0.3 ? s : contrast(p);
  const band = s;
  const bandInk = contrast(band);
  const g = team.crest % 8;
  return (
    <svg width={size} height={size * 1.19} viewBox="0 0 64 76" className="shrink-0 drop-shadow-[0_3px_6px_rgba(0,0,0,0.5)]">
      <defs>
        <linearGradient id={`g${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={mix(p, '#ffffff', 0.22)} />
          <stop offset="1" stopColor={mix(p, '#000000', 0.25)} />
        </linearGradient>
        <clipPath id={`c${uid}`}>
          <path d={SHIELD} />
        </clipPath>
      </defs>
      <path d={SHIELD} fill={`url(#g${uid})`} />
      <g clipPath={`url(#c${uid})`}>
        <rect x="0" y="0" width="64" height="23" fill={band} />
        <rect x="0" y="23" width="64" height="2.2" fill={mix(band, '#000000', 0.25)} opacity="0.8" />
        <path d="M4 8 H32 V44 C18 42 6 30 4 20Z" fill="#fff" opacity="0.09" />
      </g>
      <path d={SHIELD} fill="none" stroke={mix(s, '#000000', 0.15)} strokeWidth="3" strokeLinejoin="round" />
      <path d={SHIELD} fill="none" stroke="#fff" strokeOpacity="0.28" strokeWidth="0.8" transform="translate(3.2 4.4) scale(0.9)" />
      {size >= 40 && (
        <text x="32" y="18" textAnchor="middle" fontSize="11" fontWeight="800" fill={bandInk} style={{ fontFamily: 'Oswald, Impact, sans-serif', letterSpacing: '1px' }}>
          {team.short}
        </text>
      )}
      <g fill={ink} stroke={ink} strokeLinejoin="round" strokeLinecap="round">
        {g === 0 && <path d="M32 28 C30 36 22 40 8 38 C14 44 20 48 26 48 L28 58 L32 65 L36 58 L38 48 C44 48 50 44 56 38 C42 40 34 36 32 28 Z" strokeWidth="0.5" />}
        {g === 1 && (
          <>
            <path d="M13 55 L10 34 L21 43 L32 29 L43 43 L54 34 L51 55 Z" strokeWidth="0.5" />
            <rect x="13" y="57" width="38" height="4.5" rx="1" strokeWidth="0.5" />
            <circle cx="10" cy="32.5" r="2.4" />
            <circle cx="32" cy="27.5" r="2.4" />
            <circle cx="54" cy="32.5" r="2.4" />
          </>
        )}
        {g === 2 && (
          <>
            <path d={star(32, 46, 18, 7.5)} strokeWidth="0.6" />
            <circle cx="32" cy="46" r="3" fill={p} stroke="none" />
          </>
        )}
        {g === 3 && (
          <>
            <path d="M17 56 A15 15 0 0 1 47 56 Z" stroke="none" />
            {Array.from({ length: 7 }, (_, k) => {
              const a = Math.PI + ((k + 0.5) * Math.PI) / 7;
              return <line key={k} x1={32 + Math.cos(a) * 19} y1={56 + Math.sin(a) * 19} x2={32 + Math.cos(a) * 26} y2={56 + Math.sin(a) * 26} strokeWidth="3" fill="none" />;
            })}
            <rect x="11" y="59" width="42" height="3.5" rx="1" stroke="none" />
          </>
        )}
        {g === 4 && (
          <>
            <circle cx="32" cy="45" r="16" fill="none" strokeWidth="3" />
            <polygon points={poly(32, 45, 6.5)} stroke="none" />
            {Array.from({ length: 5 }, (_, k) => {
              const a = -Math.PI / 2 + (k * 2 * Math.PI) / 5;
              return <line key={k} x1={32 + Math.cos(a) * 6.5} y1={45 + Math.sin(a) * 6.5} x2={32 + Math.cos(a) * 15} y2={45 + Math.sin(a) * 15} strokeWidth="2" fill="none" />;
            })}
          </>
        )}
        {g === 5 && (
          <>
            <path d="M13 27 L25 38 H39 L51 27 V47 C51 57 42 63 32 68 C22 63 13 57 13 47 Z" strokeWidth="0.5" />
            <path d="M20 46 L29 49 L21 52 Z" fill={p} stroke="none" />
            <path d="M44 46 L35 49 L43 52 Z" fill={p} stroke="none" />
            <path d="M28.5 59 H35.5 L32 64 Z" fill={p} stroke="none" />
          </>
        )}
        {g === 6 && (
          <>
            <path d="M32 27 L37 36 L60 29 L52 41 L44 43 L40 53 L32 65 L24 53 L20 43 L12 41 L4 29 L27 36 Z" strokeWidth="0.5" />
            <circle cx="32" cy="31.5" r="3.6" />
            <path d="M32 33 L36 35 L32 38Z" fill={p} stroke="none" />
          </>
        )}
        {g === 7 && (
          <>
            {([[12, 49, 7, 13], [20, 41, 8, 21], [29, 32, 8, 30], [38, 42, 8, 20], [47, 50, 7, 12]] as number[][]).map(([x, y, w, h], i) => (
              <rect key={i} x={x} y={y} width={w} height={h} stroke="none" />
            ))}
            <path d={star(33, 26.5, 4.2, 1.8)} stroke="none" />
          </>
        )}
      </g>
    </svg>
  );
}

// ------------------------------------------------------------------ game logo
export function LogoMark({ size = 72 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className="shrink-0" role="img" aria-label="SideNet monogram">
      <rect x="1" y="1" width="62" height="62" rx="3" fill="#d5dd75" />
      <path d="M8 9h23v7H15v8h16v23H8v-7h16v-9H8V9Zm29 0h7l12 22V9h7v38h-7L44 25v22h-7V9Z" fill="#142018" />
      <path d="M8 54h47" stroke="#142018" strokeWidth="2" />
    </svg>
  );
}

export function Logo({ size = 1 }: { size?: number }) {
  return (
    <div className="flex items-center gap-3" style={{ transform: `scale(${size})`, transformOrigin: 'left center' }}>
      <LogoMark size={76} />
      <div className="leading-none">
        <div className="font-display title-shine text-4xl font-bold tracking-wide sm:text-5xl md:text-6xl">SIDENET</div>
        <div className="mt-1.5 flex items-center gap-3">
          <span className="h-[2px] flex-1 bg-gradient-to-r from-[var(--accent)] to-[var(--accent2)]" />
          <span className="font-display text-xs tracking-[0.2em] text-white/60 md:text-sm">AFTER DARK</span>
        </div>
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ player face portrait
export function Face({
  skin, hair, hairColor, primary = '#1d6fe0', secondary = '#ffffff', size = 64, round = true,
}: {
  skin: string; hair: number; hairColor: string; primary?: string; secondary?: string; size?: number; round?: boolean;
}) {
  const uid = useId().replace(/:/g, '');
  const sd = mix(skin, '#000000', 0.16);
  const hd = mix(hairColor, '#ffffff', 0.12);
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className="shrink-0" style={{ borderRadius: round ? '50%' : 10, background: 'radial-gradient(circle at 50% 30%, #2a3a63, #0d1426)' }}>
      <defs>
        <clipPath id={`f${uid}`}>
          <rect width="64" height="64" rx={round ? 32 : 10} />
        </clipPath>
      </defs>
      <g clipPath={`url(#f${uid})`}>
        {hair === 4 && <circle cx="32" cy="22" r="17" fill={hairColor} />}
        {hair === 2 && <path d="M15.5 28 C13 44 15 54 22 57 L42 57 C49 54 51 44 48.5 28 Z" fill={hairColor} />}
        <rect x="27" y="40" width="10" height="11" fill={sd} />
        <path d="M4 66 C6 51 19 46 32 46 C45 46 58 51 60 66 Z" fill={primary} />
        <path d="M25 46.5 L32 55 L39 46.5 Z" fill={secondary} opacity="0.95" />
        <path d="M27.5 46 L32 52 L36.5 46 Z" fill={sd} />
        <ellipse cx="18.8" cy="31" rx="2.6" ry="4.2" fill={sd} />
        <ellipse cx="45.2" cy="31" rx="2.6" ry="4.2" fill={sd} />
        <ellipse cx="32" cy="30" rx="13.2" ry="15.2" fill={skin} />
        <ellipse cx="32" cy="41" rx="9" ry="6" fill={mix(skin, '#000', 0.04)} />
        {hair === 0 && <path d="M18.5 28.5 C17 13 26 10 32 10 C38 10 47 13 45.5 28.5 C43 22 38 19.5 32 19.5 C26 19.5 21 22 18.5 28.5 Z" fill={hairColor} />}
        {hair === 1 && <path d="M19.5 27 C19 16 26 13 32 13 C38 13 45 16 44.5 27 C42 21.5 38 20.5 32 20.5 C26 20.5 22 21.5 19.5 27 Z" fill={hairColor} opacity="0.92" />}
        {hair === 2 && <path d="M18.5 29 C16.5 13 26 9.5 32 9.5 C38 9.5 47.5 13 45.5 29 C43 22 38 19 32 19 C26 19 21 22 18.5 29 Z" fill={hairColor} />}
        {hair === 3 && (
          <>
            <path d="M19.5 26 C19.5 18 26 15.5 32 15.5 C38 15.5 44.5 18 44.5 26 C42 21 38 20 32 20 C26 20 22 21 19.5 26 Z" fill={mix(hairColor, '#000', 0.45)} />
            <path d="M28 4 L36 4 L37.5 21 L26.5 21 Z" fill={hairColor} />
            <path d="M28 4 L32 4 L32 21 L26.5 21Z" fill={hd} opacity="0.35" />
          </>
        )}
        {hair === 4 && <path d="M18.5 27 C21 17 43 17 45.5 27 C42 22.5 38 21 32 21 C26 21 22 22.5 18.5 27 Z" fill={hairColor} />}
        <ellipse cx="26.6" cy="30.5" rx="3.1" ry="2.1" fill="#fbfbfb" />
        <ellipse cx="37.4" cy="30.5" rx="3.1" ry="2.1" fill="#fbfbfb" />
        <circle cx="26.9" cy="30.6" r="1.6" fill="#1b1410" />
        <circle cx="37.1" cy="30.6" r="1.6" fill="#1b1410" />
        <circle cx="27.4" cy="30" r="0.5" fill="#fff" />
        <circle cx="37.6" cy="30" r="0.5" fill="#fff" />
        <path d="M22.5 26.4 L29.5 25.4" stroke={hairColor} strokeWidth="1.7" strokeLinecap="round" />
        <path d="M34.5 25.4 L41.5 26.4" stroke={hairColor} strokeWidth="1.7" strokeLinecap="round" />
        <path d="M32 31 C31 34 30 36.5 30.5 37.6 C31.5 38.4 32.5 38.4 33.5 37.6 C34 36.5 33 34 32 31 Z" fill={sd} opacity="0.7" />
        <path d="M27.8 42.2 Q32 45.6 36.2 42.2" stroke="#8c3a3a" strokeWidth="1.7" fill="none" strokeLinecap="round" />
      </g>
    </svg>
  );
}

export function Bar({ value, color = 'var(--accent)', max = 100 }: { value: number; color?: string; max?: number }) {
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/10">
      <div className="h-full rounded-full transition-all" style={{ width: `${Math.max(0, Math.min(100, (value / max) * 100))}%`, background: color }} />
    </div>
  );
}

const ICONS: Record<string, string> = {
  play: 'M8 5v14l11-7z',
  bolt: 'M13 2 4 14h7l-1 8 9-12h-7z',
  trophy: 'M7 4h10v3a5 5 0 0 1-10 0zM5 5H3v2a4 4 0 0 0 4 4M19 5h2v2a4 4 0 0 1-4 4M12 12v4M8 21h8M10 16h4v5h-4z',
  target: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zm0 5a4 4 0 1 0 0 8 4 4 0 0 0 0-8z',
  train: 'M4 20V10l8-6 8 6v10M9 20v-6h6v6',
  shirt: 'M8 3 3 6l2 5 3-1v11h8V10l3 1 2-5-5-3a4 4 0 0 1-8 0z',
  gear: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2',
  coin: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7v10M9.5 9.5c0-1 1-1.5 2.5-1.5s2.5.7 2.5 1.8-1 1.5-2.5 1.7-2.5.7-2.5 1.8 1 1.7 2.5 1.7 2.5-.5 2.5-1.5',
  lock: 'M6 11h12v10H6zM8 11V7a4 4 0 0 1 8 0v4',
  video: 'M3 6h12v12H3zM15 10l6-3v10l-6-3z',
  globe: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c3.4 3.2 3.4 14.8 0 18M12 3c-3.4 3.2-3.4 14.8 0 18',
  street: 'M3 21V9l9-6 9 6v12M9 21v-7h6v7M3 9h18M6 13h.01M18 13h.01',
  league: 'M4 20h16M6 20v-9M12 20V4M18 20v-6',
  wall: 'M3 6h18v12H3zM3 12h18M9 6v6M15 12v6M12 6v0',
};
export function Icon({ name, size = 22 }: { name: keyof typeof ICONS | string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d={ICONS[name] ?? ICONS.play} />
    </svg>
  );
}

export const CONTROLS: [string, string][] = [
  ['WASD / Arrows', 'Move'],
  ['SHIFT', 'Sprint (uses stamina)'],
  ['Hold Left Mouse', 'Strike. Release in the highlighted band for clean contact'],
  ['V + Shoot', 'Heavy strike with a planted windup'],
  ['F + Shoot', 'Bending strike with curl'],
  ['R + Shoot', 'Chip over the keeper'],
  ['X + Shoot', 'Low driven strike'],
  ['Q while charging', 'Cancel into a body feint'],
  ['Hold Q', 'Pass. Hold for more weight'],
  ['Right Mouse', 'Through ball'],
  ['E', 'Standing tackle'],
  ['SHIFT + E', 'Sliding tackle with longer recovery'],
  ['SPACE', 'Switch player'],
  ['R + Q', 'Lofted pass'],
  ['C', 'Skill move past a marker'],
  ['Q / E', 'Curve the ball in free kicks'],
  ['1 - 5', 'Change team tactic'],
  ['B', 'Reset the ball in training'],
  ['ESC / P', 'Pause the match'],
  ['ON SCREEN', 'Pointer controls work with mouse and touch alongside the keyboard'],
  ['GAMEPAD', 'Left stick move, A pass, B strike, X tackle, Y through, LB switch, RB sprint'],
];

export function ControlsTable() {
  return (
    <div className="controls-table">
      {CONTROLS.map(([k, d]) => (
        <div key={k} className="controls-row">
          <kbd>{k}</kbd>
          <span>{d}</span>
        </div>
      ))}
    </div>
  );
}
