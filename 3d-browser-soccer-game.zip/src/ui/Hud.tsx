import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { SKIN_TONES, TACTICS, TACTIC_LIST, ALL_TEAMS as TEAMS, type Tactic } from '../game/config';
import type { Engine, EngineHud } from '../game/engine';
import type { MatchResult } from '../game/match';
import type { Rewards } from '../game/progress';
import { updateSave, useSave } from '../game/save';
import { Btn, ControlsTable, Crest, Face, Seg, Icon } from './common';

// ------------------------------------------------------------------ in-game HUD
export function Hud({ hud, engine, fps, showFps }: { hud: EngineHud; engine: Engine; fps: number; showFps: boolean }) {
  const mapRef = useRef<HTMLCanvasElement>(null);
  const intro = hud.mode === 'match' && hud.phase === 'KICKOFF' && hud.clock === '00:00' && hud.homeScore + hud.awayScore === 0;
  useEffect(() => {
    engine.attachMinimap(mapRef.current);
    return () => engine.attachMinimap(null);
  }, [engine, hud.mode, intro]);

  const stamColor = hud.stamina > 55 ? '#4ade80' : hud.stamina > 25 ? '#facc15' : '#f87171';
  const isPen = hud.mode === 'penalty' || hud.mode === 'freekick';
  const homeTeam = TEAMS.find((t) => t.name === hud.homeName);
  const awayTeam = TEAMS.find((t) => t.name === hud.awayName);

  return (
    <div className="pointer-events-none absolute inset-0 select-none">
      {hud.phase === 'GOAL' && <div className="goal-flash absolute inset-0" />}
      <div className="hud-score" aria-label={`${hud.homeName} ${hud.homeScore}, ${hud.awayName} ${hud.awayScore}; ${hud.clock || hud.half}`}>
        <div className="hud-clock"><small>{hud.mode === 'match' ? hud.half : hud.mode === 'penalty' ? 'SHOOTOUT' : hud.mode === 'freekick' ? 'FREE KICKS' : 'TRAINING'}</small><strong>{hud.clock || 'PENS'}</strong></div>
        <div className="hud-teams">
          <div className="hud-team"><i style={{ background: hud.homeColor }} />{homeTeam && <Crest team={homeTeam} size={20} />}<span>{hud.homeShort}</span><strong key={`h-${hud.homeScore}`} className="score-pop">{hud.homeScore}</strong></div>
          <div className="hud-team"><i style={{ background: hud.awayColor }} />{awayTeam && <Crest team={awayTeam} size={20} />}<span>{hud.awayShort}</span><strong key={`a-${hud.awayScore}`} className="score-pop">{hud.awayScore}</strong></div>
        </div>
      </div>

      {showFps && <div className="hud-fps">{fps} FPS</div>}

      {hud.mode === 'match' && (hud.shotInfoT ?? 0) > 0 && hud.phase === 'PLAY' && (
        <div className="hud-shot-readout">
          <div className="hud-shot-name">
            {hud.lastShotType === 'power' ? 'Heavy strike' : hud.lastShotType === 'finesse' ? 'Bending strike' : hud.lastShotType === 'chip' ? 'Chip' : hud.lastShotType === 'low' ? 'Driven low' : hud.lastShotType === 'header' ? 'Header' : 'Strike'}
          </div>
          <div>{hud.lastShotSpeedKmh} <span>KM/H</span></div>
        </div>
      )}

      {/* banner */}
      {hud.banner && !intro && (
        <div className={`hud-banner hud-banner-${hud.banner.kind}`} key={hud.banner.text + hud.banner.kind}>
          {hud.banner.kind === 'goal' ? (
            <div className="hud-goal-content">
              <small>THE BALL IS IN THE NET</small>
              <div className="hud-goal-word">GOAL<span>.</span></div>
              {hud.banner.sub && <p>{hud.banner.sub}</p>}
            </div>
          ) : hud.banner.kind === 'final' ? (
            <div className="hud-goal-content">
              <small>THE WHISTLE GOES</small>
              <div className="hud-goal-word">FULL TIME<span>.</span></div>
              <p>{hud.banner.sub}</p>
            </div>
          ) : (
            <div className="hud-event-content">
              <strong>{hud.banner.text}</strong>
              {hud.banner.sub && <span>{hud.banner.sub}</span>}
            </div>
          )}
        </div>
      )}

      {intro && homeTeam && awayTeam && (
        <div className="hud-intro">
          <div className="hud-intro-inner">
            <div className="hud-intro-team">
              <Crest team={homeTeam} size={57} />
              <div>{homeTeam.name}</div>
            </div>
            <div className="hud-intro-v">V</div>
            <div className="hud-intro-team">
              <Crest team={awayTeam} size={57} />
              <div>{awayTeam.name}</div>
            </div>
          </div>
        </div>
      )}
      {hud.phase === 'KICKOFF' && hud.mode === 'match' && !hud.banner && !intro && <div className="hud-event-content hud-get-ready">KICK OFF</div>}

      {hud.phase === 'HALFTIME' && (
        <div className="pointer-events-auto absolute inset-x-0 bottom-[22%] flex justify-center">
          <Btn variant="primary" className="!px-10 !py-3 !text-xl" onClick={() => engine.continueHalftime()}>Start second half ▶</Btn>
        </div>
      )}

      {/* bottom-left player card */}
      {!isPen && !intro && (
        <div className="hud-player" style={{ '--player-color': hud.homeColor } as CSSProperties}>
            <div className="hud-player-face">
              {hud.face ? (
                <Face skin={SKIN_TONES[hud.face.skin % 6]} hair={hud.face.hair} hairColor={hud.face.hairColor} primary={hud.homeColor} size={47} />
              ) : (
                <div className="h-[47px] w-[47px] bg-white/10" />
              )}
              <span className="hud-player-number">{hud.playerNumber}</span>
            </div>
            <div className="hud-player-detail">
              <div className="hud-player-name">{hud.playerName}</div>
              <div className="hud-player-position">{hud.playerPos}{hud.mode === 'match' ? ` / ${TACTICS[hud.tactic].label}` : ''}</div>
              <div className="hud-stamina">
                <span style={{ width: `${hud.stamina}%`, background: stamColor }} />
              </div>
            </div>
        </div>
      )}

      {/* charge bars */}
      {(hud.shootCharge > 0 || hud.passCharge > 0 || hud.timedState) && !isPen && (
        <div className="hud-charge space-y-2">
          {hud.shootCharge > 0 && <ChargeBar label={hud.shotStyle === 'power' ? 'HEAVY STRIKE' : hud.shotStyle === 'finesse' ? 'BENDING STRIKE' : hud.shotStyle === 'chip' ? 'CHIP' : hud.shotStyle === 'low' ? 'LOW STRIKE' : 'STRIKE POWER'} value={hud.shootCharge} band={[0.6, 0.88]} color={hud.powerShotActive ? 'linear-gradient(90deg,#e89061,#ec5a48)' : 'linear-gradient(90deg,#d5dd75,#e89061)'} />}
          {hud.passCharge > 0 && <ChargeBar label="PASS POWER" value={hud.passCharge} color="linear-gradient(90deg,#38bdf8,#4ade80)" />}
          {hud.timedState && <div className={`font-display text-center text-sm tracking-widest ${hud.timedState === 'green' ? 'text-[var(--accent)]' : 'text-[var(--accent2)]'}`}>{hud.timedState === 'green' ? 'CLEAN CONTACT' : hud.timedState === 'early' ? 'LIGHT CONTACT' : 'OVERHIT'}</div>}
        </div>
      )}

      {/* minimap */}
      {!isPen && hud.mode !== 'training' && !intro && (
        <div className="hud-radar">
          <canvas ref={mapRef} width={200} height={128} />
        </div>
      )}

      {/* training panel */}
      {hud.mode === 'training' && (
        <div className="hud-training">
          <div className="hud-training-label">PRACTICE</div>
          {hud.extra.map((e) => (
            <div key={e.label} className="hud-training-row">
              <span>{e.label}</span>
              <strong>{e.value}</strong>
            </div>
          ))}
        </div>
      )}

      {isPen && hud.pen && <PenaltyHud hud={hud} />}

      {hud.fk && (
        <>
          <div className="hud-free-kick space-y-2">
            <div className="label !text-cyan-300">FREE KICK / {hud.fk.dist} M / WALL OF {hud.fk.wall}</div>
            <div className="flex gap-1.5">
              {Array.from({ length: hud.fk.total }).map((_, i) => {
                const r = hud.fk!.attempts[i];
                return (
                  <div key={i} className={`flex h-6 w-6 items-center justify-center rounded-full border text-xs font-bold ${r === 'goal' ? 'border-lime-300 bg-lime-400 text-black' : r === 'miss' ? 'border-red-300 bg-red-500 text-white' : 'border-white/30 bg-white/5 text-white/40'}`}>
                    {r === 'goal' ? '✓' : r === 'miss' ? '✕' : ''}
                  </div>
                );
              })}
            </div>
            <div className="text-xs uppercase tracking-widest text-slate-400">Goals {hud.fk.goals} / {hud.fk.total}</div>
          </div>
          <div className="hud-fk-curve">
            <div className="mb-0.5 flex justify-between text-[10px] font-bold tracking-widest text-white/80">
              <span>◀ CURVE (Q)</span>
              <span>(E) CURVE ▶</span>
            </div>
            <div className="relative h-3 overflow-hidden rounded-full border border-white/30 bg-black/60">
              <div className="absolute inset-y-0 left-1/2 w-px bg-white/50" />
              <div className="absolute inset-y-0 rounded-full bg-sky-400" style={{ left: hud.fk.curve < 0 ? `${50 + hud.fk.curve * 50}%` : '50%', width: `${Math.abs(hud.fk.curve) * 50}%` }} />
            </div>
            {hud.fk.blockedPreview && <div className="mt-1 text-center text-xs font-bold text-red-300">THE WALL WILL BLOCK THIS — add height or curve</div>}
          </div>
          <div className="hud-aim-power">
            <span className="text-[10px] font-bold tracking-widest text-white/80">POWER</span>
            <div className="relative h-52 w-6 overflow-hidden rounded-full border border-white/40 bg-black/60">
              <div className="absolute inset-x-0 bg-lime-400/30" style={{ bottom: '60%', height: '25%' }} />
              <div className="absolute inset-x-0 bottom-0 rounded-full" style={{ height: `${hud.fk.power * 100}%`, background: 'linear-gradient(0deg,#4ade80,#facc15,#ef4444)' }} />
            </div>
            <span className="text-[10px] text-lime-300">SWEET SPOT</span>
          </div>
        </>
      )}

    </div>
  );
}

function ChargeBar({ label, value, color, band }: { label: string; value: number; color: string; band?: [number, number] }) {
  const inBand = !!band && value >= band[0] && value <= band[1];
  return (
    <div>
      <div className="mb-0.5 flex justify-between text-[10px] font-bold tracking-widest text-white/80">
        <span>{label}{band && <span className="ml-2 text-white/45">sweet spot {band[0] * 100}–{band[1] * 100}%</span>}</span>
        <span className={inBand ? 'text-[var(--accent)]' : undefined}>{Math.round(value * 100)}%</span>
      </div>
      <div className="relative h-3 overflow-hidden rounded-full border border-white/30 bg-black/60">
        {band && <div className="absolute inset-y-0 bg-white/25" style={{ left: `${band[0] * 100}%`, width: `${(band[1] - band[0]) * 100}%` }} />}
        <div className="relative h-full rounded-full" style={{ width: `${value * 100}%`, background: color }} />
      </div>
    </div>
  );
}

function PenaltyHud({ hud }: { hud: EngineHud }) {
  const pen = hud.pen!;
  const n = Math.max(5, pen.home.length, pen.away.length);
  const row = (res: string[], color: string) => (
    <div className="flex gap-1.5">
      {Array.from({ length: n }).map((_, i) => (
        <div
          key={i}
          className={`flex h-6 w-6 items-center justify-center rounded-full border text-xs font-bold ${res[i] === 'goal' ? 'border-lime-300 bg-lime-400 text-black' : res[i] === 'miss' ? 'border-red-300 bg-red-500 text-white' : 'border-white/30 bg-white/5 text-white/40'}`}
          style={res[i] ? undefined : { borderColor: color }}
        >
          {res[i] === 'goal' ? '✓' : res[i] === 'miss' ? '✕' : ''}
        </div>
      ))}
    </div>
  );
  return (
    <>
      <div className="hud-penalties space-y-2">
        <div className="label !text-cyan-300">{pen.sudden ? 'Sudden death' : `Round ${Math.min(pen.round, 5)}/5`}</div>
        <div className="flex items-center gap-3"><span className="font-display w-10 text-lg">{hud.homeShort}</span>{row(pen.home, hud.homeColor)}</div>
        <div className="flex items-center gap-3"><span className="font-display w-10 text-lg">{hud.awayShort}</span>{row(pen.away, hud.awayColor)}</div>
        <div className="text-xs uppercase tracking-widest text-slate-400">{pen.role === 'shoot' ? 'You are shooting' : 'You are the keeper'}</div>
      </div>
      {pen.role === 'shoot' && (
        <div className="hud-aim-power">
          <span className="text-[10px] font-bold tracking-widest text-white/80">POWER</span>
          <div className="relative h-52 w-6 overflow-hidden rounded-full border border-white/40 bg-black/60">
            <div className="absolute inset-x-0 bg-lime-400/30" style={{ bottom: '70%', height: '20%' }} />
            <div className="absolute inset-x-0 bottom-0 rounded-full" style={{ height: `${pen.power * 100}%`, background: 'linear-gradient(0deg,#4ade80,#facc15,#ef4444)' }} />
          </div>
          <span className="text-[10px] text-lime-300">SWEET SPOT</span>
        </div>
      )}
    </>
  );
}

// ------------------------------------------------------------------ pause menu
export function PauseMenu({ engine, mode, onResume, onRestart, onQuit }: { engine: Engine; mode: string; onResume: () => void; onRestart: () => void; onQuit: () => void }) {
  const save = useSave();
  const [showControls, setShowControls] = useState(false);
  const setTactic = (t: Tactic) => {
    engine.setTactic(t);
    updateSave((d) => void (d.selection.tactic = t));
  };
  return (
    <div className="pause-layer">
      <div className="pause-panel scroll-thin">
        <div className="pause-overline">SIDENET / MATCHDAY</div>
        <h2>{showControls ? 'THE CONTROLS.' : 'TAKE A BREATH.'}</h2>
        <p>{showControls ? 'Everything you need when the whistle goes.' : 'The pitch will be here when you get back.'}</p>
        {showControls ? (
          <>
            <ControlsTable />
            <Btn onClick={() => setShowControls(false)}>BACK TO PAUSE</Btn>
          </>
        ) : (
          <>
            <div className="pause-actions">
              <Btn variant="primary" onClick={onResume}>RESUME <span aria-hidden="true">&rarr;</span></Btn>
              <Btn onClick={onRestart}>RESTART MATCH <span aria-hidden="true">&rarr;</span></Btn>
              <Btn onClick={() => setShowControls(true)}>VIEW CONTROLS <span aria-hidden="true">&rarr;</span></Btn>
              <Btn variant="danger" onClick={onQuit}>LEAVE MATCH <span aria-hidden="true">&rarr;</span></Btn>
            </div>
            {mode === 'match' && (
              <div className="pause-setting">
                <Seg label="Team tactic" value={save.selection.tactic} options={TACTIC_LIST.map((t) => ({ v: t, label: TACTICS[t].label }))} onChange={setTactic} />
                <p>{TACTICS[save.selection.tactic].desc}</p>
              </div>
            )}
            {(mode === 'match' || mode === 'training') && (
              <div className="pause-setting">
                <Seg label="Camera" value={save.settings.camera} options={[{ v: 'BROADCAST', label: 'Broadcast' }, { v: 'CLASSIC', label: 'Behind' }, { v: 'CLOSE', label: 'Close' }, { v: 'WIDE', label: 'Wide' }]} onChange={(v) => updateSave((d) => void (d.settings.camera = v))} />
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ result screen
export function ResultScreen({
  result, rewards, homeName, awayName, kind, tournamentNote, onRematch, onContinue, onMenu, continueLabel, bonus,
}: {
  result: MatchResult; rewards: Rewards | null; homeName: string; awayName: string; kind: string; tournamentNote?: string;
  onRematch?: () => void; onContinue: () => void; onMenu: () => void; continueLabel: string;
  bonus?: { claimed: boolean; onClaim: () => void };
}) {
  const win = result.winner === 0;
  const draw = result.winner === -1;
  const stat = (label: string, a: number, b: number, pct = false) => {
    const t = a + b || 1;
    return (
      <div>
        <div className="flex justify-between font-display text-lg"><span>{a}{pct ? '%' : ''}</span><span className="label self-center">{label}</span><span>{b}{pct ? '%' : ''}</span></div>
        <div className="flex h-2 gap-1"><div className="flex justify-end rounded-l-full bg-white/10" style={{ width: `${(a / t) * 100}%` }}><div className="h-full w-full rounded-l-full bg-cyan-400" /></div><div className="rounded-r-full bg-white/10" style={{ width: `${(b / t) * 100}%` }}><div className="h-full w-full rounded-r-full bg-fuchsia-400" /></div></div>
      </div>
    );
  };
  return (
    <div className="result-layer">
      <div className="result-panel scroll-thin">
        <div className="result-head">
          <div className="result-overline">SIDENET / {kind === 'match' ? 'FINAL WHISTLE' : 'SHOOTOUT COMPLETE'}</div>
          <h2 className={win ? 'result-win' : draw ? 'result-draw' : 'result-loss'}>{win ? 'Your night.' : draw ? 'All square.' : 'Next time.'}</h2>
          <div className="result-scoreline">
            {TEAMS.find((t) => t.name === homeName) && <Crest team={TEAMS.find((t) => t.name === homeName)!} size={46} />}
            <span className="result-side-name">{homeName}</span>
            <strong>{result.homeScore} <span>-</span> {result.awayScore}</strong>
            <span className="result-side-name">{awayName}</span>
            {TEAMS.find((t) => t.name === awayName) && <Crest team={TEAMS.find((t) => t.name === awayName)!} size={46} />}
          </div>
          <div className="result-mobile-names">{homeName} / {awayName}</div>
          {result.pens && kind === 'match' && <div className="result-note">{win ? 'Won' : 'Lost'} after extra time decider</div>}
          {tournamentNote && <div className="result-note">{tournamentNote}</div>}
        </div>
        {kind === 'match' && (result.rating !== undefined || result.manOfMatch) && (
          <div className="result-performer">
            <div className="result-rating">
              <div className="label">YOUR PLAYER / 10</div>
              <div>{(result.rating ?? 0).toFixed(1)}</div>
            </div>
            {result.contrib && (
              <div className="result-contrib">
                {([['Goals', result.contrib.goals], ['Shots', result.contrib.shots], ['Passes', result.contrib.passes], ['Tackles', result.contrib.tackles]] as [string, number][]).map(([k, v]) => (
                  <div key={k}>
                    <strong>{v}</strong>
                    <small>{k}</small>
                  </div>
                ))}
              </div>
            )}
            {result.manOfMatch && (
              <div className="result-mom">
                <small>MAN OF THE MATCH</small>
                <strong>{result.manOfMatch}</strong>
              </div>
            )}
          </div>
        )}
        {kind === 'match' && (
          <div className="result-match-data">
            <div className="result-stats">
              {stat('SHOTS', result.shots[0], result.shots[1])}
              {stat('ON TARGET', result.shotsOn[0], result.shotsOn[1])}
              {stat('POSSESSION', result.possession[0], result.possession[1], true)}
            </div>
            <div className="result-scorers">
              <div className="label mb-1">GOALSCORERS</div>
              {result.scorers.length === 0 && <div className="text-sm text-slate-500">No goals</div>}
              <div className="space-y-1">
                {result.scorers.map((s, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    <span className="w-9 text-slate-400">{s.minute}</span>
                    <span className="h-2 w-2 rounded-full" style={{ background: s.team === 0 ? 'var(--accent)' : 'var(--accent2)' }} />
                    <span className="font-display text-base">{s.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
        {rewards && (
          <div className="result-rewards">
            <div><small>XP EARNED</small><strong>+{rewards.xp}</strong></div>
            <div><small>COINS EARNED</small><strong>+{rewards.coins}</strong></div>
            {rewards.levelAfter > rewards.levelBefore && (
              <div><small>LEVEL UP</small><strong>{rewards.levelBefore} &rarr; {rewards.levelAfter}</strong></div>
            )}
          </div>
        )}
        <div className="result-actions">
          <Btn variant="primary" onClick={onContinue}>{continueLabel} <span aria-hidden="true">&rarr;</span></Btn>
          {onRematch && <Btn onClick={onRematch}>REPLAY MATCH</Btn>}
          {bonus && rewards && (
            <Btn disabled={bonus.claimed} onClick={bonus.onClaim}>
              <Icon name="video" size={16} /> {bonus.claimed ? 'BONUS CLAIMED' : `WATCH AD / +${rewards.coins} COINS`}
            </Btn>
          )}
          <Btn onClick={onMenu}>MAIN MENU</Btn>
        </div>
      </div>
    </div>
  );
}
