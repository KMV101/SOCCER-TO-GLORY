import { useState, type CSSProperties } from 'react';
import { ALL_TEAMS, DIFFICULTIES, NATIONS, STADIUMS, TACTICS, TACTIC_LIST, TEAMS, getTeam, type Difficulty, type TeamDef } from '../game/config';
import { useSave, updateSave, type Selection } from '../game/save';
import { createTournament, currentTournamentMatch, ROUND_NAMES, stadiumUnlocked, teamUnlocked } from '../game/progress';
import { audio } from '../game/audio';
import { Btn, Crest, Icon, ScreenFrame, Seg } from './common';

// ------------------------------------------------------------------ team picker
function TeamCard({ team, selected, onClick, locked }: { team: TeamDef; selected: boolean; onClick: () => void; locked?: boolean }) {
  return (
    <button
      type="button"
      disabled={locked}
      aria-pressed={selected}
      onClick={() => {
        audio.play('click');
        onClick();
      }}
      onMouseEnter={() => !locked && audio.play('hover')}
      className={`team-option ${selected ? 'selected' : ''} ${locked ? 'locked' : ''}`}
    >
      <span className="team-option-mark"><Crest team={team} size={33} /></span>
      <span className="team-option-text"><strong>{team.name}</strong><small>{locked ? 'Unlock in Your Player' : team.nation ? 'NATIONAL SIDE' : team.city.toUpperCase()}</small></span>
      {locked ? <span className="team-option-lock"><Icon name="lock" size={16} /></span> : <span className="team-option-rating">{team.rating}</span>}
    </button>
  );
}

export function TeamGrid({ title, value, onChange, exclude, list }: { title: string; value: string; onChange: (id: string) => void; exclude?: string; list?: TeamDef[] }) {
  useSave();
  const [tab, setTab] = useState<'club' | 'nation'>(NATIONS.some((n) => n.id === value) ? 'nation' : 'club');
  const shown = list ?? (tab === 'club' ? TEAMS : NATIONS);
  return (
    <div className="team-selector">
      <div className="team-selector-head">
        <h2>{title}</h2>
        {!list && (
          <div className="team-tabs" role="group" aria-label={`${title} category`}>
            {(['club', 'nation'] as const).map((k) => (
              <button
                type="button"
                key={k}
                aria-pressed={tab === k}
                className={tab === k ? 'active' : ''}
                onClick={() => {
                  audio.play('click');
                  setTab(k);
                }}
              >
                {k === 'club' ? 'Clubs' : 'Nations'}
              </button>
            ))}
          </div>
        )}
      </div>
      <div className="team-list scroll-thin">
        {shown.map((t) => (
          <TeamCard key={t.id} team={t} selected={t.id === value} locked={!teamUnlocked(t.id) || t.id === exclude} onClick={() => onChange(t.id)} />
        ))}
      </div>
    </div>
  );
}

const DURATIONS = [{ v: 60, label: '1 min' }, { v: 120, label: '2 min' }, { v: 180, label: '3 min' }, { v: 300, label: '5 min' }];
const DIFF_OPTS = DIFFICULTIES.map((d) => ({ v: d, label: d }));
const diffDesc: Record<Difficulty, string> = {
  EASY: 'Slow reactions, sloppy positioning.',
  NORMAL: 'Balanced decisions and reactions.',
  HARD: 'Sharp positioning, smarter passing.',
  PRO: 'Fast reactions, tactical awareness.',
};

function useSel() {
  const save = useSave();
  const set = (patch: Partial<Selection>) =>
    updateSave((d) => {
      d.selection = { ...d.selection, ...patch };
    });
  return { sel: save.selection, set, save };
}

// ------------------------------------------------------------------ quick match
export function QuickMatchScreen({ onBack, onStart }: { onBack: () => void; onStart: () => void }) {
  const { sel, set } = useSel();
  const pickHome = (id: string) => {
    const currentType = getTeam(id).nation;
    const other = ALL_TEAMS.find((t) => t.id !== id && t.nation === currentType && teamUnlocked(t.id)) ?? TEAMS[0];
    set({ home: id, away: sel.away === id ? other.id : sel.away });
  };
  const pickAway = (id: string) => set({ away: id });
  const home = getTeam(sel.home);
  const away = getTeam(sel.away);
  return (
    <ScreenFrame title="Quick match" eyebrow="BUILD YOUR FIXTURE" subtitle="Make your fixture. Pick the conditions. The rest happens on the pitch." onBack={onBack}>
      <div className="setup-matchup">
        <div className="setup-side" style={{ '--side-color': home.primary } as CSSProperties}>
          <Crest team={home} size={47} />
          <div><small>YOUR SIDE</small><strong>{home.name}</strong><span className="setup-side-detail">ATT {home.attack} / MID {home.midfield} / DEF {home.defense}</span></div>
        </div>
        <div className="setup-versus">V</div>
        <div className="setup-side setup-side-away" style={{ '--side-color': away.primary } as CSSProperties}>
          <Crest team={away} size={47} />
          <div><small>OPPOSITION</small><strong>{away.name}</strong><span className="setup-side-detail">ATT {away.attack} / MID {away.midfield} / DEF {away.defense}</span></div>
        </div>
      </div>
      <div className="setup-pickers">
        <TeamGrid title="01 / Choose your side" value={sel.home} onChange={pickHome} exclude={sel.away} />
        <TeamGrid title="02 / Choose the opposition" value={sel.away} onChange={pickAway} exclude={sel.home} />
      </div>
      <section className="setup-rules">
        <div className="setup-section-title"><span>03 / MATCH RULES</span><span>YOUR GAME, YOUR TERMS</span></div>
        <div className="setup-rule-grid">
          <Seg label="Duration" value={sel.duration} options={DURATIONS} onChange={(v) => set({ duration: v })} />
          <Seg label="Team size" value={sel.size} options={[{ v: 1, label: '1v1' }, { v: 3, label: '3v3' }, { v: 5, label: '5v5' }]} onChange={(v) => set({ size: v })} />
          <Seg label="Difficulty" value={sel.difficulty} options={DIFF_OPTS} onChange={(v) => set({ difficulty: v })} />
          <Seg label="Approach" value={sel.tactic} options={TACTIC_LIST.map((t) => ({ v: t, label: TACTICS[t].label }))} onChange={(v) => set({ tactic: v })} />
          <Seg label="Ground" value={sel.stadium} options={STADIUMS.filter((s) => !s.street).map((s) => ({ v: s.id, label: s.name }))} disabledFn={(id) => !stadiumUnlocked(id)} onChange={(v) => set({ stadium: v })} />
        </div>
        <p className="setup-rule-note">{diffDesc[sel.difficulty]} {TACTICS[sel.tactic].desc}</p>
      </section>
      <div className="setup-footer"><span>{sel.size}V{sel.size} / {sel.duration / 60} MIN / {sel.difficulty}</span><Btn variant="primary" onClick={onStart}>KICK OFF <span aria-hidden="true">&rarr;</span></Btn></div>
    </ScreenFrame>
  );
}

// ------------------------------------------------------------------ tournament
export function TournamentScreen({ onBack, onPlay }: { onBack: () => void; onPlay: (oppId: string) => void }) {
  const { sel, set, save } = useSel();
  const t = save.tournament;
  const [pick, setPick] = useState(TEAMS.some((team) => team.id === sel.home) ? sel.home : TEAMS[0].id);
  const [confirmAbandon, setConfirmAbandon] = useState(false);
  if (!t) {
    return (
      <ScreenFrame title="Knockout cup" eyebrow="THE ROAD TO THE FINAL" subtitle="Three rounds. No second chances. Make the final yours." onBack={onBack}>
        <div className="max-w-[580px]"><TeamGrid title="01 / Choose your side" value={pick} onChange={setPick} list={TEAMS} /></div>
        <div className="setup-rules mt-8">
          <div className="setup-section-title"><span>02 / MATCH RULES</span><span>THE ROAD TO THE FINAL</span></div>
          <div className="setup-rule-grid">
          <Seg label="AI difficulty" value={sel.difficulty} options={DIFF_OPTS} onChange={(v) => set({ difficulty: v })} />
          <Seg label="Match duration" value={sel.duration} options={DURATIONS} onChange={(v) => set({ duration: v })} />
          </div>
        </div>
        <div className="setup-footer"><span>QUARTERFINAL / SEMIFINAL / FINAL</span><Btn variant="primary" onClick={() => updateSave((d) => { d.tournament = createTournament(pick); d.selection.home = pick; })}>START CUP <span aria-hidden="true">&rarr;</span></Btn></div>
      </ScreenFrame>
    );
  }
  const next = currentTournamentMatch(t);
  const me = getTeam(t.teamId);
  const oppId = next ? (next.a === t.teamId ? next.b : next.a) : null;
  return (
    <ScreenFrame
      title="Knockout cup"
      eyebrow="THE ROAD TO THE FINAL"
      subtitle={t.status === 'active' ? `${ROUND_NAMES[t.round]} · you are ${me.name}` : t.status === 'champion' ? 'Champions!' : 'Eliminated'}
      onBack={onBack}
      wide
      right={confirmAbandon ? (
        <div className="flex gap-2"><Btn variant="danger" onClick={() => { updateSave((d) => void (d.tournament = null)); setConfirmAbandon(false); }}>CONFIRM</Btn><Btn onClick={() => setConfirmAbandon(false)}>CANCEL</Btn></div>
      ) : <Btn variant="danger" onClick={() => setConfirmAbandon(true)}>{t.status === 'active' ? 'ABANDON CUP' : 'NEW CUP'}</Btn>}
    >
      <div className="bracket-layout">
        {t.rounds.map((round, ri) => (
          <div key={ri} className="bracket-round">
            <div className="bracket-label">0{ri + 1} / {ROUND_NAMES[ri]}</div>
            {Array.from({ length: ri === 0 ? 4 : ri === 1 ? 2 : 1 }).map((_, mi) => {
              const m = round[mi];
              const isNext = t.status === 'active' && ri === t.round && m && (m.a === t.teamId || m.b === t.teamId);
              return (
                <div key={mi} className={`bracket-fixture ${isNext ? 'is-current' : ''}`}>
                  {m ? (
                    [m.a, m.b].map((id, si) => {
                      const tm = getTeam(id);
                      const goals = si === 0 ? m.ga : m.gb;
                      const won = m.winner === id;
                      return (
                        <div key={id} className={`bracket-side ${id === t.teamId ? 'is-yours' : ''} ${m.winner && !won ? 'is-out' : ''}`}>
                          <Crest team={tm} size={26} />
                          <span className="flex-1 truncate">{tm.name}</span>
                          {goals !== undefined && <span className="bracket-goals">{goals}</span>}
                          {won && m.pens && <span className="text-[10px] text-[var(--accent2)]">ET</span>}
                        </div>
                      );
                    })
                  ) : (
                    <div className="bracket-pending">TO BE DECIDED</div>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>
      <div className="competition-next">
        {t.status === 'active' && oppId ? (
          <>
            <Crest team={me} size={50} />
            <span className="font-display text-3xl text-white/40">V</span>
            <Crest team={getTeam(oppId)} size={50} />
            <div>
              <div className="label">{ROUND_NAMES[t.round]}</div>
              <div className="font-display text-2xl">{me.name} V {getTeam(oppId).name}</div>
              <div className="text-sm text-slate-400">Knockout — a draw goes to golden goal.</div>
            </div>
            <Btn variant="primary" className="ml-auto" onClick={() => onPlay(oppId)}>PLAY MATCH <span aria-hidden="true">&rarr;</span></Btn>
          </>
        ) : (
          <div className="flex items-center gap-4">
            <div className={`flex h-12 w-12 items-center justify-center rounded-full border ${t.status === 'champion' ? 'border-[var(--accent)] text-[var(--accent)]' : 'border-white/20 text-white/60'}`}>
              <Icon name={t.status === 'champion' ? 'trophy' : 'target'} size={24} />
            </div>
            <div>
              <div className="font-display text-3xl">{t.status === 'champion' ? 'Tournament winner!' : 'Knocked out'}</div>
              <div className="text-slate-400">{t.status === 'champion' ? 'Bonus rewards were added to your profile.' : 'Start a new tournament to try again.'}</div>
            </div>
          </div>
        )}
      </div>
    </ScreenFrame>
  );
}

// ------------------------------------------------------------------ penalty setup
export function PenaltyScreen({ onBack, onStart }: { onBack: () => void; onStart: () => void }) {
  const { sel, set } = useSel();
  const home = getTeam(sel.home);
  const away = getTeam(sel.away);
  return (
    <ScreenFrame title="Penalty shootout" eyebrow="FROM THE SPOT" subtitle="Five kicks each. Step up to the spot, then try to keep theirs out." onBack={onBack}>
      <div className="setup-matchup">
        <div className="setup-side" style={{ '--side-color': home.primary } as CSSProperties}><Crest team={home} size={47} /><div><small>YOUR SIDE</small><strong>{home.name}</strong></div></div>
        <div className="setup-versus">V</div>
        <div className="setup-side setup-side-away" style={{ '--side-color': away.primary } as CSSProperties}><Crest team={away} size={47} /><div><small>OPPOSITION</small><strong>{away.name}</strong></div></div>
      </div>
      <div className="setup-pickers">
        <TeamGrid title="01 / Choose your side" value={sel.home} onChange={(id) => set({ home: id, away: sel.away === id ? (ALL_TEAMS.find((t) => t.id !== id && t.nation === getTeam(id).nation && teamUnlocked(t.id)) ?? TEAMS[0]).id : sel.away })} exclude={sel.away} />
        <TeamGrid title="02 / Choose the opposition" value={sel.away} onChange={(id) => set({ away: id })} exclude={sel.home} />
      </div>
      <div className="setup-rules"><div className="setup-section-title"><span>03 / PRESSURE</span><span>FIVE KICKS EACH</span></div><div className="setup-rule-grid"><Seg label="Keeper difficulty" value={sel.difficulty} options={DIFF_OPTS} onChange={(v) => set({ difficulty: v })} /></div><p className="setup-rule-note">Aim with WASD. Hold Strike for power; release to shoot. When in goal, pick your dive as the taker runs up.</p></div>
      <div className="setup-footer"><span>YOU SHOOT. YOU SAVE. FIVE EACH.</span><Btn variant="primary" onClick={onStart}>STEP UP <span aria-hidden="true">&rarr;</span></Btn></div>
    </ScreenFrame>
  );
}

// ------------------------------------------------------------------ training setup
export function TrainingScreen({ onBack, onStart }: { onBack: () => void; onStart: () => void }) {
  const { sel, set } = useSel();
  return (
    <ScreenFrame title="Training ground" eyebrow="FIND YOUR TOUCH" subtitle="No opponent, no clock. Just the ball and whatever you want to try next." onBack={onBack}>
      <div className="training-layout">
        <TeamGrid title="01 / Pick your colours" value={sel.home} onChange={(id) => set({ home: id })} />
        <div className="training-drills">
          <div className="setup-section-title"><span>02 / FIND YOUR TOUCH</span></div>
          <div><span>01</span><strong>Find the corners</strong><p>Four targets sit inside the goal. Hit them to build a streak.</p></div>
          <div><span>02</span><strong>Pick out a pass</strong><p>Roll the ball into the marked zones around the pitch.</p></div>
          <div><span>03</span><strong>Start again</strong><p>Press B or Reset Ball on-screen to put it back at your feet.</p></div>
          <div className="training-keys"><div className="label">ON THE PITCH</div><p>WASD to move. Hold Strike for power. Q to pass. Reset Ball brings it back.</p></div>
        </div>
      </div>
      <div className="setup-footer"><span>NO SCORE. NO PRESSURE. JUST FOOTBALL.</span><Btn variant="primary" onClick={onStart}>ENTER THE GROUND <span aria-hidden="true">&rarr;</span></Btn></div>
    </ScreenFrame>
  );
}
