import { useEffect, useState } from 'react';
import { BOOT_COLORS, HAIR_STYLES, KIT_COLORS, SKIN_TONES, UNLOCKS, findUnlock, getTeam, levelFromXp, type UnlockDef } from '../game/config';
import { buy, canBuy, isUnlocked } from '../game/progress';
import { resetSave, updateSave, useSave, type Custom, type Settings } from '../game/save';
import { audio } from '../game/audio';
import { hairColorFor } from '../game/models';
import { Btn, ControlsTable, Face, Icon, ScreenFrame, Seg, Slider, Toggle, click } from './common';

// ------------------------------------------------------------------ customize
export function CustomizeScreen({ onBack, onPreview }: { onBack: () => void; onPreview: (c: Custom | null, kit?: { primary: string; secondary: string }) => void }) {
  const save = useSave();
  const c = save.custom;
  const [tab, setTab] = useState<'player' | 'kit' | 'unlocks'>('player');
  const set = (patch: Partial<Custom>) =>
    updateSave((d) => {
      d.custom = { ...d.custom, ...patch };
    });
  const team = getTeam(save.selection.home);
  const kit = c.useCustomKit ? { primary: c.primary, secondary: c.secondary } : { primary: team.primary, secondary: team.secondary };

  useEffect(() => {
    onPreview(c, kit);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [c, kit.primary, kit.secondary]);
  useEffect(() => () => onPreview(null), []); // eslint-disable-line react-hooks/exhaustive-deps

  const lv = levelFromXp(save.xp).level;
  const lockedBadge = (u?: UnlockDef) => (u && !isUnlocked(u) ? <span className="absolute -right-1 -top-1 rounded-full bg-black/80 p-1 text-amber-300"><Icon name="lock" size={12} /></span> : null);

  return (
    <div className="studio-screen absolute inset-0 flex flex-col md:flex-row">
      <div className="studio-panel flex min-h-0 flex-1 flex-col md:max-w-xl">
        <div className="studio-header">
          <button type="button" className="screen-back" onClick={() => { click(); onBack(); }}><span aria-hidden="true">&larr;</span> BACK TO HOME</button>
          <span className="screen-edition">SIDENET / PLAYER STUDIO</span>
        </div>
        <div className="studio-heading"><div className="screen-overline">MAKE IT YOURS</div><h1>YOUR PLAYER<span>.</span></h1><p>Give them a name. Find their colours. Make the pitch yours.</p></div>
        <div className="px-4 pt-2 md:px-8">
          <Seg value={tab} onChange={setTab} options={[{ v: 'player', label: 'Player' }, { v: 'kit', label: 'Team kit' }, { v: 'unlocks', label: 'Unlocks' }]} />
        </div>
        <div className="scroll-thin min-h-0 flex-1 space-y-6 overflow-y-auto px-4 py-5 md:px-8">
          {tab === 'player' && (
            <>
              <div className="studio-identity flex items-center gap-4 pb-4">
                <Face skin={SKIN_TONES[c.skin % 6]} hair={c.hair} hairColor={hairColorFor(c.number + c.skin)} primary={kit.primary} secondary={kit.secondary} size={76} />
                <div>
                  <div className="font-display text-3xl leading-none">{c.name || 'ROOKIE'}</div>
                  <div className="mt-1 text-sm text-slate-400">#{c.number} · Level {levelFromXp(save.xp).level} · {team.name}</div>
                </div>
              </div>
              <div className="grid grid-cols-[1fr_auto] gap-4">
                <div>
                  <div className="label mb-1.5">Name</div>
                  <input
                    value={c.name}
                    maxLength={12}
                    onChange={(e) => set({ name: e.target.value.toUpperCase().replace(/[^A-Z0-9 ._-]/g, '') })}
                    className="studio-input font-display w-full px-3 py-2 text-xl outline-none"
                  />
                </div>
                <div className="w-28">
                  <div className="label mb-1.5">Shirt number</div>
                  <input
                    type="number"
                    min={1}
                    max={99}
                    value={c.number}
                    onChange={(e) => set({ number: Math.max(1, Math.min(99, Number(e.target.value) || 1)) })}
                    className="studio-input font-display w-full px-3 py-2 text-xl outline-none"
                  />
                </div>
              </div>
              <div>
                <div className="label mb-2">Hair style</div>
                <div className="flex flex-wrap gap-2">
                  {HAIR_STYLES.map((h, i) => {
                    const u = findUnlock('hair', i);
                    const locked = !!u && !isUnlocked(u);
                    return (
                      <button
                        key={h}
                        disabled={locked}
                        onClick={() => { click(); set({ hair: i }); }}
                        className={`studio-choice relative px-4 py-2 font-display text-sm transition ${c.hair === i ? 'selected' : ''} ${locked ? 'opacity-50' : ''}`}
                      >
                        {h}
                        {lockedBadge(u)}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div>
                <div className="label mb-2">Skin tone</div>
                <div className="flex gap-3">
                  {SKIN_TONES.map((s, i) => (
                    <button key={s} onClick={() => { click(); set({ skin: i }); }} className={`h-10 w-10 rounded-full border-2 transition ${c.skin === i ? 'scale-110 border-cyan-300' : 'border-white/20'}`} style={{ background: s }} />
                  ))}
                </div>
              </div>
              <div>
                <div className="label mb-2">Boots</div>
                <div className="flex flex-wrap gap-3">
                  {BOOT_COLORS.map((b) => {
                    const u = findUnlock('boots', b.id);
                    const locked = !!u && !isUnlocked(u);
                    return (
                      <button key={b.id} disabled={locked} onClick={() => { click(); set({ boots: b.id }); }} title={b.name} className={`relative h-10 w-10 rounded-lg border-2 transition ${c.boots === b.id ? 'scale-110 border-cyan-300' : 'border-white/20'} ${locked ? 'opacity-40' : ''}`} style={{ background: b.color }}>
                        {lockedBadge(u)}
                      </button>
                    );
                  })}
                </div>
              </div>
              <p className="text-sm text-slate-400">Your player is level {lv}. Higher levels boost their stats in every match.</p>
            </>
          )}
          {tab === 'kit' && (
            <>
              <Toggle value={c.useCustomKit} onChange={(v) => set({ useCustomKit: v })} label="Use custom kit colors" desc="Overrides the colors of the team you control." />
              {(['primary', 'secondary'] as const).map((k) => (
                <div key={k}>
                  <div className="label mb-2">{k} color</div>
                  <div className="flex flex-wrap gap-3">
                    {KIT_COLORS.map((col) => {
                      const u = findUnlock('kit', col.id);
                      const locked = !!u && !isUnlocked(u);
                      return (
                        <button
                          key={col.id}
                          disabled={locked}
                          title={col.name}
                          onClick={() => { click(); set({ [k]: col.color, useCustomKit: true } as Partial<Custom>); }}
                          className={`relative h-10 w-10 rounded-full border-2 transition ${c[k].toLowerCase() === col.color ? 'scale-110 border-cyan-300' : 'border-white/20'} ${locked ? 'opacity-40' : ''}`}
                          style={{ background: col.color }}
                        >
                          {lockedBadge(u)}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
              <div className="studio-identity flex items-center gap-4 py-4">
                <div className="h-14 w-14" style={{ background: `linear-gradient(135deg, ${kit.primary} 60%, ${kit.secondary} 60%)` }} />
                <div className="text-sm text-slate-300">Kit preview — see it on the 3D player to the right.</div>
              </div>
            </>
          )}
          {tab === 'unlocks' && (
            <div className="space-y-2.5">
              <p className="text-sm text-slate-400">Earn XP and coins by playing matches. Items unlock at a required level and cost coins.</p>
              {UNLOCKS.map((u) => {
                const owned = isUnlocked(u);
                const needLv = lv < u.level;
                return (
                  <div key={u.id} className="studio-unlock flex items-center gap-3 px-1 py-3">
                    <div className="min-w-0 flex-1">
                      <div className="font-display text-lg leading-tight">{u.name}</div>
                      <div className="text-xs uppercase tracking-wider text-slate-400">{u.type} · level {u.level}</div>
                    </div>
                    {owned ? (
                      <span className="font-display text-lime-300">OWNED</span>
                    ) : (
                      <Btn variant={canBuy(u) ? 'primary' : 'default'} disabled={!canBuy(u)} onClick={() => buy(u)} className="!px-4 !py-1.5 text-sm">
                        {needLv ? `LVL ${u.level}` : <><Icon name="coin" size={14} /> {u.cost}</>}
                      </Btn>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
      <div className="pointer-events-none hidden flex-1 items-end justify-end p-8 md:flex">
        <div className="studio-preview-caption">ON THE PITCH / {c.name} #{c.number}</div>
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ settings
export function SettingsScreen({ onBack }: { onBack: () => void }) {
  const save = useSave();
  const s = save.settings;
  const [confirm, setConfirm] = useState(false);
  const set = (patch: Partial<Settings>) =>
    updateSave((d) => {
      d.settings = { ...d.settings, ...patch };
    });
  return (
    <ScreenFrame title="Settings" eyebrow="MAKE IT YOUR GAME" subtitle="Graphics, audio and controls" onBack={onBack}>
      <div className="grid gap-6 lg:grid-cols-2">
        <section className="settings-section space-y-5">
          <h2 className="font-display text-2xl text-cyan-300">Graphics</h2>
          <Seg label="Quality" value={s.quality} options={[{ v: 'LOW', label: 'Low' }, { v: 'MEDIUM', label: 'Medium' }, { v: 'HIGH', label: 'High' }]} onChange={(v) => set({ quality: v })} />
          <p className="-mt-3 text-sm text-slate-400">
            {s.quality === 'LOW' ? 'No shadows, light crowd — best for integrated graphics.' : s.quality === 'MEDIUM' ? 'Soft shadows, animated crowd.' : 'Large shadow map, dense crowd, full effects.'}
          </p>
          <Seg label="Resolution scale" value={s.resScale} options={[{ v: 0.75, label: '75%' }, { v: 1, label: '100%' }]} onChange={(v) => set({ resScale: v })} />
          <Seg label="FPS limit" value={s.fps} options={[{ v: 30, label: '30' }, { v: 60, label: '60' }]} onChange={(v) => set({ fps: v })} />
          <Seg label="Camera" value={s.camera} options={[{ v: 'BROADCAST', label: 'Broadcast' }, { v: 'CLASSIC', label: 'Behind' }, { v: 'CLOSE', label: 'Close' }, { v: 'WIDE', label: 'Wide' }]} onChange={(v) => set({ camera: v })} />
          <Toggle value={s.showFps} onChange={(v) => set({ showFps: v })} label="Show FPS counter" />
        </section>
        <section className="settings-section space-y-5">
          <h2 className="font-display text-2xl text-cyan-300">Audio</h2>
          <Slider label="Master volume" value={s.master} onChange={(v) => set({ master: v })} />
          <Slider label="Music volume" value={s.music} onChange={(v) => set({ music: v })} />
          <Slider label="SFX volume" value={s.sfx} onChange={(v) => { set({ sfx: v }); audio.play('kick', 0.6); }} />
          <Slider label="Crowd volume" value={s.crowd} onChange={(v) => set({ crowd: v })} />
          <h2 className="font-display pt-2 text-2xl text-cyan-300">Gameplay</h2>
          <Toggle value={s.aimAssist} onChange={(v) => set({ aimAssist: v })} label="Shot aim assist" desc="Gently steers shots toward the goal mouth." />
          <Toggle value={s.autoSwitch} onChange={(v) => set({ autoSwitch: v })} label="Auto player switching" desc="Switch to the receiver after passes and the closest defender." />
          <Toggle value={s.gamepad} onChange={(v) => set({ gamepad: v })} label="Gamepad support" />
        </section>
        <section className="settings-section lg:col-span-2">
          <h2 className="font-display mb-3 text-2xl text-cyan-300">Controls</h2>
          <ControlsTable />
        </section>
        <section className="settings-section flex flex-wrap items-center justify-between gap-4 lg:col-span-2">
          <div>
            <h2 className="font-display text-2xl text-red-300">Save data</h2>
            <p className="text-sm text-slate-400">Settings, progress, unlocks, tournament and customization are stored locally in your browser.</p>
          </div>
          {confirm ? (
            <div className="flex gap-3">
              <Btn variant="danger" onClick={() => { resetSave(); setConfirm(false); }}>Yes, erase everything</Btn>
              <Btn onClick={() => setConfirm(false)}>Cancel</Btn>
            </div>
          ) : (
            <Btn variant="danger" onClick={() => setConfirm(true)}>Reset save data</Btn>
          )}
        </section>
      </div>
    </ScreenFrame>
  );
}
