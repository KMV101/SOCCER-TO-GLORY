import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent, type KeyboardEvent as ReactKeyboardEvent } from 'react';
import type { Engine } from '../game/engine';
import type { Action } from '../game/input';
import { audio } from '../game/audio';

export type ControlMode = 'match' | 'penalty-shot' | 'penalty-keeper' | 'freekick';
type Direction = 'up' | 'down' | 'left' | 'right';
type ShotStyle = 'normal' | 'finesse' | 'powershot' | 'lob' | 'low';

const STYLE_BUTTONS: { value: ShotStyle; label: string; hint: string }[] = [
  { value: 'normal', label: 'Normal', hint: 'Standard strike' },
  { value: 'finesse', label: 'Bend', hint: 'Curl toward the corner' },
  { value: 'powershot', label: 'Drive', hint: 'Heavy strike with a vulnerable windup' },
  { value: 'lob', label: 'Chip', hint: 'Lift it over the keeper' },
  { value: 'low', label: 'Low', hint: 'Keep the strike along the turf' },
];
const STYLE_ACTIONS: Exclude<ShotStyle, 'normal'>[] = ['finesse', 'powershot', 'lob', 'low'];

const MATCH_ACTIONS: { label: string; hint: string; action: Action; type?: 'primary' | 'accent'; wide?: boolean }[] = [
  { label: 'STRIKE', hint: 'Hold to charge, release to kick', action: 'shoot', type: 'primary', wide: true },
  { label: 'PASS', hint: 'Hold for a stronger pass', action: 'pass' },
  { label: 'THROUGH', hint: 'Pass into space', action: 'through' },
  { label: 'SKILL', hint: 'Beat a nearby marker', action: 'skill' },
  { label: 'SWITCH', hint: 'Select another player', action: 'switch' },
  { label: 'SPRINT', hint: 'Hold to run faster', action: 'sprint' },
];
const DEFEND_ACTIONS: typeof MATCH_ACTIONS = [
  { label: 'TACKLE', hint: 'Standing tackle', action: 'tackle', type: 'accent', wide: true },
  { label: 'SLIDE', hint: 'Sliding challenge and recovery', action: 'slide', type: 'accent' },
  { label: 'SWITCH', hint: 'Select another player', action: 'switch' },
  { label: 'SPRINT', hint: 'Hold to run faster', action: 'sprint' },
];

const DIVE_BUTTONS: { label: string; hint: string; actions: Action[] }[] = [
  { label: 'HIGH LEFT', hint: 'Dive toward the upper left', actions: ['diveLeft', 'diveHigh'] },
  { label: 'HIGH RIGHT', hint: 'Dive toward the upper right', actions: ['diveRight', 'diveHigh'] },
  { label: 'LOW LEFT', hint: 'Dive toward the lower left', actions: ['diveLeft', 'diveLow'] },
  { label: 'LOW RIGHT', hint: 'Dive toward the lower right', actions: ['diveRight', 'diveLow'] },
  { label: 'STAY CENTRE', hint: 'Hold your position at the centre', actions: ['switch'] },
];

function HeldButton({ engine, actions = [], label, hint, className = '', onStart, onEnd, disabled = false }: {
  engine: Engine;
  actions?: readonly Action[];
  label: string;
  hint: string;
  className?: string;
  onStart?: () => void;
  onEnd?: () => void;
  disabled?: boolean;
}) {
  const pointer = useRef<number | null>(null);
  const held = useRef(false);
  const [active, setActive] = useState(false);
  const latest = useRef({ actions, onEnd });
  latest.current = { actions, onEnd };

  const release = () => {
    if (!held.current) return;
    held.current = false;
    pointer.current = null;
    setActive(false);
    latest.current.actions.forEach((a) => engine.input.setTouchBtn(a, false));
    latest.current.onEnd?.();
  };
  useEffect(() => () => {
    if (!held.current) return;
    held.current = false;
    latest.current.actions.forEach((a) => engine.input.setTouchBtn(a, false));
    latest.current.onEnd?.();
  }, [engine]);

  const press = () => {
    if (held.current || disabled) return;
    held.current = true;
    setActive(true);
    actions.forEach((a) => engine.input.setTouchBtn(a, true));
    onStart?.();
  };
  const pointerDown = (e: ReactPointerEvent<HTMLButtonElement>) => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    e.preventDefault();
    pointer.current = e.pointerId;
    e.currentTarget.setPointerCapture(e.pointerId);
    press();
  };
  const pointerUp = (e: ReactPointerEvent<HTMLButtonElement>) => {
    if (pointer.current === e.pointerId) release();
  };
  const keyDown = (e: ReactKeyboardEvent<HTMLButtonElement>) => {
    if (e.key === ' ' || e.key === 'Enter') {
      e.preventDefault();
      e.stopPropagation();
      press();
    }
  };
  const keyUp = (e: ReactKeyboardEvent<HTMLButtonElement>) => {
    if (e.key === ' ' || e.key === 'Enter') {
      e.preventDefault();
      e.stopPropagation();
      release();
    }
  };

  return (
    <button
      type="button"
      aria-label={hint}
      title={hint}
      disabled={disabled}
      className={`virtual-key ${active ? 'is-down' : ''} ${className}`}
      onPointerDown={pointerDown}
      onPointerUp={pointerUp}
      onPointerCancel={pointerUp}
      onLostPointerCapture={pointerUp}
      onKeyDown={keyDown}
      onKeyUp={keyUp}
      onContextMenu={(e) => e.preventDefault()}
    >
      {label}
    </button>
  );
}

function DirectionPad({ engine, label }: { engine: Engine; label: string }) {
  const down = useRef(new Set<Direction>());
  const update = (direction: Direction, active: boolean) => {
    if (active) down.current.add(direction);
    else down.current.delete(direction);
    const x = Number(down.current.has('right')) - Number(down.current.has('left'));
    const y = Number(down.current.has('up')) - Number(down.current.has('down'));
    const length = Math.hypot(x, y) || 1;
    engine.input.setTouchMove(x / length, y / length);
  };
  useEffect(() => () => {
    down.current.clear();
    engine.input.setTouchMove(0, 0);
  }, [engine]);

  return (
    <div className="virtual-move">
      <div className="virtual-caption">{label} <span>W A S D</span></div>
      <div className="virtual-pad">
        {([
          ['up', '↑', 'pad-up'], ['left', '←', 'pad-left'],
          ['right', '→', 'pad-right'], ['down', '↓', 'pad-down'],
        ] as [Direction, string, string][]).map(([direction, symbol, position]) => (
          <HeldButton
            key={direction}
            engine={engine}
            label={symbol}
            hint={`${label.toLowerCase()} ${direction}`}
            className={`virtual-direction ${position}`}
            onStart={() => update(direction, true)}
            onEnd={() => update(direction, false)}
          />
        ))}
        <div className="pad-centre" aria-hidden="true">+</div>
      </div>
    </div>
  );
}

/** Works with pointer/touch on every screen size, alongside keyboard, mouse and gamepad. */
export function MatchControls({ engine, mode, training = false, canSwitch = true, attacking = true, keeperDived = false }: { engine: Engine; mode: ControlMode; training?: boolean; canSwitch?: boolean; attacking?: boolean; keeperDived?: boolean }) {
  const [style, setStyle] = useState<ShotStyle>('normal');
  useEffect(() => () => engine.input.clearVirtual(), [engine]);
  const selectStyle = (next: ShotStyle) => {
    STYLE_ACTIONS.forEach((a) => engine.input.setTouchBtn(a, a === next));
    setStyle(next);
    audio.play('click', 0.38);
  };

  return (
    <div className={`virtual-controls virtual-${mode}`} aria-label="On-screen game controls">
      {mode !== 'penalty-keeper' ? <DirectionPad engine={engine} label={mode === 'match' ? 'MOVE' : 'AIM'} /> : (
        <div className="virtual-keeper-instruction">{keeperDived ? 'Dive committed. Watch the shot.' : <>Wait for the run-up.<br />Pick a corner to dive.</>}</div>
      )}

      {training && mode === 'match' && (
        <div className="virtual-reset">
          <HeldButton engine={engine} actions={['reset']} label="RESET BALL" hint="Put the ball back in front of your player" />
        </div>
      )}

      <div className="virtual-actions">
        {mode === 'match' && (
          <>
            <div className="virtual-caption">{attacking ? 'ON THE BALL' : 'WIN IT BACK'} <span>CLICK OR TOUCH</span></div>
            {attacking && <div className="virtual-styles" aria-label="Strike type">
              {STYLE_BUTTONS.map((item) => (
                <button
                  type="button"
                  key={item.value}
                  aria-label={item.hint}
                  aria-pressed={style === item.value}
                  title={item.hint}
                  className={`virtual-style ${style === item.value ? 'selected' : ''}`}
                  onPointerDown={(e) => e.preventDefault()}
                  onClick={() => selectStyle(item.value)}
                >
                  {item.label}
                </button>
              ))}
            </div>}
            <div className="virtual-action-grid">
              {(attacking ? MATCH_ACTIONS : DEFEND_ACTIONS).filter((item) => canSwitch || item.action !== 'switch').map((item) => (
                <HeldButton
                  key={item.action}
                  engine={engine}
                  actions={[item.action]}
                  label={item.label}
                  hint={item.hint}
                  className={`${item.wide ? 'action-wide' : ''} ${item.type === 'primary' ? 'action-primary' : item.type === 'accent' ? 'action-accent' : ''}`}
                />
              ))}
            </div>
          </>
        )}
        {mode === 'penalty-shot' && (
          <div className="virtual-special">
            <div className="virtual-caption">PENALTY <span>AIM, HOLD, RELEASE</span></div>
            <HeldButton engine={engine} actions={['shoot']} label="HOLD TO STRIKE" hint="Hold to build power; release to take the penalty" className="action-primary special-strike" />
          </div>
        )}
        {mode === 'penalty-keeper' && (
          <div className="virtual-special">
            <div className="virtual-caption">GOALKEEPER <span>CHOOSE YOUR DIVE</span></div>
            <div className="virtual-dive-grid">
              {DIVE_BUTTONS.map((item) => (
                <HeldButton key={item.label} engine={engine} actions={item.actions} label={item.label} hint={item.hint} disabled={keeperDived} className={item.label === 'STAY CENTRE' ? 'centre-dive' : 'action-accent'} />
              ))}
            </div>
          </div>
        )}
        {mode === 'freekick' && (
          <div className="virtual-special">
            <div className="virtual-caption">FREE KICK <span>AIM & CURVE</span></div>
            <div className="virtual-curve-grid">
              <HeldButton engine={engine} actions={['lob']} label="CURVE LEFT" hint="Hold to curve left" />
              <HeldButton engine={engine} actions={['sprint']} label="CURVE RIGHT" hint="Hold to curve right" />
              <HeldButton engine={engine} actions={['shoot']} label="HOLD TO STRIKE" hint="Hold to charge your free kick and release to shoot" className="action-primary special-strike" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}