import { useState, type CSSProperties } from 'react';
import { ALL_TEAMS, DIFFICULTIES, NATIONS, TEAMS, getTeam, type Difficulty } from '../game/config';
import { createCup, createLeague, isKnockout, nextFixture, stageLabel, table, userPlace, type Row } from '../game/competition';
import { updateSave, useSave, type CompState, type Fx, type Selection } from '../game/save';
import { teamUnlocked } from '../game/progress';
import { Btn, Crest, ScreenFrame, Seg } from './common';
import { TeamGrid } from './Screens';

const DURATIONS = [{ v: 60, label: '1 min' }, { v: 120, label: '2 min' }, { v: 180, label: '3 min' }, { v: 300, label: '5 min' }];
const DIFF_OPTS = DIFFICULTIES.map((d) => ({ v: d as Difficulty, label: d }));

function useSel() {
  const save = useSave();
  const set = (patch: Partial<Selection>) =>
    updateSave((d) => {
      d.selection = { ...d.selection, ...patch };
    });
  return { sel: save.selection, set, save };
}

const firstOther = (id: string) => (ALL_TEAMS.find((t) => t.id !== id && t.nation === getTeam(id).nation && teamUnlocked(t.id)) ?? TEAMS[0]).id;

// ------------------------------------------------------------------ street soccer
export function StreetScreen({ onBack, onStart }: { onBack: () => void; onStart: () => void }) {
  const { sel, set } = useSel();
  const home = getTeam(sel.home);
  const away = getTeam(sel.away);
  return (
    <ScreenFrame title="Street football" eyebrow="THE CAGE" subtitle="No keepers. No out-of-play. Every wall is part of the move." onBack={onBack}>
      <div className="setup-matchup">
        <div className="setup-side" style={{ '--side-color': home.primary } as CSSProperties}><Crest team={home} size={47} /><div><small>YOUR CREW</small><strong>{home.name}</strong></div></div>
        <div className="setup-versus">V</div>
        <div className="setup-side setup-side-away" style={{ '--side-color': away.primary } as CSSProperties}><Crest team={away} size={47} /><div><small>RIVAL CREW</small><strong>{away.name}</strong></div></div>
      </div>
      <div className="setup-pickers">
        <TeamGrid title="01 / Pick your crew" value={sel.home} onChange={(id) => set({ home: id, away: sel.away === id ? firstOther(id) : sel.away })} exclude={sel.away} />
        <TeamGrid title="02 / Pick the rival" value={sel.away} onChange={(id) => set({ away: id })} exclude={sel.home} />
      </div>
      <div className="setup-rules"><div className="setup-section-title"><span>03 / COURT RULES</span><span>WALLS STAY LIVE</span></div>
        <div className="setup-rule-grid">
          <Seg label="Format" value={sel.streetSize} options={[{ v: 3, label: '3v3' }, { v: 4, label: '4v4' }]} onChange={(v) => set({ streetSize: v })} />
          <Seg label="First to" value={sel.streetGoals} options={[{ v: 3, label: '3 goals' }, { v: 5, label: '5 goals' }, { v: 7, label: '7 goals' }]} onChange={(v) => set({ streetGoals: v })} />
          <Seg label="Time limit" value={sel.duration} options={DURATIONS} onChange={(v) => set({ duration: v })} />
          <Seg label="Difficulty" value={sel.difficulty} options={DIFF_OPTS} onChange={(v) => set({ difficulty: v })} />
        </div>
        <p className="setup-rule-note">No goalkeeper. Play the boards. If the clock ends level, the next goal wins.</p>
      </div>
      <div className="setup-footer"><span>THE COURT IS YOURS</span><Btn variant="primary" onClick={onStart}>ENTER THE CAGE <span aria-hidden="true">&rarr;</span></Btn></div>
    </ScreenFrame>
  );
}

// ------------------------------------------------------------------ free kick
export function FreeKickScreen({ onBack, onStart }: { onBack: () => void; onStart: () => void }) {
  const { sel, set, save } = useSel();
  const home = getTeam(sel.home);
  const away = getTeam(sel.away);
  return (
    <ScreenFrame title="Free kicks" eyebrow="BEHIND THE BALL" subtitle={`A wall, a keeper and one good idea. Personal best: ${save.stats.freeKickBest}.`} onBack={onBack}>
      <div className="setup-matchup">
        <div className="setup-side" style={{ '--side-color': home.primary } as CSSProperties}><Crest team={home} size={47} /><div><small>YOUR TAKER</small><strong>{home.name}</strong></div></div>
        <div className="setup-versus">V</div>
        <div className="setup-side setup-side-away" style={{ '--side-color': away.primary } as CSSProperties}><Crest team={away} size={47} /><div><small>THE WALL</small><strong>{away.name}</strong></div></div>
      </div>
      <div className="setup-pickers">
        <TeamGrid title="01 / Choose your kit" value={sel.home} onChange={(id) => set({ home: id, away: sel.away === id ? firstOther(id) : sel.away })} exclude={sel.away} />
        <TeamGrid title="02 / Choose the wall" value={sel.away} onChange={(id) => set({ away: id })} exclude={sel.home} />
      </div>
      <div className="setup-rules"><div className="setup-section-title"><span>03 / THE CHALLENGE</span><span>BEND IT AROUND THE WALL</span></div>
        <div className="setup-rule-grid">
          <Seg label="Keeper difficulty" value={sel.difficulty} options={DIFF_OPTS} onChange={(v) => set({ difficulty: v })} />
          <Seg label="Attempts" value={sel.attempts} options={[{ v: 5, label: '5' }, { v: 6, label: '6' }, { v: 8, label: '8' }]} onChange={(v) => set({ attempts: v })} />
        </div>
        <p className="setup-rule-note">Move the target with WASD. Q or E adds curve. Hold Strike to charge, release to shoot.</p>
      </div>
      <div className="setup-footer"><span>BEST: {save.stats.freeKickBest} GOALS</span><Btn variant="primary" onClick={onStart}>TAKE THE SHOT <span aria-hidden="true">&rarr;</span></Btn></div>
    </ScreenFrame>
  );
}

// ------------------------------------------------------------------ league / cup
function Table({ rows, userId, qualify = 0 }: { rows: Row[]; userId: string; qualify?: number }) {
  return (
    <div className="league-table">
      <table className="w-full text-sm">
        <thead>
          <tr className="bg-white/5 text-left text-[11px] tracking-widest text-slate-400">
            <th className="py-2 pl-3">#</th>
            <th>TEAM</th>
            {['P', 'W', 'D', 'L', 'GD', 'PTS'].map((h) => (
              <th key={h} className="px-1.5 text-center">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => {
            const t = getTeam(r.id);
            return (
              <tr key={r.id} className={`border-t border-white/5 ${r.id === userId ? 'bg-[var(--accent)]/10' : ''}`} style={i < qualify ? { boxShadow: 'inset 3px 0 0 #d5dd75' } : undefined}>
                <td className="py-1.5 pl-3 font-display text-slate-400">{i + 1}</td>
                <td>
                  <div className="flex items-center gap-2">
                    <Crest team={t} size={22} />
                    <span className="font-display text-base">{t.name}</span>
                  </div>
                </td>
                <td className="text-center">{r.p}</td>
                <td className="text-center">{r.w}</td>
                <td className="text-center">{r.d}</td>
                <td className="text-center">{r.l}</td>
                <td className="text-center">{r.gd > 0 ? `+${r.gd}` : r.gd}</td>
                <td className="px-2 text-center font-display text-lg text-lime-300">{r.pts}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function FxCard({ f, userId }: { f: Fx; userId: string }) {
  return (
    <div className="competition-fixture">
      {[f.a, f.b].map((id, i) => {
        const t = getTeam(id);
        const g = i === 0 ? f.ga : f.gb;
        const won = f.ga !== undefined && f.gb !== undefined && (i === 0 ? f.ga > f.gb : f.gb > f.ga);
        return (
          <div key={id} className={`flex items-center gap-2 px-2 py-1 ${id === userId ? 'text-[var(--accent)]' : ''} ${f.ga !== undefined && !won ? 'opacity-50' : ''}`}>
            <Crest team={t} size={24} />
            <span className="font-display flex-1 truncate">{t.name}</span>
            {g !== undefined && <span className="font-display text-xl">{g}</span>}
          </div>
        );
      })}
      {f.pens && <div className="text-center text-[10px] tracking-widest text-amber-300">AFTER EXTRA TIME</div>}
    </div>
  );
}

export function CompetitionScreen({ kind, onBack, onPlay }: { kind: 'league' | 'cup'; onBack: () => void; onPlay: (oppId: string, knockout: boolean) => void }) {
  const { sel, set, save } = useSel();
  const s: CompState | null = kind === 'league' ? save.league : save.cup;
  const list = kind === 'league' ? TEAMS : NATIONS;
  const [pick, setPick] = useState(list.some((t) => t.id === sel.home) ? sel.home : list[0].id);
  const [confirmAbandon, setConfirmAbandon] = useState(false);
  const title = kind === 'league' ? 'National League' : 'International Cup';
  const clear = () =>
    updateSave((d) => {
      if (kind === 'league') d.league = null;
      else d.cup = null;
    });

  if (!s) {
    return (
      <ScreenFrame title={title} eyebrow="PLAY THE LONG GAME" subtitle={kind === 'league' ? 'Play every club once. Three points for a win — finish top to be champions.' : 'Two groups of four, top two advance to the semifinals. Win the final to become world champions.'} onBack={onBack}>
        <div className="max-w-[600px]"><TeamGrid title={kind === 'league' ? '01 / Choose your club' : '01 / Choose your nation'} value={pick} onChange={setPick} list={list} /></div>
        <div className="setup-rules"><div className="setup-section-title"><span>02 / MATCH RULES</span><span>{kind === 'league' ? 'SEVEN MATCHDAYS' : 'GROUPS TO THE FINAL'}</span></div>
          <div className="setup-rule-grid">
          <Seg label="AI difficulty" value={sel.difficulty} options={DIFF_OPTS} onChange={(v) => set({ difficulty: v })} />
          <Seg label="Match duration" value={sel.duration} options={DURATIONS} onChange={(v) => set({ duration: v })} />
          </div>
        </div>
        <div className="setup-footer"><span>{kind === 'league' ? 'THE TABLE IS WAITING' : 'THE WORLD IS WATCHING'}</span><Btn variant="primary" onClick={() => updateSave((d) => { if (kind === 'league') { d.league = createLeague(pick); d.selection.home = pick; } else d.cup = createCup(pick); })}>START {kind === 'league' ? 'SEASON' : 'CUP'} <span aria-hidden="true">&rarr;</span></Btn></div>
      </ScreenFrame>
    );
  }

  const fx = nextFixture(s);
  const me = getTeam(s.teamId);
  const oppId = fx ? (fx.a === s.teamId ? fx.b : fx.a) : null;
  const ordinal = (n: number) => `${n}${n === 1 ? 'st' : n === 2 ? 'nd' : n === 3 ? 'rd' : 'th'}`;
  const sub = s.status === 'active' ? `${stageLabel(s)} · you are ${me.name}` : s.status === 'champion' ? 'Champions!' : s.status === 'eliminated' ? 'Eliminated' : `Season complete · ${ordinal(userPlace(s))} place`;

  return (
    <ScreenFrame
      title={title}
      eyebrow="PLAY THE LONG GAME"
      subtitle={sub}
      onBack={onBack}
      wide
      right={confirmAbandon ? (
        <div className="flex gap-2"><Btn variant="danger" onClick={() => { clear(); setConfirmAbandon(false); }}>CONFIRM</Btn><Btn onClick={() => setConfirmAbandon(false)}>CANCEL</Btn></div>
      ) : <Btn variant="danger" onClick={() => setConfirmAbandon(true)}>{s.status === 'active' ? 'ABANDON' : kind === 'league' ? 'NEW SEASON' : 'NEW CUP'}</Btn>}
    >
        <div className={`grid gap-7 ${kind === 'cup' ? 'lg:grid-cols-2' : 'mx-auto max-w-3xl'}`}>
        {s.groups.map((_g, gi) => (
          <div key={gi}>
            {kind === 'cup' && <div className="label mb-1.5">Group {gi === 0 ? 'A' : 'B'}</div>}
            <Table rows={table(s, gi)} userId={s.teamId} qualify={kind === 'cup' ? 2 : 0} />
          </div>
        ))}
      </div>

      {kind === 'cup' && s.ko.length > 0 && (
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <div>
            <div className="label mb-1.5">Semifinals</div>
            <div className="grid gap-2">{s.ko[0].map((f, i) => <FxCard key={i} f={f} userId={s.teamId} />)}</div>
          </div>
          <div>
            <div className="label mb-1.5">Final</div>
            <div className="grid gap-2">{s.ko[1].length ? s.ko[1].map((f, i) => <FxCard key={i} f={f} userId={s.teamId} />) : <div className="bracket-pending">TO BE DECIDED</div>}</div>
          </div>
        </div>
      )}

      <div className="competition-next">
        {s.status === 'active' && oppId ? (
          <>
            <Crest team={me} size={50} />
            <span className="font-display text-3xl text-white/40">V</span>
            <Crest team={getTeam(oppId)} size={50} />
            <div>
              <div className="label">{stageLabel(s)}</div>
              <div className="font-display text-2xl">{me.name} V {getTeam(oppId).name}</div>
              <div className="text-sm text-slate-400">{isKnockout(s) ? 'Knockout — a draw goes to golden goal.' : 'A draw is a draw — one point each.'}</div>
            </div>
            <Btn variant="primary" className="ml-auto" onClick={() => onPlay(oppId, isKnockout(s))}>PLAY MATCH <span aria-hidden="true">&rarr;</span></Btn>
          </>
        ) : (
          <div className="flex items-center gap-4">
            <div className={`flex h-12 w-12 items-center justify-center rounded-full border ${s.status === 'champion' ? 'border-[var(--accent)] text-[var(--accent)]' : 'border-white/20 text-white/60'}`}>
              <Crest team={me} size={30} />
            </div>
            <div>
              <div className="font-display text-3xl">{s.status === 'champion' ? 'Champions!' : s.status === 'eliminated' ? 'Knocked out' : 'Season finished'}</div>
              <div className="text-slate-400">{s.status === 'champion' ? 'A big bonus was added to your profile.' : 'Start a new one to try again.'}</div>
            </div>
          </div>
        )}
      </div>
    </ScreenFrame>
  );
}
