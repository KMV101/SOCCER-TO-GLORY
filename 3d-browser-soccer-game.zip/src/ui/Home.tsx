import { useEffect, useState } from 'react';
import { getTeam, levelFromXp } from '../game/config';
import { audio } from '../game/audio';
import { DAILY_OBJECTIVES, claimDailyObjective, dailyValue } from '../game/progress';
import { useSave } from '../game/save';
import { LogoMark } from './common';

type Panel = 'modes' | 'daily' | null;

const MODE_GROUPS = [
  {
    label: '01 / MATCHDAY',
    links: [
      { id: 'quick', title: 'Quick match', detail: 'Choose the sides. Take the pitch.' },
      { id: 'street', title: 'Street football', detail: 'No keepers. Walls in play.' },
    ],
  },
  {
    label: '02 / THE LONG GAME',
    links: [
      { id: 'league', title: 'National league', detail: 'Seven matchdays. One table.' },
      { id: 'cup', title: 'International cup', detail: 'The group stage to the final.' },
      { id: 'tournament', title: 'Knockout cup', detail: 'Three wins to lift it.' },
    ],
  },
  {
    label: '03 / THE PRACTICE GROUND',
    links: [
      { id: 'freekick', title: 'Free kicks', detail: 'Pick your corner. Bend it there.' },
      { id: 'penalty', title: 'Penalties', detail: 'Five chances. Two sides of the ball.' },
      { id: 'training', title: 'Training', detail: 'Find your first touch.' },
    ],
  },
];

function Arrow({ diagonal = false }: { diagonal?: boolean }) {
  return diagonal ? (
    <svg width="17" height="17" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M4 16 16 4M6 4h10v10" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ) : (
    <svg width="21" height="21" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M3 12h17m-6-6 6 6-6 6" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export interface ResumeInfo { title: string; sub: string; onPlay: () => void }

export function HomeMenu({ go, onPlay, resume }: { go: (s: string) => void; onPlay: () => void; resume?: ResumeInfo | null }) {
  const [panel, setPanel] = useState<Panel>(null);
  const save = useSave();
  const home = getTeam(save.selection.home);
  const away = getTeam(save.selection.away);
  const level = levelFromXp(save.xp);
  const choosePanel = (value: Exclude<Panel, null>) => {
    audio.play('click', 0.65);
    setPanel((old) => old === value ? null : value);
  };
  const navigate = (screen: string) => {
    audio.play('click');
    go(screen);
  };
  useEffect(() => {
    if (!panel) return;
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape') setPanel(null); };
    window.addEventListener('keydown', close);
    return () => window.removeEventListener('keydown', close);
  }, [panel]);

  return (
    <div className="home-screen">
      <div className="home-image" style={{ backgroundImage: 'url(./images/sidenet-matchday.jpg)' }} aria-hidden="true" />
      <div className="home-grade" aria-hidden="true" />

      <header className="home-header">
        <button type="button" className="home-wordmark" onClick={() => setPanel(null)} aria-label="SideNet home">
          <LogoMark size={36} />
          <span>SIDENET<span className="home-wordmark-dot">.</span></span>
        </button>
        <nav className="home-nav" aria-label="Main navigation">
          <button type="button" className={panel === null ? 'active' : ''} onClick={() => setPanel(null)}>Home</button>
          <button type="button" className={panel === 'modes' ? 'active' : ''} onClick={() => choosePanel('modes')}>Modes</button>
          <button type="button" className={panel === 'daily' ? 'active' : ''} onClick={() => choosePanel('daily')}>Challenges</button>
          <button type="button" onClick={() => navigate('customize')}>Your player</button>
          <button type="button" onClick={() => navigate('settings')}>Settings</button>
        </nav>
        <button type="button" className="home-profile" onClick={() => navigate('customize')} title="Customize your player">
          <span className="home-profile-level">{String(level.level).padStart(2, '0')}</span>
          <span className="home-profile-name">{save.custom.name || 'ROOKIE'}<small>YOUR PLAYER</small></span>
        </button>
      </header>

      <main className="home-stage">
        <div className="home-hero">
          <div className="home-kicker"><span /> SMALL SIDES. BIG NIGHTS.</div>
          <h1>SIDE<br /><span>NET</span><i>.</i></h1>
          <p>Football after dark. Make the next touch count.</p>
          <div className="home-ctas">
            <button type="button" className="home-kickoff" onClick={onPlay}>
              <span>KICK OFF<small>{home.short} v {away.short} / {save.selection.duration / 60} MIN</small></span><Arrow />
            </button>
            <button type="button" className="home-browse" onClick={() => choosePanel('modes')}>
              Browse modes <Arrow diagonal />
            </button>
          </div>
        </div>
      </main>

      {panel && (
        <>
          <button type="button" className="home-panel-shade" aria-label="Close menu" onClick={() => setPanel(null)} />
          <aside className="home-panel" aria-label={panel === 'modes' ? 'Game modes' : 'Daily challenges'}>
            <div className="home-panel-top">
              <span className="home-panel-label">SIDENET / {panel === 'modes' ? 'PLAY' : 'DAILY'}</span>
              <button type="button" className="home-panel-close" onClick={() => setPanel(null)} aria-label="Close panel">CLOSE <span aria-hidden="true">x</span></button>
            </div>
            {panel === 'modes' ? (
              <div className="home-panel-body">
                <h2>Choose your game<span>.</span></h2>
                <p className="home-panel-intro">From a quick kickabout to a whole season. Your call.</p>
                {resume && (
                  <button type="button" className="home-resume" onClick={() => { audio.play('click'); resume.onPlay(); }}>
                    <span>CONTINUE YOUR RUN</span>
                    <strong>{resume.title}</strong>
                    <small>{resume.sub}</small>
                    <Arrow diagonal />
                  </button>
                )}
                {MODE_GROUPS.map((group) => (
                  <section className="home-mode-group" key={group.label}>
                    <h3>{group.label}</h3>
                    {group.links.map((link) => (
                      <button type="button" className="home-mode-item" key={link.id} onClick={() => navigate(link.id)}>
                        <span><strong>{link.title}</strong><small>{link.detail}</small></span>
                        <Arrow diagonal />
                      </button>
                    ))}
                  </section>
                ))}
                <div className="home-panel-tools">
                  <button type="button" onClick={() => navigate('customize')}>YOUR PLAYER <Arrow diagonal /></button>
                  <button type="button" onClick={() => navigate('settings')}>SETTINGS <Arrow diagonal /></button>
                </div>
              </div>
            ) : (
              <div className="home-panel-body">
                <h2>Today's work<span>.</span></h2>
                <p className="home-panel-intro">Three small things. A good reason for another match.</p>
                <div className="home-daily-list">
                  {DAILY_OBJECTIVES.map((objective, i) => {
                    const current = Math.min(objective.target, dailyValue(save.daily, objective.id));
                    const claimed = save.daily.claimed.includes(objective.id);
                    const ready = current >= objective.target;
                    return (
                      <div className="home-daily-row" key={objective.id}>
                        <div className="home-daily-number">0{i + 1}</div>
                        <div className="home-daily-content">
                          <strong>{objective.title}</strong>
                          <span>{objective.detail}</span>
                          <div className="home-daily-progress"><span style={{ width: `${100 * current / objective.target}%` }} /></div>
                          <small>{current}/{objective.target} &nbsp; / &nbsp; +{objective.xp} XP &nbsp; +{objective.coins} COINS</small>
                        </div>
                        <button
                          type="button"
                          disabled={!ready || claimed}
                          onClick={() => { if (claimDailyObjective(objective.id)) audio.play('tick'); }}
                          className="home-daily-claim"
                        >
                          {claimed ? 'DONE' : ready ? 'COLLECT' : 'LOCKED'}
                        </button>
                      </div>
                    );
                  })}
                </div>
                <div className="home-daily-footer">
                  <span>RECORD</span><strong>{save.stats.won} W &nbsp; {save.stats.drawn} D &nbsp; {save.stats.lost} L</strong>
                </div>
              </div>
            )}
          </aside>
        </>
      )}
    </div>
  );
}