import type { Rewards } from '../game/progress';
import { Btn, Icon } from './common';

/** Result card for score-attack skill games (Free Kick Challenge). */
export function SkillResultScreen({
  label, goals, total, rewards, onRetry, onMenu, bonus,
}: {
  label: string; goals: number; total: number; rewards: Rewards | null; onRetry: () => void; onMenu: () => void;
  bonus?: { claimed: boolean; onClaim: () => void };
}) {
  const ratio = goals / Math.max(1, total);
  const grade = ratio >= 0.85 ? 'Dead-ball specialist.' : ratio >= 0.65 ? 'You found the corners.' : ratio >= 0.4 ? 'Getting closer.' : 'One more round.';
  return (
    <div className="result-layer">
      <div className="result-panel result-skill scroll-thin">
        <div className="result-overline">SIDENET / {label.toUpperCase()}</div>
        <h2>{grade}</h2>
        <div className="result-skill-score">{goals}<span> / {total}</span><small>GOALS SCORED</small></div>
        <div className="result-skill-dots">
          {Array.from({ length: total }).map((_, i) => (
            <span key={i} className={i < goals ? 'is-goal' : ''} />
          ))}
        </div>
        {rewards && (
          <div className="result-rewards">
            <div><small>XP EARNED</small><strong>+{rewards.xp}</strong></div>
            <div><small>COINS EARNED</small><strong>+{rewards.coins}</strong></div>
            {rewards.levelAfter > rewards.levelBefore && (
              <div><small>LEVEL UP</small><strong>{rewards.levelBefore} &rarr; {rewards.levelAfter}</strong></div>
            )}
          </div>
        )}
        <div className="result-actions">
          <Btn variant="primary" onClick={onRetry}>TAKE ANOTHER ROUND <span aria-hidden="true">&rarr;</span></Btn>
          {bonus && rewards && (
            <Btn disabled={bonus.claimed} onClick={bonus.onClaim}>
              <Icon name="video" size={16} /> {bonus.claimed ? 'BONUS CLAIMED' : `WATCH AD / +${rewards.coins} COINS`}
            </Btn>
          )}
          <Btn onClick={onMenu}>MAIN MENU</Btn>
        </div>
      </div>
    </div>
  );
}
