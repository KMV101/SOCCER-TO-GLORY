import { useCallback, useEffect, useRef, useState } from 'react';
import { Engine, type EngineHud, type GameKind } from './game/engine';
import { TACTIC_LIST, getTeam, levelFromXp, teamPattern } from './game/config';
import type { MatchConfig, MatchResult } from './game/match';
import { audio } from './game/audio';
import { crazy } from './game/crazy';
import { ensureDaily, getSave, updateSave, useSave } from './game/save';
import { currentTournamentMatch, grantRewards, recordDailyMatch, recordTournamentResult, ROUND_NAMES, stadiumUnlocked, teamUnlocked, type Rewards } from './game/progress';
import { isKnockout, nextFixture, recordResult, stageLabel, userPlace } from './game/competition';
import { PenaltyScreen, QuickMatchScreen, TournamentScreen, TrainingScreen } from './ui/Screens';
import { HomeMenu, type ResumeInfo } from './ui/Home';
import { CompetitionScreen, FreeKickScreen, StreetScreen } from './ui/Modes';
import { CustomizeScreen, SettingsScreen } from './ui/Menus';
import { Hud, PauseMenu, ResultScreen } from './ui/Hud';
import { SkillResultScreen } from './ui/Skill';
import { MatchControls, type ControlMode } from './ui/MatchControls';
import { Btn } from './ui/common';

type Screen = 'menu' | 'quick' | 'street' | 'league' | 'cup' | 'tournament' | 'penalty' | 'freekick' | 'training' | 'customize' | 'settings' | 'playing' | 'result';
type Kind = 'quick' | 'street' | 'league' | 'cup' | 'tournament' | 'penalty' | 'freekick' | 'training';

interface Session {
  kind: Kind;
  home: string;
  away: string;
}
interface ResultState {
  r: MatchResult;
  kind: Kind;
  rewards: Rewards | null;
  home: string;
  away: string;
  note?: string;
}

const ordinal = (n: number) => `${n}${n === 1 ? 'st' : n === 2 ? 'nd' : n === 3 ? 'rd' : 'th'}`;
const NEXT_SCREEN: Partial<Record<Kind, Screen>> = { tournament: 'tournament', league: 'league', cup: 'cup' };

export default function App() {
  const save = useSave();
  const hostRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const [screen, setScreen] = useState<Screen>('menu');
  const screenRef = useRef<Screen>('menu');
  const [hud, setHud] = useState<EngineHud | null>(null);
  const [paused, setPaused] = useState(false);
  const blurPause = useRef(false);
  const [fps, setFps] = useState(0);
  const [result, setResult] = useState<ResultState | null>(null);
  const [bonusClaimed, setBonusClaimed] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [adBusy, setAdBusy] = useState(false);
  const session = useRef<Session>({ kind: 'quick', home: 'mumbai', away: 'london' });

  const go = useCallback((s: Screen) => {
    screenRef.current = s;
    setScreen(s);
  }, []);

  const showToast = useCallback((m: string) => {
    setToast(m);
    window.setTimeout(() => setToast((t) => (t === m ? null : t)), 4500);
  }, []);

  // ---------------------------------------------------------------- engine + SDK lifecycle
  useEffect(() => {
    ensureDaily();
    crazy.loadingStart();
    crazy.setAdListener((running) => {
      setAdBusy(running);
      if (running) {
        blurPause.current = true;
        if (screenRef.current === 'playing') {
          setPaused(true);
          engineRef.current?.setPaused(true);
        }
      }
    });
    void crazy.init();

    const engine = new Engine();
    engineRef.current = engine;
    engine.onHud = (h) => setHud(h);
    engine.onFps = setFps;
    engine.onError = setError;
    engine.onFinish = (r, gk) => finish(r, gk);
    engine.onPauseRequested = () => {
      if (screenRef.current !== 'playing') return;
      blurPause.current = false;
      const next = !engine.paused;
      engine.setPaused(next);
      setPaused(next);
    };
    engine.onSlow = () => {
      const s = getSave().settings;
      if (s.quality === 'LOW') return;
      const next = s.quality === 'HIGH' ? 'MEDIUM' : 'LOW';
      updateSave((d) => void (d.settings.quality = next));
      showToast(`Performance mode: graphics lowered to ${next}. You can change this in Settings.`);
    };
    try {
      engine.mount(hostRef.current!, getSave().settings);
    } catch (e) {
      setError(String(e));
    }
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    engineRef.current?.setSettings(save.settings);
  }, [save.settings]);

  useEffect(() => {
    const timer = window.setInterval(() => ensureDaily(), 60_000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    const st = stadiumUnlocked(save.selection.stadium) ? save.selection.stadium : 'neon';
    engineRef.current?.setStadium(st);
  }, [save.selection.stadium, save.unlocked]);

  // CrazyGames gameplay start/stop – only while actually playing (not in menus / pause / results)
  useEffect(() => {
    crazy.gameplay(screen === 'playing' && (!paused || blurPause.current));
  }, [screen, paused]);

  // audio unlock + music
  useEffect(() => {
    const unlock = () => {
      audio.unlock();
      if (screenRef.current !== 'playing' && screenRef.current !== 'result') audio.startMusic();
    };
    window.addEventListener('pointerdown', unlock);
    window.addEventListener('keydown', unlock);
    window.addEventListener('touchend', unlock);
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
      window.removeEventListener('touchend', unlock);
    };
  }, []);

  // ---------------------------------------------------------------- game start helpers
  const kitFor = (teamId: string) => {
    const c = getSave().custom;
    const t = getTeam(teamId);
    return c.useCustomKit ? { primary: c.primary, secondary: c.secondary, pattern: 0 } : { primary: t.primary, secondary: t.secondary, pattern: teamPattern(t.id) };
  };

  // 3D hero player on the home screen, rotating preview in the customizer
  useEffect(() => {
    const eng = engineRef.current;
    if (!eng) return;
    if (screen === 'menu') eng.setPreview(save.custom, kitFor(save.selection.home), 'hero');
    else if (screen !== 'customize') eng.setPreview(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen, save.custom, save.selection.home]);

  const matchConfig = (home: string, away: string, knockout: boolean, mode: 'match' | 'training' = 'match', street = false): MatchConfig => {
    const s = getSave();
    return {
      mode, home: getTeam(home), away: getTeam(away),
      homeKit: kitFor(home),
      size: mode === 'training' ? 3 : street ? s.selection.streetSize : s.selection.size,
      duration: s.selection.duration,
      difficulty: s.selection.difficulty,
      tactic: s.selection.tactic,
      knockout: knockout || street,
      street,
      goalTarget: street ? s.selection.streetGoals : undefined,
      custom: s.custom, level: levelFromXp(s.xp).level, settings: s.settings,
    };
  };
  const stadium = () => {
    const id = getSave().selection.stadium;
    return stadiumUnlocked(id) ? id : 'neon';
  };

  const beginMatch = (kind: Kind, home: string, away: string, knockout = false, street = false) => {
    audio.unlock();
    blurPause.current = false;
    session.current = { kind, home, away };
    setHud(null);
    setPaused(false);
    setBonusClaimed(false);
    go('playing');
    engineRef.current?.startMatch(matchConfig(home, away, knockout, kind === 'training' ? 'training' : 'match', street), stadium());
  };
  const beginPenalty = () => {
    audio.unlock();
    blurPause.current = false;
    const s = getSave();
    const home = s.selection.home;
    const away = s.selection.away;
    session.current = { kind: 'penalty', home, away };
    setHud(null);
    setPaused(false);
    setBonusClaimed(false);
    go('playing');
    engineRef.current?.startPenalty(
      { home: getTeam(home), away: getTeam(away), homeKit: kitFor(home), difficulty: s.selection.difficulty, custom: s.custom, level: levelFromXp(s.xp).level, settings: s.settings },
      stadium(),
    );
  };
  const beginFreeKick = () => {
    audio.unlock();
    blurPause.current = false;
    const s = getSave();
    const home = s.selection.home;
    const away = s.selection.away === home ? 'london' : s.selection.away;
    session.current = { kind: 'freekick', home, away };
    setHud(null);
    setPaused(false);
    setBonusClaimed(false);
    go('playing');
    engineRef.current?.startFreeKick(
      { home: getTeam(home), away: getTeam(away), homeKit: kitFor(home), difficulty: s.selection.difficulty, custom: s.custom, level: levelFromXp(s.xp).level, attempts: s.selection.attempts, settings: s.settings },
      stadium(),
    );
  };
  const playCompetition = (kind: 'league' | 'cup', oppId: string, knockout: boolean) => {
    const s = getSave();
    const st = kind === 'league' ? s.league : s.cup;
    if (st) beginMatch(kind, st.teamId, oppId, knockout);
  };

  const quickPlay = () => {
    const s = getSave();
    const home = teamUnlocked(s.selection.home) ? s.selection.home : 'mumbai';
    let away = s.selection.away;
    if (away === home || !teamUnlocked(away)) away = ['london', 'madrid', 'tokyo', 'rio', 'berlin'].find((t) => t !== home)!;
    beginMatch('quick', home, away);
  };

  // ---------------------------------------------------------------- game finished
  function finish(r: MatchResult, gk: GameKind) {
    const sess = session.current;
    if (gk === 'training') return;
    let rewards: Rewards | null = null;
    let note: string | undefined;
    const userWon = r.winner === 0;
    if (gk === 'match') recordDailyMatch(r.homeScore, userWon, sess.kind === 'street');
    if (gk === 'freekick') {
      const goals = r.homeScore;
      const total = r.awayScore;
      const before = levelFromXp(getSave().xp).level;
      const xp = 20 + goals * 15;
      const coins = 10 + goals * 20;
      updateSave((d) => {
        d.xp += xp;
        d.coins += coins;
        d.stats.freeKickBest = Math.max(d.stats.freeKickBest, goals);
      });
      rewards = { xp, coins, levelBefore: before, levelAfter: levelFromXp(getSave().xp).level };
      if (goals * 2 >= total) crazy.happy();
    } else if (gk === 'penalty') {
      rewards = grantRewards(userWon ? 'win' : 'loss', 0, 1, userWon ? 20 : 0);
      if (userWon) updateSave((d) => void (d.stats.penaltiesScored += r.homeScore));
      if (userWon) crazy.happy();
    } else {
      const res = r.winner === 0 ? 'win' : r.winner === 1 ? 'loss' : 'draw';
      const bonus = sess.kind === 'tournament' || sess.kind === 'cup' || sess.kind === 'league' ? 20 : sess.kind === 'street' ? 10 : 0;
      rewards = grantRewards(res, r.homeScore, r.awayScore, bonus);
      if (sess.kind === 'tournament') {
        recordTournamentResult(r.homeScore, r.awayScore, r.pens ? r.winner === 0 : null);
        const t = getSave().tournament;
        if (t?.status === 'champion') {
          updateSave((d) => {
            d.coins += 300;
            d.xp += 150;
          });
          note = 'TOURNAMENT CHAMPIONS. +300 coins, +150 XP';
        } else if (t?.status === 'eliminated') note = 'You have been knocked out of the tournament.';
        else note = 'You advance to the next round!';
      } else if (sess.kind === 'league' || sess.kind === 'cup') {
        recordResult(sess.kind, r.homeScore, r.awayScore, userWon);
        const st = sess.kind === 'league' ? getSave().league : getSave().cup;
        if (st) {
          if (st.status === 'champion') {
            updateSave((d) => {
              d.coins += 300;
              d.xp += 150;
            });
            note = sess.kind === 'league' ? 'LEAGUE CHAMPIONS. +300 coins, +150 XP' : 'WORLD CHAMPIONS. +300 coins, +150 XP';
          } else if (st.status === 'eliminated') note = 'You have been knocked out of the cup.';
          else if (st.status === 'finished') note = `Season over — you finished ${ordinal(userPlace(st))}.`;
          else note = sess.kind === 'league' ? 'On to the next matchday!' : 'Onwards to the next fixture!';
        }
      }
      if (userWon) crazy.happy();
    }
    setResult({ r, kind: sess.kind, rewards, home: sess.home, away: sess.away, note });
    setBonusClaimed(false);
    setPaused(false);
    engineRef.current?.setPaused(true);
    go('result');
  }

  const toMenu = () => {
    engineRef.current?.quitToMenu();
    setHud(null);
    setPaused(false);
    setResult(null);
    go('menu');
    audio.startMusic();
  };
  const toScreen = (s: Screen) => {
    engineRef.current?.quitToMenu();
    setHud(null);
    setResult(null);
    go(s);
    audio.startMusic();
  };

  /** run an action after a (possible) midgame ad – used between matches only */
  const afterAd = async (fn: () => void) => {
    await crazy.ad('midgame');
    fn();
  };

  const togglePause = useCallback(() => {
    if (screenRef.current !== 'playing') return;
    blurPause.current = false;
    const engine = engineRef.current;
    if (!engine) return;
    const next = !engine.paused;
    engine.setPaused(next);
    setPaused(next);
  }, []);

  // keyboard shortcuts (pause, tactics, half-time continue)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (screenRef.current !== 'playing') return;
      if (e.repeat) return;
      if (e.code === 'Escape' || e.code === 'KeyP') {
        togglePause();
        return;
      }
      if (e.code === 'Enter') engineRef.current?.continueHalftime();
      const n = Number(e.key);
      if (n >= 1 && n <= 5 && engineRef.current?.match && !engineRef.current.paused) {
        const t = TACTIC_LIST[n - 1];
        engineRef.current.setTactic(t);
        updateSave((d) => void (d.selection.tactic = t));
        audio.play('tick', 0.6);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [togglePause]);

  // auto-pause when the tab / iframe loses focus mid-game (does NOT report gameplayStop – the portal handles that)
  useEffect(() => {
    const onBlur = () => {
      if (screenRef.current === 'playing') {
        blurPause.current = true;
        setPaused(true);
        engineRef.current?.setPaused(true);
      }
    };
    window.addEventListener('blur', onBlur);
    return () => window.removeEventListener('blur', onBlur);
  }, []);

  const restartCurrent = () => {
    setResult(null);
    setPaused(false);
    setHud(null);
    blurPause.current = false;
    go('playing');
    engineRef.current?.setPaused(false);
    engineRef.current?.restart();
  };

  const claimBonus = async () => {
    const ok = await crazy.ad('rewarded');
    if (ok && result?.rewards) {
      const extra = result.rewards.coins;
      updateSave((d) => void (d.coins += extra));
      setBonusClaimed(true);
      showToast(`+${extra} bonus coins!`);
    }
  };
  const bonus = crazy.active && result?.rewards ? { claimed: bonusClaimed, onClaim: () => void claimBonus() } : undefined;

  const sel = save.selection;
  const playing = screen === 'playing' || screen === 'result';
  const controlMode: ControlMode | null = (() => {
    if (!hud) return null;
    if (hud.mode === 'match' || hud.mode === 'training') {
      if (hud.phase !== 'PLAY') return null;
      if (hud.setPiece && (hud.setPiece.team !== 0 || hud.setPiece.state !== 'ready')) return null;
      return 'match';
    }
    if (hud.mode === 'freekick') return hud.fk?.stage === 'AIM' ? 'freekick' : null;
    if (hud.mode === 'penalty') {
      if (hud.pen?.role === 'keep') return hud.pen.stage === 'RUNUP' || hud.pen.stage === 'FLIGHT' ? 'penalty-keeper' : null;
      return hud.pen?.stage === 'AIM' ? 'penalty-shot' : null;
    }
    return null;
  })();

  /** "continue" entry point: the next unfinished fixture in whichever competition is running */
  const resume: ResumeInfo | null = (() => {
    for (const kind of ['league', 'cup'] as const) {
      const st = kind === 'league' ? save.league : save.cup;
      if (!st || st.status !== 'active') continue;
      const f = nextFixture(st);
      if (!f) continue;
      const opp = f.a === st.teamId ? f.b : f.a;
      return {
        title: stageLabel(st),
        sub: `${getTeam(st.teamId).name} vs ${getTeam(opp).name}`,
        onPlay: () => playCompetition(kind, opp, isKnockout(st)),
      };
    }
    const t = save.tournament;
    if (t && t.status === 'active') {
      const m = currentTournamentMatch(t);
      if (m) {
        const opp = m.a === t.teamId ? m.b : m.a;
        return {
          title: ROUND_NAMES[t.round],
          sub: `${getTeam(t.teamId).name} vs ${getTeam(opp).name}`,
          onPlay: () => beginMatch('tournament', t.teamId, opp, true),
        };
      }
    }
    return null;
  })();

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#0b100e]">
      <div ref={hostRef} className="absolute inset-0" />
      {/* cinematic vignette */}
      <div className="pointer-events-none absolute inset-0" style={{ background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(2,6,18,0.55) 100%)' }} />

      {screen === 'menu' && <HomeMenu go={(s) => go(s as Screen)} onPlay={quickPlay} resume={resume} />}
      {screen === 'quick' && <QuickMatchScreen onBack={() => go('menu')} onStart={() => beginMatch('quick', sel.home, sel.away)} />}
      {screen === 'street' && <StreetScreen onBack={() => go('menu')} onStart={() => beginMatch('street', sel.home, sel.away === sel.home ? 'london' : sel.away, true, true)} />}
      {screen === 'league' && <CompetitionScreen kind="league" onBack={() => go('menu')} onPlay={(opp, ko) => playCompetition('league', opp, ko)} />}
      {screen === 'cup' && <CompetitionScreen kind="cup" onBack={() => go('menu')} onPlay={(opp, ko) => playCompetition('cup', opp, ko)} />}
      {screen === 'tournament' && (
        <TournamentScreen
          onBack={() => go('menu')}
          onPlay={(opp) => {
            const t = getSave().tournament;
            if (t) beginMatch('tournament', t.teamId, opp, true);
          }}
        />
      )}
      {screen === 'penalty' && <PenaltyScreen onBack={() => go('menu')} onStart={beginPenalty} />}
      {screen === 'freekick' && <FreeKickScreen onBack={() => go('menu')} onStart={beginFreeKick} />}
      {screen === 'training' && <TrainingScreen onBack={() => go('menu')} onStart={() => beginMatch('training', sel.home, sel.away === sel.home ? 'london' : sel.away)} />}
      {screen === 'customize' && <CustomizeScreen onBack={() => go('menu')} onPreview={(c, kit) => engineRef.current?.setPreview(c, kit, 'preview')} />}
      {screen === 'settings' && <SettingsScreen onBack={() => go('menu')} />}

      {playing && hud && engineRef.current && <Hud hud={hud} engine={engineRef.current} fps={fps} showFps={save.settings.showFps} />}

      {screen === 'playing' && !paused && controlMode && engineRef.current && (
        <MatchControls key={controlMode} engine={engineRef.current} mode={controlMode} training={hud?.mode === 'training'} canSwitch={hud?.canSwitch ?? true} attacking={hud?.attacking ?? true} keeperDived={hud?.pen?.diveUsed ?? false} />
      )}

      {screen === 'playing' && (
        <button type="button" className="hud-pause" aria-label="Pause match" onPointerDown={(e) => e.preventDefault()} onClick={togglePause}>
          <span aria-hidden="true"><i /><i /></span> PAUSE
        </button>
      )}

      {screen === 'playing' && paused && engineRef.current && (
        <PauseMenu engine={engineRef.current} mode={hud?.mode ?? 'match'} onResume={togglePause} onRestart={restartCurrent} onQuit={toMenu} />
      )}

      {screen === 'result' && result && result.kind === 'freekick' && (
        <SkillResultScreen
          label="Free Kick Challenge"
          goals={result.r.homeScore}
          total={result.r.awayScore}
          rewards={result.rewards}
          onRetry={() => void afterAd(restartCurrent)}
          onMenu={() => void afterAd(toMenu)}
          bonus={bonus}
        />
      )}

      {screen === 'result' && result && result.kind !== 'freekick' && (
        <ResultScreen
          result={result.r}
          rewards={result.rewards}
          homeName={getTeam(result.home).name}
          awayName={getTeam(result.away).name}
          kind={result.kind === 'penalty' ? 'penalty' : 'match'}
          tournamentNote={result.note}
          continueLabel={NEXT_SCREEN[result.kind] ? (result.kind === 'tournament' ? 'Back to bracket' : 'Back to table') : 'Continue'}
          onContinue={() => void afterAd(() => toScreen(NEXT_SCREEN[result.kind] ?? 'menu'))}
          onRematch={NEXT_SCREEN[result.kind] ? undefined : () => void afterAd(restartCurrent)}
          onMenu={() => void afterAd(toMenu)}
          bonus={bonus}
        />
      )}

      {toast && (
        <div className="pointer-events-none absolute inset-x-0 top-16 z-40 flex justify-center px-4">
          <div className="anim-pop rounded-xl border border-cyan-300/40 bg-black/80 px-5 py-2 text-center text-sm text-cyan-100 shadow-xl backdrop-blur">{toast}</div>
        </div>
      )}

      {adBusy && <div className="absolute inset-0 z-50 bg-black/80" />}

      {error && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 p-6">
          <div className="glass max-w-md space-y-4 rounded-2xl p-6 text-center">
            <h2 className="font-display text-3xl text-red-300">Something went wrong</h2>
            <p className="break-words text-sm text-slate-300">{error}</p>
            <div className="flex justify-center gap-3">
              <Btn variant="primary" onClick={() => location.reload()}>Reload</Btn>
              <Btn onClick={() => setError(null)}>Dismiss</Btn>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
