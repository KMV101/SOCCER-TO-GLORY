import {
  AdditiveBlending, BufferAttribute, BufferGeometry, CircleGeometry, Color, ConeGeometry, CylinderGeometry, DoubleSide, Group, Mesh, MeshBasicMaterial, MeshStandardMaterial,
  PCFSoftShadowMap, PerspectiveCamera, Points, PointsMaterial, RingGeometry, SRGBColorSpace, ACESFilmicToneMapping, Vector3, WebGLRenderer, type Material,
} from 'three';
import { getStadium, makePitch, type PitchSpec } from './config';
import { Footballer, angDiff } from './entities';
import { Input } from './input';
import { Match, type HudState, type MatchConfig, type MatchResult } from './match';
import { PenaltyGame, type PenaltyConfig, type PenHud } from './penalty';
import { FreeKickGame, type FkHud, type FreeKickConfig } from './freekick';
import { QUALITY, World, type QualityCfg } from './stadium';
import { audio } from './audio';
import { createBallMesh, hairColorFor, setCharacterQuality, type KitSpec } from './models';
import type { CameraMode, Custom, Quality, Settings } from './save';

export type EngineHud = HudState & { pen?: PenHud; fk?: FkHud };
export type GameKind = 'match' | 'penalty' | 'training' | 'freekick';
type PreviewKit = { primary: string; secondary: string; pattern?: number };

const CAM: Record<CameraMode, { dist: number; height: number; fov: number }> = {
  BROADCAST: { dist: 30, height: 20, fov: 46 },
  CLASSIC: { dist: 13.5, height: 8.6, fov: 52 },
  CLOSE: { dist: 9, height: 5.6, fov: 55 },
  WIDE: { dist: 20, height: 13, fov: 50 },
};

const SKINS = ['#f6d3b3', '#e8b48a', '#c98e62', '#a46a43', '#7a4a2d', '#4d2e1c'];
const BOOTS: Record<string, string> = { black: '#15171c', white: '#f1f3f6', orange: '#ff7a1a', lime: '#b6ff2e', gold: '#f4c430', pink: '#ff3d9a' };
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export class Engine {
  renderer!: WebGLRenderer;
  camera = new PerspectiveCamera(55, 1, 0.3, 700);
  input = new Input();
  world: World | null = null;
  match: Match | null = null;
  penalty: PenaltyGame | null = null;
  freekick: FreeKickGame | null = null;
  mode: 'menu' | GameKind = 'menu';
  settings!: Settings;
  paused = false;
  onHud: ((h: EngineHud) => void) | null = null;
  onFinish: ((r: MatchResult, k: GameKind) => void) | null = null;
  onFps: ((fps: number) => void) | null = null;
  onError: ((msg: string) => void) | null = null;
  onPauseRequested: (() => void) | null = null;
  /** fired when the frame rate stays far below target (App lowers the quality preset) */
  onSlow: (() => void) | null = null;
  private slowT = 0;

  private container!: HTMLElement;
  private raf = 0;
  private last = 0;
  private hudT = 0;
  private fpsAcc = 0;
  private fpsFrames = 0;
  private mapT = 0;
  private minimap: HTMLCanvasElement | null = null;
  private stadiumId = 'neon';
  private menuStadium = 'neon';
  private worldSize = 3;
  private qualityKey: Quality = 'MEDIUM';
  private aa = true;
  private camPos = new Vector3(0, 10, -20);
  private camLook = new Vector3();
  private camYaw = Math.PI / 2;
  private focus = new Vector3();
  private tmp = new Vector3();
  private shake = 0;
  private restartFn: (() => void) | null = null;
  // menu props
  private heroBall: Mesh | null = null;
  private menuPlayers: Footballer[] = [];
  private particles: Points | null = null;
  private partVel: Float32Array | null = null;
  private preview: Footballer | null = null;
  private previewSpec: { custom: Custom; kit: PreviewKit; view: 'hero' | 'preview' } | null = null;
  private stage: Group | null = null;
  private feetBall: Mesh | null = null;
  private heroAct = 3;
  private menuView: 'orbit' | 'hero' | 'preview' = 'orbit';
  private menuT = 0;
  private resizeObs: ResizeObserver | null = null;
  private lost = false;

  mount(el: HTMLElement, settings: Settings) {
    this.container = el;
    this.settings = settings;
    this.qualityKey = settings.quality;
    this.aa = settings.quality !== 'LOW';
    this.applyCharacterQuality();
    this.makeRenderer();
    this.resizeObs = new ResizeObserver(() => this.resize());
    this.resizeObs.observe(el);
    this.applyAudio();
    this.rebuildWorld(this.menuStadium, 3);
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  private makeRenderer() {
    if (this.renderer) {
      this.renderer.dispose();
      this.renderer.domElement.remove();
    }
    const r = new WebGLRenderer({ antialias: this.aa, powerPreference: 'high-performance', alpha: false });
    r.outputColorSpace = SRGBColorSpace;
    r.toneMapping = ACESFilmicToneMapping;
    r.toneMappingExposure = 1.12;
    r.shadowMap.type = PCFSoftShadowMap;
    r.domElement.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;outline:none;touch-action:none;';
    r.domElement.tabIndex = 0;
    r.domElement.addEventListener('webglcontextlost', (e) => {
      e.preventDefault();
      this.lost = true;
      this.onError?.('Graphics context lost – try lowering quality in Settings.');
    });
    r.domElement.addEventListener('webglcontextrestored', () => {
      this.lost = false;
    });
    this.container.prepend(r.domElement);
    this.renderer = r;
    this.input.attach(r.domElement);
    this.resize();
  }

  private qcfg(): QualityCfg {
    return QUALITY[this.settings.quality];
  }
  /** Character shading: standard (soft) on MEDIUM/HIGH, Lambert on LOW. */
  private applyCharacterQuality() {
    setCharacterQuality(this.settings.quality !== 'LOW');
  }

  private resize() {
    if (!this.renderer || !this.container) return;
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);
    const pr = Math.min(window.devicePixelRatio || 1, this.qcfg().pixelCap) * this.settings.resScale;
    this.renderer.setPixelRatio(pr);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  private applyAudio() {
    const s = this.settings;
    audio.setVolumes({ master: s.master, music: s.music, sfx: s.sfx, crowd: s.crowd });
    this.input.useGamepad = s.gamepad;
  }

  /** Apply (possibly changed) settings. Rebuilds the world if graphics quality changed. */
  setSettings(s: Settings) {
    const prevQ = this.settings.quality;
    this.settings = s;
    this.applyAudio();
    const needAA = s.quality !== 'LOW';
    if (needAA !== this.aa) {
      this.aa = needAA;
      this.makeRenderer();
    }
    if (s.quality !== prevQ || s.quality !== this.qualityKey) {
      this.applyCharacterQuality();
      // rebuild immediately in the menu; otherwise the new quality applies from the next game
      if (this.mode === 'menu') this.rebuildWorld(this.menuStadium, 3, true);
      else if (this.world) this.world.sun.castShadow = this.world.sun.castShadow && this.qcfg().shadows;
    }
    this.resize();
  }

  private rebuildWorld(stadium: string, size: number, force = false) {
    if (!force && this.world && this.stadiumId === stadium && this.worldSize === size && this.qualityKey === this.settings.quality) return;
    this.disposeMenuProps();
    this.world?.dispose();
    this.stadiumId = stadium;
    this.worldSize = size;
    this.qualityKey = this.settings.quality;
    const q = this.qcfg();
    this.renderer.shadowMap.enabled = q.shadows;
    const theme = getStadium(stadium);
    this.world = new World(theme, makePitch(size, !!theme.street), q);
    this.buildMenuProps();
  }

  // ------------------------------------------------------------------ menu background
  private disposeMenuProps() {
    this.menuPlayers.forEach((p) => p.dispose());
    this.menuPlayers = [];
    this.clearPreview();
    if (this.heroBall) {
      this.heroBall.geometry.dispose();
      this.heroBall = null;
    }
    if (this.particles) {
      this.particles.geometry.dispose();
      (this.particles.material as PointsMaterial).dispose();
      this.particles = null;
    }
  }

  private buildMenuProps() {
    const w = this.world!;
    const g = w.menuGroup;
    this.heroBall = createBallMesh(1.0);
    this.heroBall.position.set(0, 1.5, 0);
    g.add(this.heroBall);
    const shadows = this.qcfg().shadows;
    const silKit = (n: number): KitSpec => ({ primary: '#000', secondary: '#000', shorts: '#000', socks: '#000', boots: '#000', skin: '#000', hairColor: '#000', hair: n % 5, number: n, silhouette: true });
    const defs = [
      { a: 0.2, r: 11, act: 'CELEBRATE' },
      { a: 1.1, r: 9, act: 'IDLE' },
      { a: 2.0, r: 12, act: 'KICK' },
      { a: 3.1, r: 10, act: 'IDLE' },
      { a: 4.1, r: 12, act: 'CELEBRATE' },
      { a: 5.2, r: 9.5, act: 'RUN' },
    ];
    const fake = { id: 'm', name: '', number: 7, pos: 'MID' as const, archetype: 'Speedster' as const, hair: 0, skin: 0, stats: { speed: 80, acceleration: 80, shooting: 70, passing: 70, dribbling: 70, defending: 50, physical: 60, stamina: 80, ballControl: 70 } };
    defs.forEach((d, i) => {
      const p = new Footballer({ ...fake, hair: i % 5 }, 0, i, silKit(i), shadows);
      p.place(Math.cos(d.a) * d.r, Math.sin(d.a) * d.r, Math.atan2(-Math.cos(d.a), -Math.sin(d.a)));
      p.stamina = 100;
      p.home.set(d.a, d.r, i); // stash params
      (p as unknown as { menuAct: string }).menuAct = d.act;
      g.add(p.group);
      this.menuPlayers.push(p);
    });
    const n = 160;
    const pos = new Float32Array(n * 3);
    this.partVel = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 60;
      pos[i * 3 + 1] = Math.random() * 14;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 60;
      this.partVel[i] = 0.2 + Math.random() * 0.6;
    }
    const geo = new BufferGeometry();
    geo.setAttribute('position', new BufferAttribute(pos, 3));
    const mat = new PointsMaterial({ color: new Color(w.theme.accent), size: 0.16, transparent: true, opacity: 0.7, blending: AdditiveBlending, depthWrite: false });
    this.particles = new Points(geo, mat);
    this.particles.frustumCulled = false;
    g.add(this.particles);
    this.createPreview();
  }

  private clearPreview() {
    this.preview?.dispose();
    this.preview = null;
    if (this.stage) {
      this.stage.traverse((o) => {
        const m = o as Mesh;
        if (m.isMesh) {
          m.geometry.dispose();
          (m.material as Material).dispose();
        }
      });
      this.stage.removeFromParent();
      this.stage = null;
    }
    if (this.feetBall) {
      this.feetBall.geometry.dispose();
      (this.feetBall.material as Material).dispose();
      this.feetBall.removeFromParent();
      this.feetBall = null;
    }
  }

  /** Show the player's 3D character on a lit stage in the menu background (null = orbit view). */
  setPreview(custom: Custom | null, kit?: PreviewKit, view: 'hero' | 'preview' = 'preview') {
    this.previewSpec = custom && kit ? { custom, kit, view } : null;
    this.menuView = this.previewSpec ? view : 'orbit';
    this.createPreview();
  }

  private createPreview() {
    this.clearPreview();
    const w = this.world;
    const spec = this.previewSpec;
    if (!w || !spec) return;
    const { custom, kit, view } = spec;
    const k: KitSpec = {
      primary: kit.primary, secondary: kit.secondary, shorts: kit.secondary, socks: kit.primary, boots: BOOTS[custom.boots] ?? '#15171c',
      skin: SKINS[custom.skin % 6], hairColor: hairColorFor(custom.number + custom.skin), hair: custom.hair, number: custom.number, pattern: kit.pattern ?? 0,
    };
    const def = { id: 'pv', name: custom.name, number: custom.number, pos: 'MID' as const, archetype: 'Box-to-Box' as const, hair: custom.hair, skin: custom.skin, stats: { speed: 70, acceleration: 70, shooting: 70, passing: 70, dribbling: 70, defending: 70, physical: 70, stamina: 70, ballControl: 70 } };
    const p = new Footballer(def, 0, 0, k, this.qcfg().shadows);
    p.place(0, 6, 0);
    w.menuGroup.add(p.group);
    this.preview = p;

    const accent = new Color(w.theme.accent);
    const st = new Group();
    st.position.set(0, 0, 6);
    const base = new Mesh(new CylinderGeometry(1.5, 1.72, 0.16, 40), new MeshStandardMaterial({ color: '#10162a', metalness: 0.6, roughness: 0.35 }));
    base.position.y = 0.08;
    const ring = new Mesh(new RingGeometry(1.22, 1.4, 56).rotateX(-Math.PI / 2), new MeshBasicMaterial({ color: accent, transparent: true, opacity: 0.95, blending: AdditiveBlending, depthWrite: false }));
    ring.position.y = 0.17;
    const disc = new Mesh(new CircleGeometry(1.22, 56).rotateX(-Math.PI / 2), new MeshBasicMaterial({ color: accent, transparent: true, opacity: 0.14, blending: AdditiveBlending, depthWrite: false }));
    disc.position.y = 0.165;
    const beam = new Mesh(new ConeGeometry(2.3, 9, 28, 1, true).translate(0, 4.5, 0), new MeshBasicMaterial({ color: '#cfe8ff', transparent: true, opacity: 0.07, blending: AdditiveBlending, depthWrite: false, side: DoubleSide }));
    st.add(base, ring, disc, beam);
    w.menuGroup.add(st);
    this.stage = st;

    if (view === 'hero') {
      this.feetBall = createBallMesh(0.26);
      w.menuGroup.add(this.feetBall);
      this.heroAct = 3;
    }
  }

  private updateMenu(dt: number) {
    const w = this.world!;
    this.menuT += dt;
    const t = this.menuT;
    const cam = this.camera;
    const view = this.preview ? this.menuView : 'orbit';
    if (view !== 'orbit' && this.preview) {
      const p = this.preview;
      if (view === 'hero') {
        // idle showcase with the odd skill move / celebration
        this.heroAct -= dt;
        if (this.heroAct <= 0 && p.action === 'IDLE') {
          this.heroAct = 3.2 + Math.random() * 2.5;
          p.setAction(Math.random() < 0.55 ? 'SKILL' : 'CELEBRATE', Math.random() < 0.55 ? 0.6 : 1.8);
          p.skillCd = 0;
        }
        p.yaw = Math.sin(t * 0.45) * 0.55 + 0.15;
        p.step(dt, 1, false);
        p.pos.set(0, 0, 6);
        p.vel.set(0, 0, 0);
        p.sync();
        p.animate(dt);
        if (this.feetBall) {
          const fx = Math.sin(p.yaw) * 0.62;
          const fz = Math.cos(p.yaw) * 0.62;
          this.feetBall.position.set(fx, 0.26 + Math.max(0, Math.sin(t * 2.2)) * 0.05, 6 + fz);
          this.feetBall.rotation.x += dt * 0.6;
        }
        this.tmp.set(0.3 + Math.sin(t * 0.3) * 0.45, 1.5, 10.7);
        this.camPos.lerp(this.tmp, 1 - Math.exp(-2.5 * dt));
        this.camLook.lerp(this.tmp.set(0.85, 1.08, 6), 1 - Math.exp(-3 * dt));
        cam.fov = 40;
      } else {
        p.yaw += dt * 0.7;
        p.sync();
        p.animate(dt);
        this.tmp.set(Math.sin(t * 0.3) * 1.2, 1.5, 10.2);
        this.camPos.lerp(this.tmp, 1 - Math.exp(-2.5 * dt));
        this.camLook.lerp(this.tmp.set(-1.5, 1.05, 6), 1 - Math.exp(-3 * dt));
        cam.fov = 40;
      }
      if (this.heroBall) this.heroBall.visible = false;
      this.menuPlayers.forEach((m) => (m.group.visible = false));
      if (this.stage) this.stage.children[1].rotation.y += dt * 0.5;
    } else {
      const a = t * 0.07 + 0.6;
      const R = 17 + Math.sin(t * 0.2) * 2;
      this.tmp.set(Math.cos(a) * R, 3.8 + Math.sin(t * 0.35) * 0.8, Math.sin(a) * R);
      this.camPos.lerp(this.tmp, 1 - Math.exp(-2 * dt));
      this.camLook.lerp(this.tmp.set(0, 1.9, 0), 1 - Math.exp(-3 * dt));
      cam.fov = 50;
      if (this.heroBall) {
        this.heroBall.visible = true;
        this.heroBall.rotation.y += dt * 0.6;
        this.heroBall.rotation.x += dt * 0.25;
        this.heroBall.position.y = 1.7 + Math.sin(t * 1.3) * 0.25;
      }
      for (const p of this.menuPlayers) {
        p.group.visible = true;
        const act = (p as unknown as { menuAct: string }).menuAct;
        const h = p.home;
        if (act === 'RUN') {
          const ang = h.x + t * 0.35;
          const nx = Math.cos(ang) * h.y;
          const nz = Math.sin(ang) * h.y;
          p.moveDir.set(nx - p.pos.x, 0, nz - p.pos.z).setLength(0.9);
          p.sprint = false;
          p.step(dt, 1, false);
        } else if (act === 'CELEBRATE' && p.action !== 'CELEBRATE') p.setAction('CELEBRATE', 3.2);
        else if (act === 'KICK' && p.action !== 'KICK' && Math.random() < dt * 0.35) p.setAction('KICK', 0.45, 0.9);
        if (act !== 'RUN') p.step(dt, 1, false);
        p.animate(dt);
      }
      if (this.particles && this.partVel) {
        const pos = this.particles.geometry.attributes.position as BufferAttribute;
        for (let i = 0; i < pos.count; i++) {
          let y = pos.getY(i) + this.partVel[i] * dt;
          if (y > 14) y = 0;
          pos.setY(i, y);
          pos.setX(i, pos.getX(i) + Math.sin(t * 0.5 + i) * dt * 0.2);
        }
        pos.needsUpdate = true;
      }
    }
    cam.position.copy(this.camPos);
    cam.lookAt(this.camLook);
    cam.updateProjectionMatrix();
    w.update(dt, this.tmp.set(0, 0, 0));
  }

  // ------------------------------------------------------------------ modes
  private enter(kind: GameKind, stadium: string, size: number) {
    this.input.suspend();
    this.leave();
    this.rebuildWorld(stadium, size);
    this.world!.menuGroup.visible = false;
    this.mode = kind;
    this.paused = false;
    this.input.enabled = true;
    this.camYaw = this.settings.camera === 'BROADCAST' ? Math.PI : Math.PI / 2;
    audio.stopMusic();
    audio.startCrowd();
    this.renderer.domElement.focus();
  }

  private leave() {
    this.match?.dispose();
    this.penalty?.dispose();
    this.freekick?.dispose();
    this.match = null;
    this.penalty = null;
    this.freekick = null;
  }

  startMatch(cfg: MatchConfig, stadium: string) {
    this.restartFn = () => this.startMatch(cfg, stadium);
    this.enter(cfg.mode === 'training' ? 'training' : 'match', cfg.street ? 'street' : stadium, cfg.size);
    const w = this.world!;
    const m = new Match({ ...cfg, settings: this.settings }, w.scene, this.qcfg().shadows, w.pitch);
    m.onFinish = (r) => this.onFinish?.(r, 'match');
    m.onGoalEvent = () => {
      w.cheer(1.4);
      this.shake = 0.5;
    };
    m.onFx = (kind, x, z, power) => {
      w.effect(kind, x, z, power, [m.teams[0].kit.primary, m.teams[0].kit.secondary, m.teams[1].kit.primary]);
      if (kind === 'kick' && power > 0.88) this.shake = Math.max(this.shake, 0.1);
    };
    this.match = m;
    w.setCrowdColors([m.teams[0].kit.primary, m.teams[1].kit.primary]);
    const u = m.user!;
    this.camPos.set(u.pos.x - 15, 10, u.pos.z);
    this.camLook.set(u.pos.x, 0, u.pos.z);
    audio.play('whistle');
    this.pushHud();
  }

  startPenalty(cfg: PenaltyConfig, stadium: string) {
    this.restartFn = () => this.startPenalty(cfg, stadium);
    this.enter('penalty', stadium, 3);
    const w = this.world!;
    const g = new PenaltyGame({ ...cfg, settings: this.settings }, w.scene, this.qcfg().shadows);
    g.onFinish = (r) => this.onFinish?.(r, 'penalty');
    this.penalty = g;
    w.setCrowdColors([cfg.homeKit.primary, cfg.away.primary]);
    const cp = { pos: new Vector3(), look: new Vector3(), fov: 46 };
    g.camera(cp);
    this.camPos.copy(cp.pos);
    this.camLook.copy(cp.look);
    this.pushHud();
  }

  startFreeKick(cfg: FreeKickConfig, stadium: string) {
    this.restartFn = () => this.startFreeKick(cfg, stadium);
    this.enter('freekick', stadium, 5);
    const w = this.world!;
    const g = new FreeKickGame({ ...cfg, settings: this.settings }, w.scene, this.qcfg().shadows);
    g.onFinish = (r) => this.onFinish?.(r, 'freekick');
    this.freekick = g;
    w.setCrowdColors([cfg.homeKit.primary, cfg.away.primary]);
    const cp = { pos: new Vector3(), look: new Vector3(), fov: 50 };
    g.camera(cp);
    this.camPos.copy(cp.pos);
    this.camLook.copy(cp.look);
    this.pushHud();
  }

  restart() {
    this.restartFn?.();
  }

  quitToMenu() {
    this.leave();
    this.mode = 'menu';
    this.paused = false;
    this.input.enabled = false;
    this.input.suspend();
    audio.stopCrowd();
    this.restartFn = null;
    // after leaving a larger pitch / street cage, restore the default menu world
    this.rebuildWorld(this.menuStadium, 3);
    if (this.world) this.world.menuGroup.visible = true;
    this.onHud?.(null as unknown as EngineHud);
  }

  setPaused(p: boolean) {
    this.paused = p;
    this.input.enabled = !p && this.mode !== 'menu';
    if (p) {
      this.input.suspend();
      this.match?.cancelControls();
      this.penalty?.cancelCharge();
      this.freekick?.cancelCharge();
      audio.setCrowdLevel(0);
    }
  }

  continueHalftime() {
    this.match?.continueFromHalftime();
  }

  setTactic(t: Parameters<Match['setTactic']>[0]) {
    this.match?.setTactic(t);
  }

  attachMinimap(c: HTMLCanvasElement | null) {
    this.minimap = c;
  }

  setStadium(id: string) {
    this.menuStadium = id;
    if (this.mode === 'menu' && this.world) this.rebuildWorld(id, 3);
  }

  // ------------------------------------------------------------------ loop
  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    const interval = this.mode === 'menu' ? 1000 / Math.min(this.settings.fps, 30) : 1000 / this.settings.fps;
    const elapsed = now - this.last;
    if (elapsed < interval - 2.5) return;
    let dt = elapsed / 1000;
    this.last = now;
    if (dt > 0.1) dt = 0.1;
    if (this.lost || !this.world) return;

    try {
      this.fpsAcc += dt;
      this.fpsFrames++;
      if (this.fpsAcc >= 0.5) {
        const fps = Math.round(this.fpsFrames / this.fpsAcc);
        this.onFps?.(fps);
        this.fpsAcc = 0;
        this.fpsFrames = 0;
        // adaptive quality: if the game stays well below the target for ~5s, ask to lower the preset
        const target = this.settings.fps;
        if (this.mode !== 'menu' && !this.paused && fps < target * 0.68) this.slowT += 0.5;
        else this.slowT = Math.max(0, this.slowT - 1);
        if (this.slowT >= 5) {
          this.slowT = 0;
          this.onSlow?.();
        }
      }

      if (this.mode === 'menu') {
        // The home screen uses full-bleed photography. Don't waste GPU cycles
        // rendering a WebGL scene that is completely covered by the menu.
        if (this.menuView === 'hero') return;
        this.updateMenu(dt);
      } else {
        this.input.update(dt);
        if (this.input.pressed.pause && !this.input.keys.has('Escape') && !this.input.keys.has('KeyP')) this.onPauseRequested?.();
        if (!this.paused) {
          if (this.match) this.updateMatchFrame(dt);
          else if (this.penalty) this.updatePenaltyFrame(dt);
          else if (this.freekick) this.updateFreeKickFrame(dt);
        }
        this.hudT -= dt;
        if (this.hudT <= 0) {
          this.hudT = 0.1;
          this.pushHud();
        }
      }
      this.renderer.render(this.world.scene, this.camera);
    } catch (e) {
      console.error(e);
      this.onError?.(String(e));
      cancelAnimationFrame(this.raf);
    }
  };

  private updateMatchFrame(dt: number) {
    const m = this.match!;
    const w = this.world!;
    const p = w.pitch;
    m.camYaw = this.camYaw;
    m.update(dt, this.input);

    // ---- camera
    const camMode = this.settings.camera;
    const cm = CAM[camMode];
    const goal = m.phase === 'GOAL';
    m.cameraFocus(this.focus);
    const u = m.user;
    const side = camMode === 'BROADCAST';
    const broadcast = side && !goal;
    let yawT = side ? Math.PI : Math.PI / 2;
    if (u && !goal && !side) {
      if (u.speed > 3) {
        const mv = Math.atan2(u.vel.x, u.vel.z);
        yawT += clamp(angDiff(Math.PI / 2, mv) * 0.28, -0.38, 0.38);
      }
    }
    if (goal) yawT = this.camYaw + 0.4;
    this.camYaw += angDiff(this.camYaw, yawT) * (1 - Math.exp(-(goal ? 0.6 : 2.2) * dt));

    const zoom = Math.max(m.shootCharge * 0.1, m.shotFlash * 0.06);
    if (broadcast) {
      // side-on television view (DLS / eFootball style): the camera tracks along the touchline
      const sc = clamp(p.W / 38, 0.55, 1.5);
      const dist = cm.dist * sc * (1 - zoom * 0.5);
      const height = cm.height * sc * (1 - zoom * 0.4);
      this.tmp.set(this.focus.x, height, this.focus.z * 0.5 + dist);
      const track = m.ball.speed > 15 ? 7.5 : 5.2;
      this.camPos.lerp(this.tmp, 1 - Math.exp(-track * dt));
      this.camLook.lerp(this.tmp.set(this.focus.x, 0.4, this.focus.z * 0.55 + 4 * sc), 1 - Math.exp(-(track + 2) * dt));
    } else {
      const dist = (goal ? 8.5 : cm.dist) * (1 - zoom);
      const height = (goal ? 3.6 : cm.height) * (1 - zoom * 0.7);
      const fx = Math.sin(this.camYaw);
      const fz = Math.cos(this.camYaw);
      this.tmp.set(this.focus.x - fx * dist, height, this.focus.z - fz * dist);
      this.tmp.x = clamp(this.tmp.x, -(p.boardX + 1.5), p.boardX + 1.5);
      this.tmp.z = clamp(this.tmp.z, -(p.boardZ + 1.2), p.boardZ + 1.2);
      this.camPos.lerp(this.tmp, 1 - Math.exp(-6 * dt));
      this.camLook.lerp(this.tmp.set(this.focus.x + fx * 1.5, 0.8, this.focus.z + fz * 1.5), 1 - Math.exp(-9 * dt));
    }
    this.shake = Math.max(0, this.shake - dt * 1.5);
    this.camera.position.copy(this.camPos);
    if (this.shake > 0) {
      this.camera.position.x += (Math.random() - 0.5) * this.shake * 0.25;
      this.camera.position.y += (Math.random() - 0.5) * this.shake * 0.25;
    }
    this.camera.lookAt(this.camLook);
    const targetFov = cm.fov + m.shotFlash * (broadcast ? 2 : 5);
    this.camera.fov += (targetFov - this.camera.fov) * (1 - Math.exp(-8 * dt));
    this.camera.updateProjectionMatrix();
    w.update(dt, this.focus);
    const elapsed = Math.floor(m.clock + (m.overtime ? m.overtimeClock : 0));
    const clock = `${String(Math.floor(elapsed / 60)).padStart(2, '0')}:${String(elapsed % 60).padStart(2, '0')}`;
    w.setScoreboard(m.teams[0].def.short, m.teams[1].def.short, m.teams[0].score, m.teams[1].score, clock);
    audio.setCrowdLevel(Math.max(0, Math.abs(m.ball.pos.x) / (p.L / 2) - 0.5) * 2);
    this.mapT -= dt;
    if (this.minimap && this.mapT <= 0) {
      this.mapT = 0.05;
      this.drawMinimap(m, p);
    }
  }

  private updatePenaltyFrame(dt: number) {
    const g = this.penalty!;
    const w = this.world!;
    g.update(dt, this.input);
    const cp = { pos: new Vector3(), look: new Vector3(), fov: 46 };
    g.camera(cp);
    this.camPos.lerp(cp.pos, 1 - Math.exp(-3 * dt));
    this.camLook.lerp(cp.look, 1 - Math.exp(-6 * dt));
    this.camera.position.copy(this.camPos);
    this.camera.lookAt(this.camLook);
    this.camera.fov += (cp.fov + g.shotFlash * 3 - this.camera.fov) * (1 - Math.exp(-6 * dt));
    this.camera.updateProjectionMatrix();
    w.update(dt, this.tmp.set(w.pitch.L / 2 - 8, 0, 0));
    const ph = g.hud();
    w.setScoreboard(ph.homeShort, ph.awayShort, ph.homeScore, ph.awayScore, 'PENALTIES');
    if (g.stage === 'RESULT' && g.message.startsWith('GOAL') && g.stageT === 0) {
      w.cheer(1);
      w.effect('goal', w.pitch.L / 2, 0, 1, ['#ffffff', '#ffe14d']);
    }
  }

  private updateFreeKickFrame(dt: number) {
    const g = this.freekick!;
    const w = this.world!;
    g.update(dt, this.input);
    const cp = { pos: new Vector3(), look: new Vector3(), fov: 50 };
    g.camera(cp);
    this.camPos.lerp(cp.pos, 1 - Math.exp(-3.5 * dt));
    this.camLook.lerp(cp.look, 1 - Math.exp(-6 * dt));
    this.camera.position.copy(this.camPos);
    this.camera.lookAt(this.camLook);
    this.camera.fov += (cp.fov + g.shotFlash * 3 - this.camera.fov) * (1 - Math.exp(-6 * dt));
    this.camera.updateProjectionMatrix();
    w.update(dt, this.tmp.set(w.pitch.L / 2 - 12, 0, 0));
    const fh = g.hud();
    w.setScoreboard(fh.homeShort, fh.awayShort, fh.fk.goals, fh.fk.total, 'FREE KICKS');
    if (g.justScored) {
      g.justScored = false;
      w.cheer(1);
      w.effect('goal', w.pitch.L / 2, 0, 1, ['#ffffff', '#ffe14d']);
    }
  }

  private pushHud() {
    if (!this.onHud) return;
    if (this.match) this.onHud(this.match.hud());
    else if (this.penalty) this.onHud(this.penalty.hud());
    else if (this.freekick) this.onHud(this.freekick.hud());
  }

  private drawMinimap(m: Match, p: PitchSpec) {
    const c = this.minimap!;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    const W = c.width;
    const H = c.height;
    const pad = 6;
    const sx = (W - pad * 2) / (p.L + 4);
    const sz = (H - pad * 2) / (p.W + 4);
    const X = (x: number) => W / 2 + x * sx;
    const Z = (z: number) => H / 2 + z * sz;
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = p.street ? 'rgba(40,36,60,0.8)' : 'rgba(10,40,20,0.72)';
    ctx.fillRect(0, 0, W, H);
    ctx.strokeStyle = 'rgba(255,255,255,0.7)';
    ctx.lineWidth = 1;
    ctx.strokeRect(X(-p.L / 2), Z(-p.W / 2), p.L * sx, p.W * sz);
    ctx.beginPath();
    ctx.moveTo(X(0), Z(-p.W / 2));
    ctx.lineTo(X(0), Z(p.W / 2));
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(X(0), Z(0), p.circleR * sx, 0, Math.PI * 2);
    ctx.stroke();
    for (const s of [-1, 1]) {
      ctx.strokeRect(s < 0 ? X(-p.L / 2) : X(p.L / 2 - p.boxD), Z(-p.boxW / 2), p.boxD * sx, p.boxW * sz);
    }
    for (const pl of m.players) {
      ctx.fillStyle = m.teams[pl.team].kit.primary;
      ctx.beginPath();
      ctx.arc(X(pl.pos.x), Z(pl.pos.z), pl.isGK ? 3 : 3.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = pl.isUser ? '#ffe14d' : 'rgba(0,0,0,0.6)';
      ctx.lineWidth = pl.isUser ? 2 : 1;
      ctx.stroke();
    }
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.arc(X(m.ball.pos.x), Z(m.ball.pos.z), 2.4, 0, Math.PI * 2);
    ctx.fill();
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    this.resizeObs?.disconnect();
    this.leave();
    this.disposeMenuProps();
    this.world?.dispose();
    this.input.dispose();
    this.renderer?.dispose();
    this.renderer?.domElement.remove();
    audio.stopMusic();
    audio.stopCrowd();
  }
}
