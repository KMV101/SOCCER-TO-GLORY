import { Vector3 } from 'three';
import { TACTICS } from './config';
import type { Footballer } from './entities';
import type { Match } from './match';

const rand = Math.random;
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const _v = new Vector3();

/** distance from point p to segment a-b (xz plane) */
export function segDist(px: number, pz: number, ax: number, az: number, bx: number, bz: number): number {
  const dx = bx - ax;
  const dz = bz - az;
  const l2 = dx * dx + dz * dz;
  let t = l2 > 0 ? ((px - ax) * dx + (pz - az) * dz) / l2 : 0;
  t = clamp(t, 0, 1);
  return Math.hypot(px - (ax + dx * t), pz - (az + dz * t));
}

/** smallest distance of any opponent of `team` to the lane a->b (ignores the keeper at the end if `skipKeeper`). */
export function laneClearance(m: Match, team: number, ax: number, az: number, bx: number, bz: number, skipKeeper = false): number {
  let best = 99;
  for (const o of m.teams[1 - team].players) {
    if (skipKeeper && o.isGK) continue;
    best = Math.min(best, segDist(o.pos.x, o.pos.z, ax, az, bx, bz));
  }
  return best;
}

/** Where should a player stand according to formation + ball + tactic + game state */
export function formationPos(m: Match, p: Footballer, out: Vector3): Vector3 {
  const t = m.teams[p.team];
  const tac = TACTICS[t.tactic];
  const D = m.diffFor(p.team);
  const { L, W } = m.pitch;
  const d = t.dir;
  const slot = m.slotOf(p);
  const ball = m.ball;
  const ballU = clamp((ball.pos.x * d + L / 2) / L, 0, 1);
  const teamHas = m.possession === p.team;
  const oppHas = m.possession === 1 - p.team && m.possession !== -1;
  let u = slot.u + tac.shift + (ballU - 0.5) * 0.34;
  if (teamHas) u += 0.07 + (p.def.pos === 'FWD' ? 0.08 : 0);
  if (tac.counter && teamHas && m.time - m.possessionSince < 5 && p.def.pos !== 'DEF') u += 0.2;
  if (oppHas && p.def.pos !== 'FWD') u = Math.min(u, ballU + 0.04);
  if (oppHas && tac.counter && p.def.pos === 'FWD') u = Math.max(u, 0.52);
  u = clamp(u, 0.08, 0.93);
  const x = d * (-L / 2 + u * L);
  let z = d * slot.v * (W / 2 - 3.5) * tac.width;
  z += (ball.pos.z - z) * (oppHas ? 0.32 : 0.2);
  const n = Math.sin(m.time * 0.6 + p.index * 2.3) * D.posNoise * 0.5;
  out.set(x + n * 0.6, 0, clamp(z + n, -(W / 2 - 2), W / 2 - 2));
  return out;
}

export function chaseTarget(m: Match, p: Footballer, out: Vector3): Vector3 {
  const b = m.ball;
  const D = m.diffFor(p.team);
  const dist = Math.hypot(b.pos.x - p.pos.x, b.pos.z - p.pos.z);
  const tt = Math.min(1.6, (dist / Math.max(4, p.topRun)) * (0.4 + 0.6 * D.awareness));
  const k = 0.45;
  const f = (1 - Math.exp(-k * tt)) / k;
  out.set(b.pos.x + b.vel.x * f, 0, b.pos.z + b.vel.z * f);
  return out;
}

// ---------------------------------------------------------------- outfield think
export function thinkOutfield(m: Match, p: Footballer) {
  const D = m.diffFor(p.team);
  const t = m.teams[p.team];
  const tac = TACTICS[t.tactic];
  const ball = m.ball;
  const owner = ball.owner;
  const iHave = owner === p;
  p.sprint = false;

  if (m.sp) {
    setPieceThink(m, p);
    return;
  }

  if (m.kickoffLock > 0 && m.kickoffTeam !== p.team && m.phase === 'PLAY') {
    p.state = 'POSITIONING';
    formationPos(m, p, p.target);
    return;
  }

  // expecting a pass
  if (p.receive && m.time < p.receive.until && !iHave) {
    p.state = 'CHASE_BALL';
    const bd = Math.hypot(ball.pos.x - p.pos.x, ball.pos.z - p.pos.z);
    if (bd < 7 && ball.owner === null) chaseTarget(m, p, p.target);
    else p.target.copy(p.receive.target);
    p.sprint = p.stamina > 20;
    return;
  }
  p.receive = null;

  if (iHave) {
    thinkCarrier(m, p);
    return;
  }

  const teamHas = !!owner && owner.team === p.team;
  const oppHas = !!owner && owner.team !== p.team;
  const isChaser = m.chasers.has(p);

  if (teamHas) {
    thinkSupport(m, p, owner!);
    return;
  }

  if (!owner) {
    // loose ball
    if (isChaser) {
      p.state = 'CHASE_BALL';
      chaseTarget(m, p, p.target);
      p.sprint = p.stamina > 15;
    } else {
      p.state = 'POSITIONING';
      formationPos(m, p, p.target);
      p.sprint = Math.hypot(p.target.x - p.pos.x, p.target.z - p.pos.z) > 9 && p.stamina > 40;
    }
    return;
  }

  // opponent has the ball
  if (oppHas) {
    const dToBall = Math.hypot(owner!.pos.x - p.pos.x, owner!.pos.z - p.pos.z);
    const inRange = dToBall < tac.pressRange * D.pressRange;
    if (isChaser && (inRange || (p.def.pos === 'DEF' && dToBall < 12)) && !owner!.holding) {
      p.state = 'PRESS';
      // approach goal-side of the carrier, anticipating movement
      const lead = 0.18 + 0.3 * D.awareness;
      const ownGoalX = -t.dir * m.pitch.L / 2;
      _v.set(ownGoalX - owner!.pos.x, 0, -owner!.pos.z).normalize();
      const stand = dToBall > 3 ? 0.9 : 0.3;
      p.target.set(owner!.pos.x + owner!.vel.x * lead + _v.x * stand, 0, owner!.pos.z + owner!.vel.z * lead + _v.z * stand);
      p.sprint = dToBall > 3.2 && p.stamina > 12;
      // tackle decision
      if (dToBall < 1.55 && p.tackleCd <= 0 && !p.busy && rand() < 0.42 * (0.4 + D.tackle * 0.8) + 0.06) {
        p.state = 'TACKLE';
        m.startTackle(p, false);
      } else if (dToBall < 2.5 && dToBall > 1.6 && p.tackleCd <= 0 && !p.busy && D.decision > 0.85 && p.stamina > 30 && rand() < 0.04) {
        p.state = 'TACKLE';
        m.startTackle(p, true);
      }
      return;
    }
    // mark / zone defend
    p.state = 'DEFEND';
    const zone = formationPos(m, p, p.target);
    const mark = m.markTarget(p);
    if (mark) {
      const ownGoalX = -t.dir * m.pitch.L / 2;
      _v.set(ownGoalX - mark.pos.x, 0, 0 - mark.pos.z).normalize();
      const mx = mark.pos.x + _v.x * 2.4;
      const mz = mark.pos.z + _v.z * 2.4;
      zone.x += (mx - zone.x) * tac.mark * (0.5 + 0.5 * D.awareness);
      zone.z += (mz - zone.z) * tac.mark * (0.5 + 0.5 * D.awareness);
    }
    p.sprint = Math.hypot(zone.x - p.pos.x, zone.z - p.pos.z) > 8 && p.stamina > 25;
    return;
  }
  p.state = 'POSITIONING';
  formationPos(m, p, p.target);
}

// ---------------------------------------------------------------- set pieces (throw-ins & corners)
function setPieceThink(m: Match, p: Footballer) {
  const sp = m.sp!;
  const D = m.diffFor(p.team);
  const { L, W } = m.pitch;
  p.receive = null;
  if (sp.taker === p) {
    p.state = 'POSITIONING';
    if (sp.state === 'fetch') {
      p.target.copy(sp.spot);
      p.sprint = true;
      return;
    }
    if (sp.t > 0.8 + D.think * 3) {
      const bp = bestPass(m, p, true);
      if (bp && sp.kind === 'corner') m.aiCross(p, bp.mate);
      else if (bp) m.aiPass(p, bp.mate, false);
      else {
        // A throw-in without a passing option is recycled toward midfield,
        // not converted into an impossible shot from the touchline.
        const dx = -p.pos.x * 0.35 + m.teams[p.team].dir * 5;
        const dz = -p.pos.z * 0.8;
        m.kick(p, new Vector3(dx, 0, dz).normalize(), 10, sp.kind === 'throw' ? 3 : 0.5, 'pass');
      }
    }
    return;
  }
  const d = m.teams[sp.team].dir;
  const mates = m.teams[p.team].outfield.filter((q) => q !== sp.taker);
  const idx = Math.max(0, mates.indexOf(p));
  p.state = 'POSITIONING';
  if (sp.kind === 'corner') {
    const gx = d * L / 2;
    const row = idx % 3;
    if (p.team === sp.team) p.target.set(gx - d * (6 + (idx % 2) * 2.4), 0, (row - 1) * 3.4);
    else p.target.set(gx - d * (3 + (idx % 2) * 2.2), 0, (row - 1) * 3 + (idx % 2 ? 0.8 : -0.8));
    p.sprint = true;
    return;
  }
  if (p.team === sp.team) {
    const side = Math.sign(sp.spot.z) || 1;
    const n = Math.max(1, mates.length);
    p.target.set(sp.spot.x + (idx - (n - 1) / 2) * 8 + d * 3, 0, sp.spot.z - side * (5 + (idx % 2) * 4));
  } else formationPos(m, p, p.target);
  p.target.x = clamp(p.target.x, -(L / 2 - 2), L / 2 - 2);
  p.target.z = clamp(p.target.z, -(W / 2 - 1.5), W / 2 - 1.5);
  p.sprint = Math.hypot(p.target.x - p.pos.x, p.target.z - p.pos.z) > 9 && p.stamina > 40;
}

// ---------------------------------------------------------------- supporting play
function thinkSupport(m: Match, p: Footballer, carrier: Footballer) {
  const t = m.teams[p.team];
  const D = m.diffFor(p.team);
  const { L, W } = m.pitch;
  const d = t.dir;
  const tac = TACTICS[t.tactic];
  const pos = p.def.pos;
  // The closest non-defender teammate provides short support, others make runs.
  const isSupport = m.supportOf(p.team) === p;
  if (isSupport) {
    p.state = 'SUPPORT';
    // side with more room
    let bestZ = 0;
    let bestScore = -1;
    for (const zz of [-0.55, 0.55]) {
      const cz = clamp(carrier.pos.z + zz * 14, -(W / 2 - 3), W / 2 - 3);
      const cx = carrier.pos.x - d * 1.5;
      const nearest = m.nearestOpponentTo(p.team, cx, cz);
      const sc = nearest.d + rand() * 0.5;
      if (sc > bestScore) {
        bestScore = sc;
        bestZ = cz;
      }
    }
    p.target.set(clamp(carrier.pos.x - d * 2 + d * (tac.risk * 3), -L / 2 + 3, L / 2 - 3), 0, bestZ);
    p.sprint = Math.hypot(p.target.x - p.pos.x, p.target.z - p.pos.z) > 7 && p.stamina > 30;
    return;
  }
  p.state = 'ATTACK';
  const home = formationPos(m, p, p.target);
  if (pos === 'FWD' || pos === 'MID' || tac.shift > 0.1) {
    // run into space ahead of the ball carrier
    const ahead = 9 + tac.risk * 8;
    let tx = carrier.pos.x + d * ahead;
    const limit = pos === 'DEF' ? 0.6 : 0.88;
    const lim = d * (-L / 2 + limit * L);
    tx = d > 0 ? Math.min(tx, lim) : Math.max(tx, lim);
    // pick the lane with the most space
    let bz = home.z;
    let best = -1;
    for (const f of [-0.6, -0.2, 0.2, 0.6]) {
      const cz = f * (W / 2 - 3);
      const nearest = m.nearestOpponentTo(p.team, tx, cz);
      const dc = Math.abs(cz - carrier.pos.z);
      const sc = nearest.d + Math.min(dc, 12) * 0.25 + rand() * (1 - D.decision) * 4;
      if (sc > best) {
        best = sc;
        bz = cz;
      }
    }
    p.target.set(tx * 0.7 + home.x * 0.3, 0, bz);
    p.state = 'ATTACK';
    p.sprint = Math.hypot(p.target.x - p.pos.x, p.target.z - p.pos.z) > 6 && p.stamina > 35;
  }
}

// ---------------------------------------------------------------- ball carrier
interface PassOption { mate: Footballer; score: number; through: boolean }

export function bestPass(m: Match, p: Footballer, allowBack = true): PassOption | null {
  const t = m.teams[p.team];
  const d = t.dir;
  const D = m.diffFor(p.team);
  let best: PassOption | null = null;
  const gx = d * m.pitch.L / 2;
  const myGoalDist = Math.hypot(gx - p.pos.x, p.pos.z);
  for (const mate of t.outfield) {
    if (mate === p) continue;
    const dist = Math.hypot(mate.pos.x - p.pos.x, mate.pos.z - p.pos.z);
    if (dist < 3.5 || dist > 36) continue;
    const progress = (mate.pos.x - p.pos.x) * d;
    if (!allowBack && progress < -2) continue;
    const risk = laneClearance(m, p.team, p.pos.x, p.pos.z, mate.pos.x, mate.pos.z, true);
    const open = Math.min(8, m.nearestOpponentTo(p.team, mate.pos.x, mate.pos.z).d) / 8;
    const mateGoalDist = Math.hypot(gx - mate.pos.x, mate.pos.z);
    let score = progress * 0.06 + open * 0.9 - (risk < 1.2 ? 1.3 : risk < 2.4 ? 0.5 : 0) - dist * 0.012;
    if (mateGoalDist < myGoalDist - 3) score += 0.45;
    score += (rand() - 0.5) * (1 - D.decision) * 1.6;
    const through = mate.def.pos === 'FWD' && progress > 7 && risk > 2 && rand() < 0.35 * D.decision;
    if (!best || score > best.score) best = { mate, score, through };
  }
  return best;
}

function thinkCarrier(m: Match, p: Footballer) {
  const t = m.teams[p.team];
  const D = m.diffFor(p.team);
  const tac = TACTICS[t.tactic];
  const d = t.dir;
  const { L, W, goalW } = m.pitch;
  const gx = d * L / 2;
  const st = p.def.stats;
  const dGoal = Math.hypot(gx - p.pos.x, p.pos.z);
  const nearest = m.nearestOpponentTo(p.team, p.pos.x, p.pos.z, true);
  p.state = 'ATTACK';
  const holdT = m.time - m.ownerSince;

  // kick-off: simple safe pass
  if (m.phase === 'PLAY' && m.time - m.playStart < 1.4 && holdT > 0.35 && m.kickoffTeam === p.team) {
    const bp = bestPass(m, p, false);
    if (bp) {
      m.aiPass(p, bp.mate, false);
      return;
    }
  }

  // shoot?
  const range = Math.min(L * 0.34, 12 + st.shooting * 0.09) * (0.9 + tac.risk * 0.18);
  if (dGoal < range && p.decisionCd <= 0 && holdT > 0.25) {
    const clear = laneClearance(m, p.team, p.pos.x, p.pos.z, gx, 0, true);
    const close = dGoal < L * 0.22;
    let chance = (clear > 1.6 ? 0.85 : clear > 0.9 ? 0.5 : 0.18) * (close ? 1.2 : 0.8);
    chance *= 0.5 + 0.5 * D.decision;
    if (rand() < chance * 0.78 + tac.risk * 0.08) {
      p.state = 'SHOOT';
      p.decisionCd = 0.8;
      m.aiShoot(p);
      return;
    }
    p.decisionCd = 0.25;
  }

  // pass?
  const pressure = nearest.d < 2.9 * (0.6 + 0.4 * D.awareness);
  if (p.decisionCd <= 0 && holdT > 0.3) {
    const bp = bestPass(m, p);
    if (bp) {
      const forwardGood = bp.score > 1.1 && rand() < 0.35 * D.decision * (0.5 + tac.risk);
      if ((pressure && bp.score > 0.1 && rand() < 0.8) || forwardGood || holdT > 3.2) {
        p.state = 'PASS';
        p.decisionCd = 0.6;
        m.aiPass(p, bp.mate, bp.through);
        return;
      }
    }
    p.decisionCd = 0.12;
  }

  // skill move to beat a defender who is closing in
  if (p.skillCd <= 0 && nearest.d < 3.2 && nearest.d > 1.1 && p.stamina > 25 && rand() < (m.cfg.street ? 0.32 : 0.1) * D.decision) m.startSkill(p);

  // dribble toward goal avoiding defenders
  let dx = gx - p.pos.x;
  let dz = (rand() < 0.01 ? 0 : 0) - p.pos.z * 0.5;
  const l = Math.hypot(dx, dz) || 1;
  dx /= l;
  dz /= l;
  for (const o of m.teams[1 - p.team].players) {
    const ox = p.pos.x - o.pos.x;
    const oz = p.pos.z - o.pos.z;
    const dd = Math.hypot(ox, oz);
    if (dd < 6.5 && dd > 0.01) {
      // only dodge defenders that are ahead of us
      const ahead = ((o.pos.x - p.pos.x) * d) > -1.5;
      if (!ahead) continue;
      const w = Math.pow(1 - dd / 6.5, 2) * 2.1 * (0.4 + 0.6 * D.awareness);
      // slide sideways: choose the perpendicular that heads away from the defender
      const side = Math.sign(oz) || (rand() < 0.5 ? 1 : -1);
      dx += (ox / dd) * w * 0.5;
      dz += (oz / dd) * w * 0.7 + side * w * 0.6;
    }
  }
  // avoid sidelines
  if (Math.abs(p.pos.z) > W / 2 - 3) dz -= Math.sign(p.pos.z) * 1.2;
  const nl = Math.hypot(dx, dz) || 1;
  p.target.set(p.pos.x + (dx / nl) * 8, 0, p.pos.z + (dz / nl) * 8);
  p.target.z = clamp(p.target.z, -(W / 2 - 1.5), W / 2 - 1.5);
  p.sprint = nearest.d > 3.4 && p.stamina > 22;
  void goalW;
}

// ---------------------------------------------------------------- movement helper
export function steerToTarget(m: Match, p: Footballer) {
  const dx = p.target.x - p.pos.x;
  const dz = p.target.z - p.pos.z;
  const dist = Math.hypot(dx, dz);
  const D = m.diffFor(p.team);
  if (dist < 0.35) {
    p.moveDir.set(0, 0, 0);
    return;
  }
  const mag = dist > 2.2 ? 1 : dist > 1 ? 0.7 : 0.4;
  p.moveDir.set((dx / dist) * mag * D.speed, 0, (dz / dist) * mag * D.speed);
  // never ghost through the sideline boards
  void m;
}

// ---------------------------------------------------------------- goalkeeper
export function updateKeeper(m: Match, gk: Footballer, dt: number) {
  const t = m.teams[gk.team];
  const D = m.diffFor(gk.team);
  const { L, goalW, boxD, boxW } = m.pitch;
  const d = t.dir;
  const lineX = -d * L / 2;
  const ball = m.ball;
  gk.state = 'KEEPER';
  gk.sprint = false;

  if (gk.busy) return;

  if (gk.holding) {
    gk.target.set(lineX + d * 2.2, 0, gk.pos.z * 0.9);
    steerToTarget(m, gk);
    gk.moveDir.multiplyScalar(0.3);
    return;
  }

  const approach = ball.vel.x * -d; // moving toward own goal?
  const bDistGoal = Math.hypot(ball.pos.x - lineX, ball.pos.z);
  const inBox = Math.abs(ball.pos.x - lineX) < boxD && Math.abs(ball.pos.z) < boxW / 2;

  // shot incoming?
  if (approach > 5 && ball.owner === null && ball.lastKickTeam !== gk.team) {
    const dxl = (lineX - ball.pos.x);
    const tHit = dxl / ball.vel.x;
    if (tHit > 0 && tHit < 2.2) {
      const cz = ball.pos.z + ball.vel.z * tHit;
      const cy = ball.pos.y + ball.vel.y * tHit - 0.5 * 17 * tHit * tHit;
      if (Math.abs(cz) < goalW / 2 + 1.5 && cy < 3.2) {
        if (gk.reactShot !== ball.shotId) {
          gk.reactShot = ball.shotId;
          gk.thinkT = m.time + D.gkReaction; // reaction delay – reused as 'react at' timestamp
        }
        if (m.time >= gk.thinkT) {
          const tz = clamp(cz, -goalW / 2 - 0.4, goalW / 2 + 0.4);
          gk.target.set(lineX + d * 0.5, 0, tz);
          gk.sprint = true;
          const lateral = Math.abs(gk.pos.z - tz);
          const reachT = lateral / 5.5;
          // dive when lateral distance is beyond a step or the ball is high & close
          if ((lateral > 1.2 && tHit < reachT * 0.55 + 0.38 && tHit < 0.5) || (lateral > 0.5 && tHit < 0.24 && gk.tackleCd <= 0)) {
            _v.set(0.0, 0, Math.sign(tz - gk.pos.z) || 1);
            m.keeperDive(gk, _v, clamp(cy / 2.6, 0, 1));
            return;
          }
          steerToTarget(m, gk);
          gk.moveDir.setLength(1);
          return;
        }
        // still reacting: shuffle toward the ball's line
        gk.target.set(lineX + d * 1.2, 0, clamp(ball.pos.z * 0.4, -goalW / 2, goalW / 2));
        steerToTarget(m, gk);
        return;
      }
    }
  }

  // come out to claim a loose ball in the box
  if (ball.owner === null && inBox && ball.speed < 6) {
    const mine = Math.hypot(ball.pos.x - gk.pos.x, ball.pos.z - gk.pos.z);
    const nearOpp = m.nearestOpponentTo(gk.team, ball.pos.x, ball.pos.z, true);
    if (mine < nearOpp.d + 1.5) {
      gk.target.set(ball.pos.x, 0, ball.pos.z);
      gk.sprint = true;
      steerToTarget(m, gk);
      return;
    }
  }

  // narrow the angle against a carrier near the box
  const carrier = ball.owner && ball.owner.team !== gk.team ? ball.owner : null;
  let depth = 0.9;
  if (carrier && bDistGoal < boxD * 1.6) depth = clamp(bDistGoal * 0.32, 1, 5.2) * (0.6 + 0.4 * D.awareness);
  else depth = clamp(bDistGoal * 0.05, 0.8, 2.6);
  const ang = Math.atan2(ball.pos.z, Math.abs(ball.pos.x - lineX) + 0.5);
  const zSpot = clamp(Math.tan(ang) * depth * 1.15, -goalW / 2 + 0.3, goalW / 2 - 0.3);
  gk.target.set(lineX + d * depth, 0, zSpot);
  gk.sprint = !!carrier && bDistGoal < boxD * 1.2;
  steerToTarget(m, gk);
  if (Math.hypot(gk.target.x - gk.pos.x, gk.target.z - gk.pos.z) < 0.5) gk.moveDir.set(0, 0, 0);
  void dt;
}
