import { Group, Mesh, Vector3 } from 'three';
import type { PlayerDef, Pos } from './config';
import { applyPose, createBlobShadow, createPlayerModel, disposeRig, type KitSpec, type PlayerRig } from './models';

export type ActionKind = 'IDLE' | 'KICK' | 'TACKLE' | 'SLIDE' | 'FALL' | 'SAVE' | 'CELEBRATE' | 'SKILL' | 'POWER_SHOT' | 'ROULETTE' | 'FINESSE' | 'HEADER';
export type AIState =
  | 'IDLE' | 'POSITIONING' | 'CHASE_BALL' | 'ATTACK' | 'SUPPORT' | 'PASS' | 'SHOOT' | 'DEFEND' | 'PRESS' | 'TACKLE' | 'RECOVER' | 'KEEPER';

const TAU = Math.PI * 2;
export function angDiff(a: number, b: number): number {
  let d = (b - a) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return d;
}

/** a dead-ball restart (throw-in / corner kick) waiting for its taker */
export interface SetPiece {
  kind: 'throw' | 'corner';
  team: number;
  spot: Vector3;
  taker: Footballer;
  state: 'fetch' | 'ready';
  t: number;
}

export class Footballer {
  readonly def: PlayerDef;
  readonly team: 0 | 1;
  readonly index: number;
  readonly isGK: boolean;
  readonly pos2: Pos;
  readonly rig: PlayerRig;
  readonly group = new Group();
  readonly blob: Mesh;

  pos = new Vector3();
  vel = new Vector3();
  yaw = 0;
  turnRate = 0;
  stamina = 100;

  // intent (set by user input or AI)
  moveDir = new Vector3(); // magnitude 0..1
  sprint = false;
  isUser = false;

  // actions
  action: ActionKind = 'IDLE';
  actionT = 0;
  actionDur = 0;
  actionPower = 0;
  actionResolved = false;
  diveDir = new Vector3();
  diveHeight = 0;
  kickCooldown = 0;
  stunned = 0;
  hasBall = false;
  dribbling = false;
  holding = false; // keeper holding the ball
  holdTimer = 0;

  // AI
  state: AIState = 'IDLE';
  thinkT = 0;
  target = new Vector3();
  home = new Vector3();
  receive: { until: number; target: Vector3 } | null = null;
  tackleCd = 0;
  decisionCd = 0;
  markId = -1;
  runPhase = 0;
  throwPose = false; // arms overhead while holding the ball for a throw-in
  skillCd = 0; // cooldown for skill moves
  /** contributions this match – feed the post-match player rating */
  gGoals = 0;
  gShots = 0;
  gPasses = 0;
  gTackles = 0;
  gSaves = 0;
  lookAt: Vector3 | null = null; // if set, the player faces this point instead of the move direction (keepers)
  reactShot = -1; // keeper: shot id it is currently reacting to
  saveShot = -1; // keeper: shot id it already attempted to save

  private phase = 0;
  private time = Math.random() * 10;
  private prevVel = new Vector3();
  private accel = 0;

  constructor(def: PlayerDef, team: 0 | 1, index: number, kit: KitSpec, shadows: boolean) {
    this.def = def;
    this.team = team;
    this.index = index;
    this.isGK = def.pos === 'GK';
    this.pos2 = def.pos;
    this.rig = createPlayerModel(kit);
    this.group.add(this.rig.root);
    this.blob = createBlobShadow(1.5);
    this.group.add(this.blob);
    this.rig.root.traverse((o) => {
      const m = o as Mesh;
      if (m.isMesh) m.castShadow = shadows;
    });
    this.blob.visible = !shadows;
  }

  dispose() {
    disposeRig(this.rig);
    this.group.removeFromParent();
  }

  // ---- derived stats
  get stamFactor() {
    return this.stamina > 35 ? 1 : 0.72 + 0.28 * (this.stamina / 35);
  }
  get topRun() {
    return 4.5 + this.def.stats.speed * 0.031 + (this.isGK ? -0.3 : 0);
  }
  get fwd(): Vector3 {
    return new Vector3(Math.sin(this.yaw), 0, Math.cos(this.yaw));
  }
  get speed() {
    return Math.hypot(this.vel.x, this.vel.z);
  }
  get busy() {
    return this.action === 'TACKLE' || this.action === 'SLIDE' || this.action === 'FALL' || this.action === 'SAVE' || this.action === 'CELEBRATE' || this.action === 'POWER_SHOT' || this.action === 'HEADER';
  }

  setAction(a: ActionKind, dur: number, power = 1) {
    this.action = a;
    this.actionT = 0;
    this.actionDur = dur;
    this.actionPower = power;
    this.actionResolved = false;
  }

  place(x: number, z: number, yaw: number) {
    this.pos.set(x, 0, z);
    this.vel.set(0, 0, 0);
    this.yaw = yaw;
    this.action = 'IDLE';
    this.actionT = 0;
    this.actionDur = 0;
    this.actionPower = 0;
    this.actionResolved = false;
    this.moveDir.set(0, 0, 0);
    this.sprint = false;
    this.holding = false;
    this.dribbling = false;
    this.throwPose = false;
    this.hasBall = false;
    this.receive = null;
    this.stunned = 0;
    this.skillCd = 0;
    this.tackleCd = 0;
    this.kickCooldown = 0;
    this.turnRate = 0;
    this.sync();
  }

  /** Physics step: acceleration, turning, stamina. */
  step(dt: number, speedMul: number, carrying: boolean) {
    this.time += dt;
    if (this.kickCooldown > 0) this.kickCooldown -= dt;
    if (this.tackleCd > 0) this.tackleCd -= dt;
    if (this.stunned > 0) this.stunned -= dt;
    if (this.action !== 'IDLE') {
      this.actionT += dt;
      if (this.actionT >= this.actionDur) {
        this.action = 'IDLE';
        this.actionT = 0;
      }
    }
    this.prevVel.copy(this.vel);
    const fw = this.fwd;
    const st = this.def.stats;
    let canSteer = true;
    let cap = 1;
    let accelMul = 1;
    let boost = 1;
    const t = this.actionT;
    if (this.skillCd > 0) this.skillCd -= dt;

    switch (this.action) {
      case 'SKILL':
      case 'ROULETTE':
        // explosive skill acceleration in chosen direction
        if (this.moveDir.lengthSq() < 0.1) this.moveDir.set(fw.x, 0, fw.z);
        boost = this.action === 'ROULETTE' ? 1.48 : 1.36;
        accelMul = 2.6;
        this.sprint = true;
        if (this.action === 'ROULETTE') {
          this.yaw += dt * Math.PI * 3.5;
        }
        break;
      case 'POWER_SHOT':
        // A planted windup leaves the carrier vulnerable before contact.
        if (t < 0.24) {
          cap = 0.45;
          canSteer = false;
        } else {
          this.vel.x += (fw.x * 5.5 - this.vel.x) * Math.min(1, 10 * dt);
          this.vel.z += (fw.z * 5.5 - this.vel.z) * Math.min(1, 10 * dt);
          cap = 0.9;
        }
        break;
      case 'HEADER':
        cap = 0.3;
        break;
      case 'FINESSE':
        cap = 0.85;
        break;
      case 'KICK':
        cap = 0.8;
        break;
      case 'TACKLE':
        if (t < 0.28) {
          this.vel.x += (fw.x * 6.2 - this.vel.x) * Math.min(1, 14 * dt);
          this.vel.z += (fw.z * 6.2 - this.vel.z) * Math.min(1, 14 * dt);
          canSteer = false;
          cap = 0;
        } else {
          cap = 0.15;
        }
        break;
      case 'SLIDE': {
        if (t < 0.03) {
          const s = Math.max(8, this.speed + 3.5);
          this.vel.set(fw.x * s, 0, fw.z * s);
        }
        const sp = this.speed;
        const ns = Math.max(0, sp - 7.5 * dt);
        if (sp > 0) {
          this.vel.x *= ns / sp;
          this.vel.z *= ns / sp;
        }
        canSteer = false;
        cap = 0;
        break;
      }
      case 'FALL':
        this.vel.multiplyScalar(Math.max(0, 1 - 7 * dt));
        canSteer = false;
        cap = 0;
        break;
      case 'SAVE':
        if (t < 0.55) {
          this.vel.x += (this.diveDir.x * 4.5 - this.vel.x) * Math.min(1, 10 * dt);
          this.vel.z += (this.diveDir.z * 4.5 - this.vel.z) * Math.min(1, 10 * dt);
        } else this.vel.multiplyScalar(Math.max(0, 1 - 6 * dt));
        canSteer = false;
        cap = 0;
        break;
      case 'CELEBRATE':
        this.vel.multiplyScalar(Math.max(0, 1 - 5 * dt));
        canSteer = false;
        cap = 0;
        break;
      default:
        break;
    }
    if (this.stunned > 0) cap = Math.min(cap, 0.35);
    if (this.holding) cap = Math.min(cap, 0.5);

    if (canSteer) {
      const m = Math.min(1, this.moveDir.length());
      const sprinting = this.sprint && this.stamina > 2 && m > 0.5;
      const walkMul = m < 0.45 ? 0.5 : 1; // gentle stick = jog
      let vmax = this.topRun * speedMul * this.stamFactor * (sprinting ? 1.22 : 1) * (carrying ? 0.94 : 1) * cap * boost * (m > 0 ? walkMul : 0);
      vmax *= Math.min(1, m * 1.15);
      const dirx = m > 0 ? this.moveDir.x / m : 0;
      const dirz = m > 0 ? this.moveDir.z / m : 0;
      const tx = dirx * vmax;
      const tz = dirz * vmax;
      let a = (13 + st.acceleration * 0.12) * (0.78 + 0.22 * this.stamFactor) * accelMul;
      // braking / sharp direction changes are a touch snappier than speeding up
      const dx = tx - this.vel.x;
      const dz = tz - this.vel.z;
      const dl = Math.hypot(dx, dz);
      const curSp = this.speed;
      const brake = curSp > Math.hypot(tx, tz) ? 1.35 : 1;
      a *= brake;
      if (dl > 1e-5) {
        const k = Math.min(dl, a * dt) / dl;
        this.vel.x += dx * k;
        this.vel.z += dz * k;
      }
      // stamina
      if (sprinting && curSp > 3) this.stamina = Math.max(0, this.stamina - (19 - st.stamina * 0.1) * dt);
      else if (curSp < 0.6) this.stamina = Math.min(100, this.stamina + (9 + st.stamina * 0.06) * dt);
      else if (curSp < 4.2) this.stamina = Math.min(100, this.stamina + (5 + st.stamina * 0.03) * dt);
      else this.stamina = Math.min(100, this.stamina + 1.2 * dt);
    } else if (this.action === 'IDLE') {
      this.stamina = Math.min(100, this.stamina + 6 * dt);
    }

    this.pos.x += this.vel.x * dt;
    this.pos.z += this.vel.z * dt;

    // facing
    const sp = this.speed;
    if (canSteer) {
      let want = this.yaw;
      let has = false;
      if (this.lookAt) {
        const lx = this.lookAt.x - this.pos.x;
        const lz = this.lookAt.z - this.pos.z;
        if (lx * lx + lz * lz > 0.25) {
          want = Math.atan2(lx, lz);
          has = true;
        }
      } else if (this.moveDir.lengthSq() > 0.01 && sp > 0.4) {
        want = Math.atan2(this.vel.x, this.vel.z);
        has = true;
      } else if (this.moveDir.lengthSq() > 0.01) {
        want = Math.atan2(this.moveDir.x, this.moveDir.z);
        has = true;
      }
      if (has) {
        const d = angDiff(this.yaw, want);
        const rate = (sp > 6 ? 7.5 : 11) * (carrying ? 0.9 : 1);
        const step = Math.max(-rate * dt, Math.min(rate * dt, d));
        this.yaw += step;
        this.turnRate += (step / dt - this.turnRate) * Math.min(1, 10 * dt);
      } else this.turnRate *= Math.max(0, 1 - 8 * dt);
    } else this.turnRate *= Math.max(0, 1 - 8 * dt);

    this.accel = (sp - Math.hypot(this.prevVel.x, this.prevVel.z)) / Math.max(dt, 1e-4);
    this.phase += sp * dt * 1.55;
  }

  clampTo(hx: number, hz: number) {
    this.pos.x = Math.max(-hx, Math.min(hx, this.pos.x));
    this.pos.z = Math.max(-hz, Math.min(hz, this.pos.z));
  }

  sync() {
    this.group.position.set(this.pos.x, 0, this.pos.z);
    this.rig.root.rotation.y = this.yaw;
  }

  // ------------------------------------------------------------- animation
  animate(dt: number) {
    this.sync();
    const T = this.rig.target;
    const sp = this.speed;
    const amp = Math.min(1, sp / 8.2);
    const ph = this.phase;
    const s = Math.sin(ph);
    const c = Math.cos(ph);
    const t = this.actionT;
    const time = this.time;
    const sprinting = sp > 7;

    // ---- base locomotion
    const moving = sp > 0.35;
    const A = 0.25 + 0.85 * amp;
    T.legLx = moving ? -s * A : Math.sin(time * 1.4) * 0.01;
    T.legRx = moving ? s * A : 0;
    T.kneeL = moving ? Math.max(0, c) * (0.3 + 1.1 * amp) : 0.03;
    T.kneeR = moving ? Math.max(0, -c) * (0.3 + 1.1 * amp) : 0.03;
    T.legLz = 0.02;
    T.legRz = -0.02;
    const B = 0.2 + 0.95 * amp;
    T.armLx = moving ? s * B : Math.sin(time * 1.2) * 0.04;
    T.armRx = moving ? -s * B : -Math.sin(time * 1.2) * 0.04;
    T.armLz = 0.1 + amp * 0.05;
    T.armRz = -0.1 - amp * 0.05;
    const elb = moving ? -(0.35 + 0.9 * amp) : -0.18;
    T.elbowL = elb;
    T.elbowR = elb;
    T.lean = moving ? 0.05 + amp * (sprinting ? 0.34 : 0.26) + Math.max(-0.1, Math.min(0.12, this.accel * 0.012)) : 0.02;
    T.roll = Math.max(-0.28, Math.min(0.28, -this.turnRate * 0.028 * Math.min(1, sp / 4)));
    T.bodyY = 0.95 - (moving ? 0.015 + amp * 0.035 : 0) + (moving ? Math.abs(s) * 0.04 * amp : Math.sin(time * 1.6) * 0.004);
    T.bodyRotX = 0;
    T.twist = moving ? s * 0.25 * amp : 0;
    T.headX = 0;

    if (this.dribbling && moving) {
      // close control: shorter strides, head down, arms low
      T.legLx *= 0.8;
      T.legRx *= 0.8;
      T.armLx *= 0.55;
      T.armRx *= 0.55;
      T.lean += 0.06;
      T.headX = 0.2;
    }
    if (this.isGK && !this.busy) {
      T.bodyY -= 0.07;
      T.kneeL += 0.25;
      T.kneeR += 0.25;
      T.legLx -= 0.18;
      T.legRx -= 0.18;
      T.legLz = 0.14;
      T.legRz = -0.14;
      T.armLz = 0.65;
      T.armRz = -0.65;
      T.armLx = -0.5 + (moving ? s * 0.3 : 0);
      T.armRx = -0.5 - (moving ? s * 0.3 : 0);
      T.elbowL = -0.6;
      T.elbowR = -0.6;
      T.lean = Math.max(T.lean, 0.15);
      if (this.holding) {
        T.armLx = T.armRx = -1.15;
        T.armLz = 0.2;
        T.armRz = -0.2;
        T.elbowL = T.elbowR = -1.2;
      }
    }

    const sm = (x: number) => x * x * (3 - 2 * x);
    const clamp01 = (x: number) => Math.max(0, Math.min(1, x));

    if (!this.isGK && this.holding && this.throwPose) {
      T.armLx = T.armRx = -2.9;
      T.armLz = 0.28;
      T.armRz = -0.28;
      T.elbowL = T.elbowR = -0.35;
      T.lean = -0.1;
      T.headX = -0.2;
    }

    switch (this.action) {
      case 'HEADER': {
        const k = sm(clamp01(t / 0.08)) * (1 - sm(clamp01((t - 0.24) / 0.2)));
        T.bodyY = 0.95 + Math.sin(t * 7) * 0.13 * k;
        T.lean = 0.6 * k;
        T.headX = 0.38 * k;
        T.armLz = 1.2 * k;
        T.armRz = -1.2 * k;
        T.armLx = -0.3 * k;
        T.armRx = -0.3 * k;
        T.kneeL = T.kneeR = 0.25 * k;
        break;
      }
      case 'ROULETTE': {
        const k = sm(clamp01(t / 0.1)) * (1 - sm(clamp01((t - 0.45) / 0.15)));
        T.bodyY = 0.92 + Math.sin(t * 12) * 0.06 * k;
        T.roll = Math.sin(t * 12) * 0.35 * k;
        T.twist = Math.sin(t * 12) * 0.8 * k;
        T.kneeL = 0.8 * k;
        T.kneeR = 0.6 * k;
        T.armLx = -0.8 * k;
        T.armRx = 0.8 * k;
        T.armLz = 0.6 * k;
        T.armRz = -0.6 * k;
        T.lean = 0.22 * k;
        break;
      }
      case 'SKILL': {
        // rapid step-overs with a body feint
        const k = sm(clamp01(t / 0.08)) * (1 - sm(clamp01((t - 0.42) / 0.16)));
        const ph2 = t * 30;
        T.legRx = Math.sin(ph2) * 0.95 * k;
        T.legLx = -Math.sin(ph2) * 0.95 * k;
        T.kneeR = Math.max(0, Math.sin(ph2)) * 1.0 * k;
        T.kneeL = Math.max(0, -Math.sin(ph2)) * 1.0 * k;
        T.legLz = 0.18 * k;
        T.legRz = -0.18 * k;
        T.roll = Math.sin(t * 15) * 0.4 * k;
        T.twist = Math.sin(t * 15 + 1) * 0.7 * k;
        T.lean += 0.14 * k;
        T.armLz = 0.7 * k;
        T.armRz = -0.7 * k;
        break;
      }
      case 'POWER_SHOT': {
        // Deep backswing and follow-through sell a heavier strike.
        const wind = sm(clamp01(t / 0.2));
        const strike = sm(clamp01((t - 0.2) / 0.14));
        const recover = sm(clamp01((t - 0.45) / 0.22));
        T.legRx = (wind * 1.6) * (1 - strike) + (-strike * 2.2) * (1 - recover);
        T.kneeR = (wind * 1.7) * (1 - strike) + (0.35 * strike) * (1 - recover);
        T.legLx = -0.35 * (1 - recover);
        T.kneeL = 0.55 * (1 - recover);
        T.lean = (wind * 0.18) * (1 - strike) + (0.52 * strike) * (1 - recover);
        T.armLx = -1.2 * strike * (1 - recover);
        T.armRx = 1.1 * strike * (1 - recover);
        T.armLz = 1.25 * (1 - recover);
        T.armRz = -1.25 * (1 - recover);
        T.twist = (0.55 * strike - 0.45 * wind) * (1 - recover);
        T.bodyY = 0.91;
        break;
      }
      case 'FINESSE': {
        // curved instep stroke
        const wind = sm(clamp01(t / 0.08));
        const strike = sm(clamp01((t - 0.08) / 0.12));
        const recover = sm(clamp01((t - 0.28) / 0.18));
        T.legRx = (wind * 0.85) * (1 - strike) + (-strike * 1.4) * (1 - recover);
        T.legRz = (0.35 * strike) * (1 - recover);
        T.kneeR = (wind * 1.1) * (1 - strike) + (0.4 * strike) * (1 - recover);
        T.lean = 0.18 * strike * (1 - recover);
        T.twist = (0.4 * strike) * (1 - recover);
        T.armLx = -0.8 * strike;
        T.armRx = 0.7 * strike;
        T.bodyY = 0.93;
        break;
      }
      case 'KICK': {
        const pw = this.actionPower;
        // wind-up -> strike -> follow-through
        const wind = sm(clamp01(t / 0.07));
        const strike = sm(clamp01((t - 0.07) / 0.09));
        const recover = sm(clamp01((t - 0.25) / 0.17));
        const swing = (wind * (0.7 + 0.4 * pw) - strike * (1.35 + 1.35 * pw) - 0) * (1 - recover);
        // right leg (x = -0.105) kicks
        T.legRx = swing > 0 ? swing : swing;
        T.legRx = (wind * (0.8 + 0.6 * pw)) * (1 - strike) + (-strike * (1.2 + 1.0 * pw)) * (1 - recover) * 1;
        T.kneeR = (wind * 1.4) * (1 - strike) + 0.25 * strike * (1 - recover);
        T.legLx = -0.12 - 0.1 * pw;
        T.kneeL = 0.35;
        T.lean = 0.05 + (0.28 + 0.12 * pw) * strike * (1 - recover) - 0.18 * wind * (1 - strike);
        T.armLx = -0.6 * strike;
        T.armRx = 0.5 * strike;
        T.armLz = 0.9 * wind;
        T.armRz = -0.9 * wind;
        T.twist = (0.35 * strike - 0.3 * wind) * (1 - recover);
        T.bodyY = 0.93;
        break;
      }
      case 'TACKLE': {
        const k = sm(clamp01(t / 0.12)) * (1 - sm(clamp01((t - 0.32) / 0.2)));
        T.legRx = -1.25 * k;
        T.kneeR = 0.15 * k;
        T.legLx = 0.45 * k;
        T.kneeL = 0.9 * k;
        T.lean = 0.45 * k + 0.1;
        T.bodyY = 0.95 - 0.2 * k;
        T.armLz = 1.0 * k;
        T.armRz = -1.0 * k;
        T.armLx = -0.4 * k;
        T.armRx = -0.4 * k;
        break;
      }
      case 'SLIDE': {
        const k = sm(clamp01(t / 0.14)) * (1 - sm(clamp01((t - 0.75) / 0.25)));
        T.bodyRotX = -1.28 * k;
        T.lean = 0;
        T.bodyY = 0.95 - 0.64 * k;
        T.legRx = -0.25 * k;
        T.legLx = 0.1 * k;
        T.kneeL = 0.9 * k;
        T.kneeR = 0.05;
        T.armLx = 1.1 * k;
        T.armRx = 0.9 * k;
        T.armLz = 0.7 * k;
        T.armRz = -0.7 * k;
        T.elbowL = T.elbowR = -0.3;
        T.headX = 0.5 * k;
        break;
      }
      case 'FALL': {
        const down = sm(clamp01(t / 0.22));
        const up = sm(clamp01((t - this.actionDur * 0.65) / (this.actionDur * 0.35)));
        const k = down * (1 - up);
        T.bodyRotX = -1.35 * k;
        T.lean = 0;
        T.bodyY = 0.95 - 0.72 * k;
        T.legLx = -0.2 * k;
        T.legRx = -0.35 * k;
        T.kneeL = 0.4 * k;
        T.kneeR = 0.2 * k;
        T.armLx = -0.5 * k;
        T.armRx = -0.3 * k;
        T.armLz = 0.8 * k;
        T.armRz = -0.8 * k;
        break;
      }
      case 'SAVE': {
        const k = sm(clamp01(t / 0.18)) * (1 - sm(clamp01((t - 0.6) / 0.4)));
        const side = Math.max(-1, Math.min(1, this.diveLocal()));
        T.roll = -1.25 * side * k;
        T.bodyRotX = 0;
        T.lean = 0.15 * k;
        T.bodyY = 0.95 - 0.1 * k + this.diveHeight * 0.3 * k - 0.35 * (1 - this.diveHeight) * k;
        T.armLx = T.armRx = -2.9 * k;
        T.armLz = 0.2 * k;
        T.armRz = -0.2 * k;
        T.elbowL = T.elbowR = -0.1;
        T.legLz = 0.35 * k;
        T.legRz = -0.35 * k;
        T.legLx = 0.2 * k;
        T.legRx = 0.3 * k;
        T.kneeL = 0.4 * k;
        T.kneeR = 0.6 * k;
        break;
      }
      case 'CELEBRATE': {
        const hop = Math.abs(Math.sin(t * 7.5 + this.index));
        const k = sm(clamp01(t / 0.2));
        T.bodyY = 0.95 + hop * 0.22 * k;
        T.armLx = T.armRx = -2.8 * k + Math.sin(t * 15) * 0.25 * k;
        T.armLz = 0.45 * k;
        T.armRz = -0.45 * k;
        T.elbowL = T.elbowR = -0.25;
        T.legLx = -0.1 * hop;
        T.legRx = -0.1 * hop;
        T.kneeL = T.kneeR = hop * 0.7;
        T.lean = -0.12 * k;
        T.headX = -0.3 * k;
        T.twist = Math.sin(t * 6) * 0.3 * k;
        break;
      }
      default:
        break;
    }
    if (this.stunned > 0 && this.action === 'IDLE') {
      T.lean += 0.25;
      T.roll = Math.sin(time * 18) * 0.08;
    }
    applyPose(this.rig, dt, this.action === 'KICK' ? 30 : this.action === 'SLIDE' || this.action === 'FALL' ? 22 : 15);

    // blob shadow scale
    if (this.blob.visible) this.blob.scale.set(1.5, 1, 1.5);
  }

  /** dive direction projected on the keeper's local left axis */
  private diveLocal(): number {
    const lx = Math.cos(this.yaw);
    const lz = -Math.sin(this.yaw);
    return this.diveDir.x * lx + this.diveDir.z * lz;
  }
}
