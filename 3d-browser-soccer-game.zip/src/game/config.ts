// Static game data: teams, archetypes, difficulty, tactics, pitch specs, unlocks, stadium themes.
// Everything here is original & fictional. Add new teams / stadiums / sizes by extending these tables.

export type Pos = 'GK' | 'DEF' | 'MID' | 'FWD';
export type Archetype =
  | 'Speedster'
  | 'Playmaker'
  | 'Finisher'
  | 'Defender'
  | 'Target Forward'
  | 'Box-to-Box'
  | 'Goalkeeper';

export interface Stats {
  speed: number;
  acceleration: number;
  shooting: number;
  passing: number;
  dribbling: number;
  defending: number;
  physical: number;
  stamina: number;
  ballControl: number;
}

export interface PlayerDef {
  id: string;
  name: string;
  number: number;
  pos: Pos;
  archetype: Archetype;
  stats: Stats;
  hair: number;
  skin: number;
}

export interface TeamDef {
  id: string;
  name: string;
  short: string;
  primary: string;
  secondary: string;
  rating: number;
  attack: number;
  midfield: number;
  defense: number;
  goalkeeper: number;
  crest: number;
  city: string;
  /** national teams render a flag instead of a club crest */
  flag?: { kind: 'h3' | 'v3' | 'cross' | 'disc' | 'diamond'; c: string[] };
  nation?: boolean;
}

export const TEAMS: TeamDef[] = [
  { id: 'mumbai', name: 'Mumbai Falcons', short: 'MUF', city: 'Mumbai', primary: '#1d6fe0', secondary: '#ffb81c', rating: 78, attack: 80, midfield: 77, defense: 75, goalkeeper: 76, crest: 0 },
  { id: 'london', name: 'London Royals', short: 'LDR', city: 'London', primary: '#c8102e', secondary: '#f4f4f4', rating: 82, attack: 81, midfield: 84, defense: 80, goalkeeper: 82, crest: 1 },
  { id: 'madrid', name: 'Madrid Titans', short: 'MAT', city: 'Madrid', primary: '#f2f2f2', secondary: '#6b2fb3', rating: 84, attack: 86, midfield: 83, defense: 81, goalkeeper: 80, crest: 2 },
  { id: 'tokyo', name: 'Tokyo Strikers', short: 'TKS', city: 'Tokyo', primary: '#e8212b', secondary: '#16181d', rating: 77, attack: 79, midfield: 80, defense: 72, goalkeeper: 74, crest: 3 },
  { id: 'rio', name: 'Rio United', short: 'RIU', city: 'Rio', primary: '#17a64b', secondary: '#ffd400', rating: 80, attack: 85, midfield: 79, defense: 72, goalkeeper: 75, crest: 4 },
  { id: 'berlin', name: 'Berlin Wolves', short: 'BEW', city: 'Berlin', primary: '#222a35', secondary: '#e23b3b', rating: 81, attack: 77, midfield: 80, defense: 85, goalkeeper: 83, crest: 5 },
  { id: 'paris', name: 'Paris Eagles', short: 'PAE', city: 'Paris', primary: '#0b2a6b', secondary: '#e9e9e9', rating: 79, attack: 80, midfield: 81, defense: 76, goalkeeper: 74, crest: 6 },
  { id: 'newyork', name: 'New York FC', short: 'NYF', city: 'New York', primary: '#31b8e8', secondary: '#101a2b', rating: 76, attack: 75, midfield: 78, defense: 75, goalkeeper: 77, crest: 7 },
];

// National teams (International Cup). Plain country names + simplified flags; all players are fictional.
export const NATIONS: TeamDef[] = [
  { id: 'n_bra', name: 'Brazil', short: 'BRA', city: 'Brazil', primary: '#f7d417', secondary: '#0b8f3d', rating: 86, attack: 89, midfield: 85, defense: 80, goalkeeper: 82, crest: 0, nation: true, flag: { kind: 'diamond', c: ['#0b8f3d', '#f7d417', '#1b3f9c'] } },
  { id: 'n_arg', name: 'Argentina', short: 'ARG', city: 'Argentina', primary: '#7ec8f0', secondary: '#ffffff', rating: 85, attack: 87, midfield: 84, defense: 82, goalkeeper: 84, crest: 0, nation: true, flag: { kind: 'h3', c: ['#74acdf', '#ffffff', '#74acdf'] } },
  { id: 'n_fra', name: 'France', short: 'FRA', city: 'France', primary: '#1c3f94', secondary: '#e0262f', rating: 86, attack: 88, midfield: 84, defense: 83, goalkeeper: 83, crest: 0, nation: true, flag: { kind: 'v3', c: ['#1c3f94', '#ffffff', '#e0262f'] } },
  { id: 'n_ger', name: 'Germany', short: 'GER', city: 'Germany', primary: '#f2f2f2', secondary: '#16181d', rating: 83, attack: 82, midfield: 85, defense: 82, goalkeeper: 84, crest: 0, nation: true, flag: { kind: 'h3', c: ['#16181d', '#dd0000', '#ffce00'] } },
  { id: 'n_esp', name: 'Spain', short: 'ESP', city: 'Spain', primary: '#d8202a', secondary: '#f4c20d', rating: 84, attack: 83, midfield: 88, defense: 80, goalkeeper: 82, crest: 0, nation: true, flag: { kind: 'h3', c: ['#c60b1e', '#ffc400', '#c60b1e'] } },
  { id: 'n_eng', name: 'England', short: 'ENG', city: 'England', primary: '#ffffff', secondary: '#1c2e6b', rating: 84, attack: 85, midfield: 83, defense: 81, goalkeeper: 82, crest: 0, nation: true, flag: { kind: 'cross', c: ['#ffffff', '#ce1124'] } },
  { id: 'n_jpn', name: 'Japan', short: 'JPN', city: 'Japan', primary: '#1e3a8a', secondary: '#ffffff', rating: 79, attack: 78, midfield: 81, defense: 77, goalkeeper: 76, crest: 0, nation: true, flag: { kind: 'disc', c: ['#ffffff', '#bc002d'] } },
  { id: 'n_ita', name: 'Italy', short: 'ITA', city: 'Italy', primary: '#1d6fe0', secondary: '#ffffff', rating: 82, attack: 79, midfield: 82, defense: 86, goalkeeper: 85, crest: 0, nation: true, flag: { kind: 'v3', c: ['#009246', '#ffffff', '#ce2b37'] } },
];
export const ALL_TEAMS: TeamDef[] = [...TEAMS, ...NATIONS];
export const getTeam = (id: string): TeamDef => ALL_TEAMS.find((t) => t.id === id) ?? TEAMS[0];

/** jersey pattern per team: 0 solid · 1 vertical stripes · 2 hoops · 3 sash · 4 split */
const TEAM_PATTERN: Record<string, number> = { mumbai: 3, london: 1, madrid: 0, tokyo: 2, rio: 0, berlin: 4, paris: 3, newyork: 0 };
export const teamPattern = (id: string) => TEAM_PATTERN[id] ?? 0;

// ------------------------------------------------------------------ players
const FIRST = ['Arjun', 'Leo', 'Mateo', 'Kenji', 'Davi', 'Jonas', 'Luc', 'Mason', 'Ravi', 'Oscar', 'Tariq', 'Niko', 'Hugo', 'Ivan', 'Zane', 'Felix', 'Sami', 'Rory', 'Dante', 'Kai', 'Elio', 'Bruno', 'Axel', 'Yuri'];
const LAST = ['Varma', 'Hale', 'Ortega', 'Sato', 'Costa', 'Brandt', 'Moreau', 'Cole', 'Iyer', 'Lindqvist', 'Haddad', 'Petrov', 'Duval', 'Novak', 'Rowe', 'Keller', 'Amari', 'Quinn', 'Vidal', 'Mori', 'Santos', 'Frey', 'Okoye', 'Zhao'];

function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function mulberry(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const ARCH_MOD: Record<Archetype, Partial<Stats>> = {
  Speedster: { speed: 12, acceleration: 12, dribbling: 6, physical: -6, defending: -10 },
  Playmaker: { passing: 12, ballControl: 8, dribbling: 5, physical: -6, shooting: -2 },
  Finisher: { shooting: 13, ballControl: 4, speed: 3, defending: -14, passing: -4 },
  Defender: { defending: 14, physical: 8, shooting: -12, dribbling: -8, speed: -2 },
  'Target Forward': { shooting: 8, physical: 14, speed: -6, acceleration: -6, ballControl: 3, dribbling: -4 },
  'Box-to-Box': { stamina: 12, physical: 5, passing: 3, defending: 4, shooting: -2 },
  Goalkeeper: { defending: 6, physical: 6, shooting: -30, dribbling: -25, speed: -12 },
};

const clampStat = (n: number) => Math.max(35, Math.min(97, Math.round(n)));

function makeStats(base: number, arch: Archetype, rnd: () => number): Stats {
  const m = ARCH_MOD[arch];
  const s = (k: keyof Stats) => clampStat(base + (m[k] ?? 0) + (rnd() - 0.5) * 8);
  return {
    speed: s('speed'), acceleration: s('acceleration'), shooting: s('shooting'), passing: s('passing'),
    dribbling: s('dribbling'), defending: s('defending'), physical: s('physical'), stamina: s('stamina'), ballControl: s('ballControl'),
  };
}

interface Slot { pos: Pos; arch: Archetype[] }
const ROSTER_SLOTS: Slot[] = [
  { pos: 'GK', arch: ['Goalkeeper'] },
  { pos: 'DEF', arch: ['Defender'] },
  { pos: 'MID', arch: ['Playmaker', 'Box-to-Box'] },
  { pos: 'FWD', arch: ['Finisher', 'Speedster', 'Target Forward'] },
  { pos: 'DEF', arch: ['Defender'] },
  { pos: 'FWD', arch: ['Speedster', 'Finisher'] },
  { pos: 'MID', arch: ['Box-to-Box', 'Playmaker'] },
  { pos: 'DEF', arch: ['Defender'] },
  { pos: 'MID', arch: ['Playmaker'] },
  { pos: 'FWD', arch: ['Target Forward'] },
  { pos: 'DEF', arch: ['Defender'] },
];

const rosterCache = new Map<string, PlayerDef[]>();

/** Deterministic fictional roster for a team (ordered by lineup priority). */
export function getRoster(team: TeamDef): PlayerDef[] {
  const cached = rosterCache.get(team.id);
  if (cached) return cached;
  const rnd = mulberry(hashStr(team.id));
  const used = new Set<string>();
  const nums = new Set<number>();
  const roster: PlayerDef[] = ROSTER_SLOTS.map((slot, i) => {
    const arch = slot.arch[Math.floor(rnd() * slot.arch.length)];
    const base = slot.pos === 'GK' ? team.goalkeeper : slot.pos === 'DEF' ? team.defense : slot.pos === 'MID' ? team.midfield : team.attack;
    let name = '';
    do {
      name = `${FIRST[Math.floor(rnd() * FIRST.length)]} ${LAST[Math.floor(rnd() * LAST.length)]}`;
    } while (used.has(name));
    used.add(name);
    let number = slot.pos === 'GK' ? 1 : 2 + Math.floor(rnd() * 28);
    while (nums.has(number)) number++;
    nums.add(number);
    return {
      id: `${team.id}_${i}`, name, number, pos: slot.pos, archetype: arch,
      stats: makeStats(base - 6, arch, rnd), hair: Math.floor(rnd() * 6), skin: Math.floor(rnd() * 6),
    };
  });
  rosterCache.set(team.id, roster);
  return roster;
}

// ------------------------------------------------------------------ formations
export interface FormationSlot { pos: Pos; u: number; v: number }
/** u: 0 = own goal line .. 1 = opponent goal line.  v: -1..1 across the pitch width. GK is added automatically. */
export const FORMATIONS: Record<number, FormationSlot[]> = {
  4: [
    { pos: 'DEF', u: 0.24, v: 0 },
    { pos: 'MID', u: 0.42, v: -0.6 },
    { pos: 'MID', u: 0.42, v: 0.6 },
    { pos: 'FWD', u: 0.64, v: 0 },
  ],
  1: [{ pos: 'MID', u: 0.34, v: 0 }],
  3: [
    { pos: 'DEF', u: 0.24, v: 0 },
    { pos: 'MID', u: 0.44, v: -0.55 },
    { pos: 'FWD', u: 0.64, v: 0.55 },
  ],
  5: [
    { pos: 'DEF', u: 0.22, v: -0.5 },
    { pos: 'DEF', u: 0.22, v: 0.5 },
    { pos: 'MID', u: 0.42, v: 0 },
    { pos: 'FWD', u: 0.64, v: -0.45 },
    { pos: 'FWD', u: 0.64, v: 0.45 },
  ],
  7: [
    { pos: 'DEF', u: 0.2, v: -0.55 },
    { pos: 'DEF', u: 0.2, v: 0 },
    { pos: 'DEF', u: 0.2, v: 0.55 },
    { pos: 'MID', u: 0.42, v: -0.4 },
    { pos: 'MID', u: 0.42, v: 0.4 },
    { pos: 'FWD', u: 0.65, v: 0 },
  ],
};
export const SUPPORTED_SIZES = [1, 3, 5];

// ------------------------------------------------------------------ pitch
export interface PitchSpec {
  L: number; W: number; goalW: number; goalH: number; goalD: number;
  boxD: number; boxW: number; sixD: number; sixW: number; circleR: number; spotD: number;
  boardX: number; boardZ: number;
  /** street cage: no out-of-play, bouncy walls, small goals */
  street?: boolean;
  wallBounce?: number;
}
export function makePitch(size: number, street = false): PitchSpec {
  if (street) {
    const sd: Record<number, [number, number]> = { 3: [34, 20], 4: [38, 22], 5: [44, 26] };
    const [L, W] = sd[size] ?? sd[3];
    return {
      L, W, goalW: 4.6, goalH: 1.9, goalD: 1.3, boxD: 5, boxW: 11, sixD: 2, sixW: 7, circleR: 3.4, spotD: 5.5,
      boardX: L / 2 + 1.9, boardZ: W / 2 + 0.9, street: true, wallBounce: 0.82,
    };
  }
  const dims: Record<number, [number, number]> = { 1: [40, 26], 3: [60, 38], 5: [76, 48], 7: [90, 56], 11: [105, 68] };
  const [L, W] = dims[size] ?? dims[3];
  const goalW = Math.min(7.32, 5.4 + (L - 40) * 0.03);
  return {
    L, W, goalW, goalH: 2.44, goalD: 2.1,
    boxD: L * 0.16, boxW: W * 0.58, sixD: L * 0.055, sixW: goalW + 5.5,
    circleR: Math.min(9.15, L * 0.1), spotD: L * 0.105,
    boardX: L / 2 + 4.2, boardZ: W / 2 + 3,
  };
}

// ------------------------------------------------------------------ difficulty & tactics
export type Difficulty = 'EASY' | 'NORMAL' | 'HARD' | 'PRO';
export interface DifficultyDef {
  think: number; // seconds between AI decisions (reaction time)
  gkReaction: number; // seconds before keeper reacts to a shot
  gkSave: number; // base save quality multiplier
  posNoise: number; // positioning error in meters
  passError: number; // pass inaccuracy multiplier
  shotError: number; // shot inaccuracy multiplier
  tackle: number; // tackle success multiplier
  decision: number; // chance of picking the best option instead of a random one
  speed: number; // movement multiplier (kept near 1.0 – difficulty is about decisions)
  pressRange: number; // multiplier on press range
  awareness: number; // how well they anticipate ball path & track runners
}
export const DIFFICULTY: Record<Difficulty, DifficultyDef> = {
  EASY: { think: 0.5, gkReaction: 0.42, gkSave: 0.6, posNoise: 3.2, passError: 1.6, shotError: 1.7, tackle: 0.4, decision: 0.45, speed: 0.93, pressRange: 0.6, awareness: 0.3 },
  NORMAL: { think: 0.3, gkReaction: 0.26, gkSave: 0.78, posNoise: 1.6, passError: 1.1, shotError: 1.2, tackle: 0.6, decision: 0.7, speed: 0.97, pressRange: 0.85, awareness: 0.6 },
  HARD: { think: 0.18, gkReaction: 0.16, gkSave: 0.9, posNoise: 0.8, passError: 0.85, shotError: 0.9, tackle: 0.75, decision: 0.88, speed: 1, pressRange: 1, awareness: 0.85 },
  PRO: { think: 0.1, gkReaction: 0.09, gkSave: 1.0, posNoise: 0.25, passError: 0.6, shotError: 0.65, tackle: 0.88, decision: 0.97, speed: 1, pressRange: 1.12, awareness: 1 },
};
export const DIFFICULTIES: Difficulty[] = ['EASY', 'NORMAL', 'HARD', 'PRO'];

export type Tactic = 'BALANCED' | 'ATTACKING' | 'DEFENSIVE' | 'HIGH_PRESS' | 'COUNTER_ATTACK';
export interface TacticDef {
  label: string; desc: string;
  shift: number; // formation shift toward opponent goal (fraction of pitch length)
  pressers: number; // outfield players that press ball carrier
  pressRange: number; // meters
  counter: boolean; // fast forward runs after winning possession
  width: number; // lateral spread multiplier
  mark: number; // 0..1 how tightly defenders mark opponents vs zone
  risk: number; // willingness to shoot/pass forward
}
export const TACTICS: Record<Tactic, TacticDef> = {
  BALANCED: { label: 'Balanced', desc: 'Even shape, press when close.', shift: 0, pressers: 1, pressRange: 14, counter: false, width: 1, mark: 0.5, risk: 0.5 },
  ATTACKING: { label: 'Attacking', desc: 'Push forward, take risks.', shift: 0.14, pressers: 1, pressRange: 12, counter: false, width: 1.1, mark: 0.35, risk: 0.8 },
  DEFENSIVE: { label: 'Defensive', desc: 'Sit deep, stay behind the ball.', shift: -0.12, pressers: 1, pressRange: 9, counter: false, width: 0.8, mark: 0.75, risk: 0.25 },
  HIGH_PRESS: { label: 'High Press', desc: 'Hunt the ball aggressively.', shift: 0.08, pressers: 2, pressRange: 24, counter: false, width: 1, mark: 0.8, risk: 0.55 },
  COUNTER_ATTACK: { label: 'Counter Attack', desc: 'Absorb, then break at pace.', shift: -0.05, pressers: 1, pressRange: 11, counter: true, width: 1, mark: 0.55, risk: 0.7 },
};
export const TACTIC_LIST = Object.keys(TACTICS) as Tactic[];

// ------------------------------------------------------------------ customization & unlocks
export const HAIR_STYLES = ['Short', 'Buzz', 'Long', 'Mohawk', 'Afro', 'Bald'];
export const HAIR_COLORS = ['#1a1410', '#3b2415', '#6b4423', '#c9a24b', '#8a2d1c', '#2a2a2e'];
export const SKIN_TONES = ['#f6d3b3', '#e8b48a', '#c98e62', '#a46a43', '#7a4a2d', '#4d2e1c'];
export const BOOT_COLORS: { id: string; name: string; color: string }[] = [
  { id: 'black', name: 'Shadow', color: '#15171c' },
  { id: 'white', name: 'Frost', color: '#f1f3f6' },
  { id: 'orange', name: 'Blaze', color: '#ff7a1a' },
  { id: 'lime', name: 'Neon', color: '#b6ff2e' },
  { id: 'gold', name: 'Gold', color: '#f4c430' },
  { id: 'pink', name: 'Pulse', color: '#ff3d9a' },
];
export const KIT_COLORS: { id: string; name: string; color: string }[] = [
  { id: 'red', name: 'Red', color: '#e0262f' },
  { id: 'blue', name: 'Blue', color: '#1f6fe5' },
  { id: 'green', name: 'Green', color: '#16a34a' },
  { id: 'yellow', name: 'Yellow', color: '#fbc02d' },
  { id: 'white', name: 'White', color: '#f3f4f6' },
  { id: 'black', name: 'Black', color: '#1b1e24' },
  { id: 'orange', name: 'Orange', color: '#f97316' },
  { id: 'purple', name: 'Purple', color: '#7c3aed' },
  { id: 'cyan', name: 'Cyan', color: '#06b6d4' },
  { id: 'pink', name: 'Hot Pink', color: '#ec4899' },
  { id: 'teal', name: 'Teal', color: '#0f766e' },
  { id: 'maroon', name: 'Maroon', color: '#7f1d1d' },
];

export type UnlockType = 'stadium' | 'team' | 'hair' | 'boots' | 'kit';
export interface UnlockDef { id: string; type: UnlockType; name: string; level: number; cost: number; ref: string | number }
export const UNLOCKS: UnlockDef[] = [
  { id: 'team_paris', type: 'team', name: 'Paris Eagles', level: 2, cost: 250, ref: 'paris' },
  { id: 'team_newyork', type: 'team', name: 'New York FC', level: 4, cost: 400, ref: 'newyork' },
  { id: 'stadium_sunset', type: 'stadium', name: 'Sunset Plaza', level: 3, cost: 300, ref: 'sunset' },
  { id: 'stadium_frost', type: 'stadium', name: 'Frost Dome', level: 6, cost: 600, ref: 'frost' },
  { id: 'hair_mohawk', type: 'hair', name: 'Mohawk', level: 2, cost: 120, ref: 3 },
  { id: 'hair_afro', type: 'hair', name: 'Afro', level: 3, cost: 150, ref: 4 },
  { id: 'hair_long', type: 'hair', name: 'Long', level: 2, cost: 100, ref: 2 },
  { id: 'boots_orange', type: 'boots', name: 'Blaze Boots', level: 2, cost: 100, ref: 'orange' },
  { id: 'boots_lime', type: 'boots', name: 'Neon Boots', level: 3, cost: 150, ref: 'lime' },
  { id: 'boots_pink', type: 'boots', name: 'Pulse Boots', level: 4, cost: 180, ref: 'pink' },
  { id: 'boots_gold', type: 'boots', name: 'Gold Boots', level: 5, cost: 300, ref: 'gold' },
  { id: 'kit_purple', type: 'kit', name: 'Purple Kit', level: 2, cost: 80, ref: 'purple' },
  { id: 'kit_cyan', type: 'kit', name: 'Cyan Kit', level: 3, cost: 80, ref: 'cyan' },
  { id: 'kit_pink', type: 'kit', name: 'Hot Pink Kit', level: 4, cost: 100, ref: 'pink' },
  { id: 'kit_teal', type: 'kit', name: 'Teal Kit', level: 5, cost: 100, ref: 'teal' },
  { id: 'kit_maroon', type: 'kit', name: 'Maroon Kit', level: 6, cost: 100, ref: 'maroon' },
];
export const findUnlock = (type: UnlockType, ref: string | number) => UNLOCKS.find((u) => u.type === type && u.ref === ref);

// ------------------------------------------------------------------ stadium themes
export interface StadiumTheme {
  id: string; name: string; skyTop: string; skyMid: string; skyHorizon: string; fog: string;
  grassA: string; grassB: string; standA: string; standB: string; light: number; ambient: string; sun: string; accent: string;
  street?: boolean;
}
export const STADIUMS: StadiumTheme[] = [
  { id: 'neon', name: 'Floodlight Park', skyTop: '#09110f', skyMid: '#273b34', skyHorizon: '#58645a', fog: '#26382e', grassA: '#397d42', grassB: '#316d3a', standA: '#323a35', standB: '#242b27', light: 1.35, ambient: '#cad1b5', sun: '#fff2d8', accent: '#d5dd75' },
  { id: 'sunset', name: 'Harbor Lights', skyTop: '#241b1d', skyMid: '#9a5345', skyHorizon: '#e59b68', fog: '#754c40', grassA: '#397d42', grassB: '#316d3a', standA: '#493b35', standB: '#332b27', light: 1.35, ambient: '#f0c6a6', sun: '#f9dbb9', accent: '#e89061' },
  { id: 'frost', name: 'Frost Dome', skyTop: '#6fa3d9', skyMid: '#a9cfee', skyHorizon: '#e6f2fb', fog: '#cfe3f3', grassA: '#58a860', grassB: '#4b9654', standA: '#6a7b93', standB: '#4e5d73', light: 1.5, ambient: '#e0efff', sun: '#ffffff', accent: '#7dd3fc' },
];
STADIUMS.push({
  id: 'street', name: 'Downtown Cage', street: true, skyTop: '#1a1038', skyMid: '#6a2c70', skyHorizon: '#ff8a5c', fog: '#55305f',
  grassA: '#434a5c', grassB: '#394052', standA: '#3a2d46', standB: '#2a2034', light: 1.35, ambient: '#ffd2b8', sun: '#ffcfa6', accent: '#ff4fd8',
});
/** stadiums selectable by the player (the street cage is only used by Street Soccer) */
export const PICKABLE_STADIUMS = () => STADIUMS.filter((s) => !s.street);
export const getStadium = (id: string) => STADIUMS.find((s) => s.id === id) ?? STADIUMS[0];

export const AD_BRANDS = ['NORTHLINE', 'DAYBREAK', 'FIELDWORK', 'HIGH WATER', 'OPEN LATE', 'OFFSIDE COFFEE', 'SIDENET', 'LAST TRAIN'];

// ------------------------------------------------------------------ progression
export const xpForLevel = (lvl: number) => 100 + (lvl - 1) * 60; // XP needed to go from lvl to lvl+1
export function levelFromXp(xp: number): { level: number; into: number; need: number } {
  let level = 1;
  let rest = xp;
  while (rest >= xpForLevel(level) && level < 99) {
    rest -= xpForLevel(level);
    level++;
  }
  return { level, into: rest, need: xpForLevel(level) };
}
