import { useSyncExternalStore } from 'react';
import type { Difficulty, Tactic } from './config';

export type Quality = 'LOW' | 'MEDIUM' | 'HIGH';
export type CameraMode = 'BROADCAST' | 'CLASSIC' | 'CLOSE' | 'WIDE';

/** One fixture of a league / cup competition */
export interface Fx { a: string; b: string; ga?: number; gb?: number; pens?: boolean }
/** National League (8 clubs, round robin) and International Cup (8 nations, 2 groups → semis → final) */
export interface CompState {
  kind: 'league' | 'cup';
  teamId: string;
  groups: string[][];
  rounds: Fx[][];
  ko: Fx[][];
  day: number;
  stage: 'group' | 'semi' | 'final' | 'done';
  status: 'active' | 'eliminated' | 'champion' | 'finished';
}

export interface DailyProgress {
  day: string;
  matches: number;
  goals: number;
  streetWins: number;
  claimed: string[];
}

export interface Settings {
  quality: Quality;
  resScale: 0.75 | 1;
  fps: 30 | 60;
  camera: CameraMode;
  master: number;
  music: number;
  sfx: number;
  crowd: number;
  showFps: boolean;
  aimAssist: boolean;
  autoSwitch: boolean;
  gamepad: boolean;
}

export interface Custom {
  name: string;
  number: number;
  hair: number;
  skin: number;
  boots: string;
  primary: string;
  secondary: string;
  useCustomKit: boolean;
}

export interface TMatch { a: string; b: string; ga?: number; gb?: number; winner?: string; pens?: string }
export interface TournamentState {
  teamId: string;
  rounds: TMatch[][];
  round: number;
  status: 'active' | 'eliminated' | 'champion';
}

export interface Selection {
  home: string;
  away: string;
  duration: number;
  difficulty: Difficulty;
  tactic: Tactic;
  size: number;
  stadium: string;
  streetSize: number;
  streetGoals: number;
  attempts: number;
}

export interface Stats {
  played: number; won: number; drawn: number; lost: number; goals: number; conceded: number; penaltiesScored: number; tournaments: number; freeKickBest: number;
}

export interface SaveData {
  v: number;
  settings: Settings;
  xp: number;
  coins: number;
  unlocked: string[];
  tournament: TournamentState | null;
  league: CompState | null;
  cup: CompState | null;
  daily: DailyProgress;
  custom: Custom;
  selection: Selection;
  stats: Stats;
}

export const defaultSave = (): SaveData => ({
  v: 3,
  settings: {
    quality: 'MEDIUM', resScale: 1, fps: 60, camera: 'BROADCAST', master: 0.8, music: 0.4, sfx: 0.9, crowd: 0.7,
    showFps: false, aimAssist: true, autoSwitch: true, gamepad: true,
  },
  xp: 0,
  coins: 100,
  unlocked: [],
  tournament: null,
  league: null,
  cup: null,
  daily: { day: localDayKey(), matches: 0, goals: 0, streetWins: 0, claimed: [] },
  custom: { name: 'ROOKIE', number: 10, hair: 0, skin: 1, boots: 'black', primary: '#1d6fe0', secondary: '#ffb81c', useCustomKit: false },
  selection: { home: 'mumbai', away: 'london', duration: 180, difficulty: 'NORMAL', tactic: 'BALANCED', size: 3, stadium: 'neon', streetSize: 3, streetGoals: 5, attempts: 6 },
  stats: { played: 0, won: 0, drawn: 0, lost: 0, goals: 0, conceded: 0, penaltiesScored: 0, tournaments: 0, freeKickBest: 0 },
});

const KEY = 'sidenet.save.v3';
const LEGACY_KEY = 'streetkick3d.save.v2';
const memory: { raw: string | null } = { raw: null };

function readRaw(): string | null {
  try {
    return localStorage.getItem(KEY) ?? localStorage.getItem(LEGACY_KEY);
  } catch {
    return memory.raw;
  }
}
function writeRaw(s: string) {
  memory.raw = s;
  try {
    localStorage.setItem(KEY, s);
  } catch {
    /* storage unavailable – keep in memory only */
  }
}

const isObj = (o: unknown): o is Record<string, unknown> => typeof o === 'object' && o !== null && !Array.isArray(o);
const num = (v: unknown, d: number, lo: number, hi: number) => (typeof v === 'number' && isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d);
const str = (v: unknown, d: string) => (typeof v === 'string' && v.length < 40 ? v : d);
const oneOf = <T,>(v: unknown, opts: readonly T[], d: T): T => (opts.includes(v as T) ? (v as T) : d);
const bool = (v: unknown, d: boolean) => (typeof v === 'boolean' ? v : d);

/** Merge arbitrary parsed JSON into a valid SaveData – corrupted fields fall back to defaults. */
export function sanitize(raw: unknown): SaveData {
  const d = defaultSave();
  if (!isObj(raw)) return d;
  const s = isObj(raw.settings) ? raw.settings : {};
  const c = isObj(raw.custom) ? raw.custom : {};
  const sel = isObj(raw.selection) ? raw.selection : {};
  const st = isObj(raw.stats) ? raw.stats : {};
  const out: SaveData = {
    v: d.v,
    settings: {
      quality: oneOf(s.quality, ['LOW', 'MEDIUM', 'HIGH'] as const, d.settings.quality),
      resScale: oneOf(s.resScale, [0.75, 1] as const, d.settings.resScale),
      fps: oneOf(s.fps, [30, 60] as const, d.settings.fps),
      camera: oneOf(s.camera, ['BROADCAST', 'CLASSIC', 'CLOSE', 'WIDE'] as const, d.settings.camera),
      master: num(s.master, d.settings.master, 0, 1),
      music: num(s.music, d.settings.music, 0, 1),
      sfx: num(s.sfx, d.settings.sfx, 0, 1),
      crowd: num(s.crowd, d.settings.crowd, 0, 1),
      showFps: bool(s.showFps, d.settings.showFps),
      aimAssist: bool(s.aimAssist, d.settings.aimAssist),
      autoSwitch: bool(s.autoSwitch, d.settings.autoSwitch),
      gamepad: bool(s.gamepad, d.settings.gamepad),
    },
    xp: num(raw.xp, 0, 0, 1e7),
    coins: num(raw.coins, d.coins, 0, 1e8),
    unlocked: Array.isArray(raw.unlocked) ? raw.unlocked.filter((x): x is string => typeof x === 'string').slice(0, 200) : [],
    tournament: null,
    league: null,
    cup: null,
    daily: d.daily,
    custom: {
      name: str(c.name, d.custom.name).slice(0, 12),
      number: Math.round(num(c.number, d.custom.number, 1, 99)),
      hair: Math.round(num(c.hair, d.custom.hair, 0, 5)),
      skin: Math.round(num(c.skin, d.custom.skin, 0, 5)),
      boots: str(c.boots, d.custom.boots),
      primary: /^#[0-9a-f]{6}$/i.test(String(c.primary)) ? String(c.primary) : d.custom.primary,
      secondary: /^#[0-9a-f]{6}$/i.test(String(c.secondary)) ? String(c.secondary) : d.custom.secondary,
      useCustomKit: bool(c.useCustomKit, d.custom.useCustomKit),
    },
    selection: {
      home: str(sel.home, d.selection.home),
      away: str(sel.away, d.selection.away),
      duration: oneOf(sel.duration, [60, 120, 180, 300] as const, 180),
      difficulty: oneOf(sel.difficulty, ['EASY', 'NORMAL', 'HARD', 'PRO'] as const, 'NORMAL'),
      tactic: oneOf(sel.tactic, ['BALANCED', 'ATTACKING', 'DEFENSIVE', 'HIGH_PRESS', 'COUNTER_ATTACK'] as const, 'BALANCED'),
      size: oneOf(sel.size, [1, 3, 5] as const, 3),
      stadium: str(sel.stadium, d.selection.stadium),
      streetSize: oneOf(sel.streetSize, [3, 4] as const, 3),
      streetGoals: oneOf(sel.streetGoals, [3, 5, 7] as const, 5),
      attempts: oneOf(sel.attempts, [5, 6, 8] as const, 6),
    },
    stats: {
      played: num(st.played, 0, 0, 1e6), won: num(st.won, 0, 0, 1e6), drawn: num(st.drawn, 0, 0, 1e6), lost: num(st.lost, 0, 0, 1e6),
      goals: num(st.goals, 0, 0, 1e6), conceded: num(st.conceded, 0, 0, 1e6), penaltiesScored: num(st.penaltiesScored, 0, 0, 1e6), tournaments: num(st.tournaments, 0, 0, 1e6), freeKickBest: num(st.freeKickBest, 0, 0, 100),
    },
  };
  // tournament – validate loosely
  const t = raw.tournament;
  if (isObj(t) && Array.isArray(t.rounds) && t.rounds.length === 3 && typeof t.teamId === 'string') {
    try {
      const rounds = (t.rounds as unknown[]).map((r) =>
        (Array.isArray(r) ? r : []).map((m) => {
          const mm = isObj(m) ? m : {};
          return {
            a: str(mm.a, ''), b: str(mm.b, ''),
            ga: typeof mm.ga === 'number' ? mm.ga : undefined, gb: typeof mm.gb === 'number' ? mm.gb : undefined,
            winner: typeof mm.winner === 'string' ? mm.winner : undefined, pens: typeof mm.pens === 'string' ? mm.pens : undefined,
          } as TMatch;
        }),
      );
      if (rounds[0].length === 4 && rounds[0].every((m) => m.a && m.b)) {
        out.tournament = {
          teamId: t.teamId, rounds, round: Math.round(num(t.round, 0, 0, 2)),
          status: oneOf(t.status, ['active', 'eliminated', 'champion'] as const, 'active'),
        };
      }
    } catch {
      out.tournament = null;
    }
  }
  out.league = sanitizeComp(raw.league, 'league');
  out.cup = sanitizeComp(raw.cup, 'cup');
  const dy = isObj(raw.daily) ? raw.daily : {};
  out.daily = {
    day: str(dy.day, d.daily.day),
    matches: num(dy.matches, 0, 0, 1000),
    goals: num(dy.goals, 0, 0, 10000),
    streetWins: num(dy.streetWins, 0, 0, 1000),
    claimed: Array.isArray(dy.claimed) ? dy.claimed.filter((x): x is string => typeof x === 'string').slice(0, 20) : [],
  };
  return out;
}

export function localDayKey(date = new Date()): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

/** Reset daily objectives at local midnight; a small offline-friendly replacement for server dailies. */
export function ensureDaily(): DailyProgress {
  const day = localDayKey();
  if (data.daily.day !== day) {
    updateSave((d) => {
      d.daily = { day, matches: 0, goals: 0, streetWins: 0, claimed: [] };
    });
  }
  return data.daily;
}

function sanitizeComp(c: unknown, kind: 'league' | 'cup'): CompState | null {
  try {
    if (!isObj(c) || c.kind !== kind || typeof c.teamId !== 'string') return null;
    const fx = (m: unknown): Fx | null => {
      if (!isObj(m) || typeof m.a !== 'string' || typeof m.b !== 'string') return null;
      return {
        a: m.a, b: m.b, ga: typeof m.ga === 'number' ? m.ga : undefined, gb: typeof m.gb === 'number' ? m.gb : undefined,
        pens: m.pens === true ? true : undefined,
      };
    };
    const list = (v: unknown): Fx[][] | null => {
      if (!Array.isArray(v)) return null;
      const out: Fx[][] = [];
      for (const r of v) {
        if (!Array.isArray(r)) return null;
        const row: Fx[] = [];
        for (const m of r) {
          const f = fx(m);
          if (!f) return null;
          row.push(f);
        }
        out.push(row);
      }
      return out;
    };
    const rounds = list(c.rounds);
    const ko = list(c.ko);
    if (!rounds || !ko || !Array.isArray(c.groups) || rounds.length === 0) return null;
    const groups = c.groups.map((g) => (Array.isArray(g) ? g.filter((x): x is string => typeof x === 'string') : []));
    if (groups.length === 0 || groups.some((g) => g.length < 2)) return null;
    return {
      kind, teamId: c.teamId, groups, rounds, ko,
      day: Math.round(num(c.day, 0, 0, rounds.length)),
      stage: oneOf(c.stage, ['group', 'semi', 'final', 'done'] as const, 'group'),
      status: oneOf(c.status, ['active', 'eliminated', 'champion', 'finished'] as const, 'active'),
    };
  } catch {
    return null;
  }
}

function load(): SaveData {
  try {
    const raw = readRaw();
    if (!raw) return defaultSave();
    return sanitize(JSON.parse(raw));
  } catch {
    return defaultSave();
  }
}

let data: SaveData = load();
const listeners = new Set<() => void>();

export const getSave = () => data;
export function updateSave(fn: (d: SaveData) => SaveData | void) {
  const copy: SaveData = JSON.parse(JSON.stringify(data));
  const res = fn(copy);
  data = sanitize(res ?? copy);
  writeRaw(JSON.stringify(data));
  listeners.forEach((l) => l());
}
export function resetSave() {
  data = defaultSave();
  try {
    localStorage.removeItem(KEY);
    localStorage.removeItem(LEGACY_KEY);
  } catch {
    /* ignore */
  }
  memory.raw = null;
  listeners.forEach((l) => l());
}
export const subscribe = (l: () => void) => {
  listeners.add(l);
  return () => listeners.delete(l);
};
export function useSave(): SaveData {
  return useSyncExternalStore(subscribe, getSave, getSave);
}
