import {
  AdditiveBlending, BufferAttribute, BufferGeometry, CircleGeometry, ConeGeometry, Group, Mesh, MeshBasicMaterial,
  Line, LineBasicMaterial, Points, PointsMaterial, RingGeometry, Vector3, type Scene,
} from 'three';
import {
  DIFFICULTY, FORMATIONS, getRoster, TACTICS, teamPattern, type Difficulty, type DifficultyDef, type PlayerDef, type Pos, type Tactic, type TeamDef, type PitchSpec,
  makePitch,
} from './config';
import { Ball } from './ball';
import { angDiff, Footballer, type SetPiece } from './entities';
import { bestPass, laneClearance, steerToTarget, thinkOutfield, updateKeeper, chaseTarget } from './ai';
import { audio } from './audio';
import { contrastColor, gkColor, hairColorFor, type KitSpec } from './models';
import type { Input } from './input';
import type { Custom, Settings } from './save';

export type Phase = 'KICKOFF' | 'PLAY' | 'GOAL' | 'RESET' | 'HALFTIME' | 'FULLTIME';

export interface MatchConfig {
  mode: 'match' | 'training';
  home: TeamDef;
  away: TeamDef;
  homeKit: { primary: string; secondary: string; pattern?: number };
  size: number;
  duration: number;
  difficulty: Difficulty;
  tactic: Tactic;
  knockout: boolean;
  /** street cage rules: no keepers, walls instead of out-of-play, first to N goals */
  street?: boolean;
  goalTarget?: number;
  custom: Custom;
  level: number;
  settings: Settings;
}

export interface MatchResult {
  homeScore: number;
  awayScore: number;
  winner: 0 | 1 | -1;
  pens: boolean;
  shots: [number, number];
  shotsOn: [number, number];
  possession: [number, number];
  scorers: { name: string; team: 0 | 1; minute: string }[];
  /** how the human's player performed (0–10) */
  rating?: number;
  manOfMatch?: string;
  contrib?: { goals: number; shots: number; passes: number; tackles: number };
}

export interface TeamRT {
  def: TeamDef;
  players: Footballer[];
  outfield: Footballer[];
  gk: Footballer | null;
  dir: 1 | -1;
  tactic: Tactic;
  score: number;
  shots: number;
  shotsOn: number;
  possTime: number;
  kit: { primary: string; secondary: string; pattern?: number };
}

export interface HudState {
  mode: 'match' | 'penalty' | 'training' | 'freekick';
  homeName: string; awayName: string; homeShort: string; awayShort: string;
  homeColor: string; awayColor: string; homeScore: number; awayScore: number;
  clock: string; half: string; phase: string;
  banner: { text: string; sub: string; kind: 'goal' | 'info' | 'final' } | null;
  stamina: number; shootCharge: number; passCharge: number;
  playerName: string; playerNumber: number; playerPos: string; tactic: Tactic;
  canSwitch?: boolean;
  attacking?: boolean;
  face?: { skin: number; hair: number; hairColor: string };
  difficulty: string;
  extra: { label: string; value: string | number }[];
  hint: string;
  countdown: number;
  setPiece?: { kind: 'throw' | 'corner'; team: number; state: 'fetch' | 'ready' };
  // Shot presentation
  powerShotActive?: boolean;
  powerShotCharge?: number;
  timedState?: 'green' | 'early' | 'late' | null;
  lastShotSpeedKmh?: number;
  lastShotType?: 'normal' | 'power' | 'finesse' | 'chip' | 'low' | 'header';
  shotStyle?: 'normal' | 'power' | 'finesse' | 'chip' | 'low';
  shotInfoT?: number;
  goalSpeedKmh?: number;
  goalDistanceM?: number;
}

const rand = Math.random;
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const gauss = () => rand() + rand() + rand() - 1.5; // ~[-1.5,1.5]
const STEP = 1 / 90;

function colorDist(a: string, b: string) {
  const pa = parseInt(a.slice(1), 16);
  const pb = parseInt(b.slice(1), 16);
  const dr = ((pa >> 16) & 255) - ((pb >> 16) & 255);
  const dg = ((pa >> 8) & 255) - ((pb >> 8) & 255);
  const db = (pa & 255) - (pb & 255);
  return Math.sqrt(dr * dr + dg * dg + db * db);
}

export class Match {
  readonly cfg: MatchConfig;
  readonly pitch: PitchSpec;
  readonly ball = new Ball();
  readonly group = new Group();
  teams: TeamRT[] = [];
  players: Footballer[] = [];
  user: Footballer | null = null;
  phase: Phase = 'KICKOFF';
  phaseT = 0;
  time = 0; // simulation time
  clock = 0; // match clock (seconds of play)
  half = 1;
  overtime = false;
  overtimeClock = 0;
  possession = -1;
  possessionSince = 0;
  ownerSince = 0;
  playStart = 0;
  kickoffTeam = 0;
  kickoffLock = 0;
  chasers = new Set<Footballer>();
  camYaw = Math.PI / 2;
  shotFlash = 0;
  shootCharge = 0;
  passCharge = 0;
  // Shot type is chosen while charging. A heavy strike has a short, interruptible plant step.
  powerShotActive = false;
  powerShotCharge = 0;
  timedState: 'green' | 'early' | 'late' | null = null;
  timedStateT = 0;
  shotInfoT = 0;
  lastShotSpeedKmh = 0;
  lastShotType: 'normal' | 'power' | 'finesse' | 'chip' | 'low' | 'header' = 'normal';
  goalSpeedKmh = 0;
  goalDistanceM = 0;
  private shotModifier: 'normal' | 'power' | 'finesse' | 'chip' | 'low' = 'normal';
  private pendingPower: { shooter: Footballer; aim: Vector3; power: number; clean: boolean; delay: number } | null = null;
  private fakeShotQueued = false;
  private suppressPass = false;
  private lastShooter: Footballer | null = null;
  private lastShotAt = -100;

  cancelControls() {
    this.shootCharge = this.passCharge = this.powerShotCharge = 0;
    this.powerShotActive = false;
    this.fakeShotQueued = this.suppressPass = false;
    this.shotModifier = 'normal';
  }
  banner: HudState['banner'] = null;
  bannerT = 0;
  result: MatchResult | null = null;
  scorers: MatchResult['scorers'] = [];
  onFinish: ((r: MatchResult) => void) | null = null;
  onGoalEvent: (() => void) | null = null;
  onFx: ((kind: 'kick' | 'tackle' | 'goal', x: number, z: number, power: number) => void) | null = null;
  celebrateFocus = new Vector3();
  lastScorer: Footballer | null = null;
  // training
  training = { targets: 0, zones: 0, goals: 0, streak: 0, best: 0 };

  private acc = 0;
  private roleT = 0;
  private slots = new Map<Footballer, { u: number; v: number }>();
  private supports: (Footballer | null)[] = [null, null];
  private marks = new Map<Footballer, Footballer | null>();
  private autoSwitchT = 0;
  private pendingSwitch: Footballer | null = null;
  private indicator = new Group();
  private ring: Mesh;
  private cone: Mesh;
  private passMarker: Mesh;
  private passLine: Line;
  private passPreviewT = 0;
  private passPreview: Footballer | null = null;
  private goalLatched = false;
  private trainingResetAt = -1;
  private tTargets: { mesh: Group; pos: Vector3; alive: boolean; respawn: number }[] = [];
  private tZones: { mesh: Group; pos: Vector3; r: number }[] = [];
  private tmp = new Vector3();
  private tmp2 = new Vector3();
  private finished = false;
  /** goal replays run in slow motion; ramps back to 1 for open play */
  timeScale = 1;
  private trail: Points | null = null;
  private trailPos = new Float32Array(0);

  constructor(cfg: MatchConfig, scene: Scene, shadows: boolean, pitch?: PitchSpec) {
    this.cfg = cfg;
    this.pitch = pitch ?? makePitch(cfg.size);
    scene.add(this.group);
    this.group.add(this.ball.mesh, this.ball.shadow);
    this.ball.onEvent = (e, s) => {
      if (e === 'bounce') audio.play('bounce', s);
      else if (e === 'post') audio.play('post', 0.6 + s);
      else if (e === 'net') audio.play('net', s);
      else if (e === 'wall') audio.play('bounce', 0.3 * s);
    };
    this.buildTeams(shadows);
    this.buildIndicator();
    this.ring = this.indicator.children[0] as Mesh;
    this.cone = this.indicator.children[1] as Mesh;
    this.passMarker = this.indicator.children[2] as Mesh;
    this.passLine = this.indicator.children[3] as Line;
    this.group.add(this.indicator);
    this.buildTrail();
    if (cfg.mode === 'training') this.buildTraining();
    this.kickoffTeam = 0;
    this.placeKickoff(0, true);
    this.phase = 'KICKOFF';
    this.phaseT = 0;
    this.showBanner(cfg.mode === 'training' ? 'TRAINING' : 'KICK OFF', cfg.mode === 'training' ? 'Hit the targets & pass into the zones' : `${cfg.home.name} vs ${cfg.away.name}`, 'info', cfg.mode === 'training' ? 2 : 1.25);
  }

  // ------------------------------------------------------------------ setup
  private buildTeams(shadows: boolean) {
    const cfg = this.cfg;
    const size = cfg.size;
    const form = FORMATIONS[size] ?? FORMATIONS[3];
    const awayPrimary = colorDist(cfg.homeKit.primary, cfg.away.primary) < 110 ? cfg.away.secondary : cfg.away.primary;
    const awaySecondary = awayPrimary === cfg.away.primary ? cfg.away.secondary : cfg.away.primary;
    const kits: { primary: string; secondary: string; pattern?: number }[] = [
      cfg.homeKit,
      { primary: awayPrimary, secondary: awaySecondary, pattern: awayPrimary === cfg.away.primary ? teamPattern(cfg.away.id) : 0 },
    ];
    const defs = [cfg.home, cfg.away];
    const gkCols = [gkColor([kits[0].primary, kits[1].primary]), gkColor([kits[0].primary, kits[1].primary])];
    if (gkCols[0] === gkCols[1]) gkCols[1] = '#2bf08a' === gkCols[0] ? '#ff7a1a' : '#2bf08a';

    for (let t = 0 as 0 | 1; t < 2; t = (t + 1) as 0 | 1) {
      const def = defs[t];
      const training = cfg.mode === 'training';
      const rt: TeamRT = {
        def, players: [], outfield: [], gk: null, dir: t === 0 ? 1 : -1,
        tactic: t === 0 ? cfg.tactic : this.autoTactic(def, cfg.home),
        score: 0, shots: 0, shotsOn: 0, possTime: 0, kit: kits[t],
      };
      this.teams.push(rt);
      if (training && t === 1) continue;
      const roster = getRoster(def);
      const lineup: PlayerDef[] = [];
      const gkDef = roster.find((p) => p.pos === 'GK')!;
      const slots = training ? form.slice(0, 1) : form;
      const used = new Set<string>([gkDef.id]);
      for (const s of slots) {
        const cand = roster.find((p) => p.pos === s.pos && !used.has(p.id)) ?? roster.find((p) => !used.has(p.id) && p.pos !== 'GK')!;
        used.add(cand.id);
        lineup.push(cand);
      }
      // custom player replaces the first outfield slot of the user's team
      if (t === 0) {
        const c = cfg.custom;
        const bonus = Math.min(12, cfg.level * 0.9);
        const base = def.midfield - 4 + bonus;
        const s = (v: number) => clamp(Math.round(base + v), 40, 99);
        const ci = slots.length - 1; // the custom player leads the line (most advanced slot)
        const slotPos = slots[ci].pos;
        lineup[ci] = {
          id: 'custom', name: c.name || 'ROOKIE', number: c.number, pos: slotPos, archetype: 'Box-to-Box', hair: c.hair, skin: c.skin,
          stats: { speed: s(4), acceleration: s(3), shooting: s(1), passing: s(2), dribbling: s(3), defending: s(-2), physical: s(1), stamina: s(8), ballControl: s(3) },
        };
      }
      const makeKit = (pd: PlayerDef, gk: boolean): KitSpec => {
        const isCustom = pd.id === 'custom';
        const k = kits[t];
        const boots = isCustom ? bootColor(cfg.custom.boots) : '#15171c';
        const skinTones = ['#f6d3b3', '#e8b48a', '#c98e62', '#a46a43', '#7a4a2d', '#4d2e1c'];
        return {
          primary: gk ? gkCols[t] : k.primary,
          secondary: gk ? contrastColor(gkCols[t]) : k.secondary,
          shorts: gk ? '#1a1d24' : k.secondary,
          socks: gk ? '#1a1d24' : k.primary,
          boots,
          skin: skinTones[pd.skin % 6],
          hairColor: hairColorFor(pd.number + pd.skin),
          hair: pd.hair,
          number: pd.number,
          pattern: gk ? 0 : k.pattern ?? 0,
          gloves: gk ? '#f4f6fa' : undefined,
          seed: 1 + (pd.number % 6),
        };
      };
      // GK (street cage games are played without keepers)
      if (!cfg.street) {
        const gk = new Footballer(gkDef, t, 0, makeKit(gkDef, true), shadows);
        gk.lookAt = this.ball.pos;
        rt.gk = gk;
        rt.players.push(gk);
        this.slots.set(gk, { u: 0.04, v: 0 });
      }
      lineup.forEach((pd, i) => {
        const f = new Footballer(pd, t, i + 1, makeKit(pd, false), shadows);
        rt.players.push(f);
        rt.outfield.push(f);
        this.slots.set(f, { u: slots[i].u, v: slots[i].v });
      });
    }
    for (const t of this.teams) for (const p of t.players) {
      this.players.push(p);
      this.group.add(p.group);
    }
    // user: custom player on team 0
    const first = this.teams[0].outfield.find((p) => p.def.id === 'custom') ?? this.teams[0].outfield[0];
    this.setUser(first);
  }

  private autoTactic(opp: TeamDef, mine: TeamDef): Tactic {
    if (opp.attack > opp.defense + 5) return 'ATTACKING';
    if (opp.defense > opp.attack + 5) return 'COUNTER_ATTACK';
    return opp.rating >= mine.rating + 3 ? 'HIGH_PRESS' : 'BALANCED';
  }

  private buildIndicator() {
    // Selected player ring, visible from either camera preset.
    const ring = new Mesh(new RingGeometry(0.62, 0.82, 32).rotateX(-Math.PI / 2), new MeshBasicMaterial({ color: '#d5dd75', transparent: true, opacity: 0.85, depthWrite: false }));
    ring.position.y = 0.04;

    const cone = new Mesh(new ConeGeometry(0.22, 0.38, 3).rotateX(Math.PI), new MeshBasicMaterial({ color: '#d5dd75', depthTest: false }));
    cone.renderOrder = 20;

    const halo = new Mesh(new ConeGeometry(0.32, 0.52, 3).rotateX(Math.PI), new MeshBasicMaterial({ color: '#d5dd75', transparent: true, opacity: 0, depthTest: false }));
    halo.renderOrder = 21;
    cone.add(halo);

    const pm = new Mesh(new ConeGeometry(0.14, 0.26, 3).rotateX(Math.PI), new MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.85, depthTest: false }));
    pm.visible = false;
    const path = new BufferGeometry();
    path.setAttribute('position', new BufferAttribute(new Float32Array(6), 3));
    const line = new Line(path, new LineBasicMaterial({ color: '#f2f2e6', transparent: true, opacity: 0.52, depthTest: false }));
    line.visible = false;
    this.indicator.add(ring, cone, pm, line);
  }

  private buildTraining() {
    const p = this.pitch;
    const mkTarget = (x: number, y: number, z: number) => {
      const g = new Group();
      const a = new Mesh(new CircleGeometry(0.46, 20), new MeshBasicMaterial({ color: '#ffffff' }));
      const b = new Mesh(new RingGeometry(0.16, 0.34, 20), new MeshBasicMaterial({ color: '#ff3b3b' }));
      b.position.z = 0.01;
      const c = new Mesh(new CircleGeometry(0.1, 12), new MeshBasicMaterial({ color: '#ffd400' }));
      c.position.z = 0.02;
      g.add(a, b, c);
      g.rotation.y = -Math.PI / 2;
      g.position.set(x, y, z);
      this.group.add(g);
      return { mesh: g, pos: new Vector3(x, y, z), alive: true, respawn: 0 };
    };
    const bx = p.L / 2 + p.goalD - 0.2;
    const zz = p.goalW / 2 - 0.75;
    this.tTargets = [mkTarget(bx, 0.7, -zz), mkTarget(bx, 0.7, zz), mkTarget(bx, p.goalH - 0.6, -zz), mkTarget(bx, p.goalH - 0.6, zz)];
    for (let i = 0; i < 2; i++) {
      const g = new Group();
      const ring = new Mesh(new RingGeometry(1.7, 2.0, 32).rotateX(-Math.PI / 2), new MeshBasicMaterial({ color: '#d5dd75', transparent: true, opacity: 0.95, depthWrite: false }));
      const disc = new Mesh(new CircleGeometry(1.7, 32).rotateX(-Math.PI / 2), new MeshBasicMaterial({ color: '#d5dd75', transparent: true, opacity: 0.16, depthWrite: false }));
      ring.position.y = 0.04;
      disc.position.y = 0.035;
      g.add(ring, disc);
      this.group.add(g);
      const z = { mesh: g, pos: new Vector3(), r: 2.0 };
      this.tZones.push(z);
      this.moveZone(z);
    }
  }

  private moveZone(z: { mesh: Group; pos: Vector3 }) {
    const p = this.pitch;
    for (let tries = 0; tries < 12; tries++) {
      const x = (rand() * 0.8 - 0.4) * p.L;
      const zz = (rand() * 2 - 1) * (p.W / 2 - 4);
      const farFromUser = !this.user || Math.hypot(x - this.user.pos.x, zz - this.user.pos.z) > 12;
      const farFromOther = this.tZones.every((o) => o.pos === z.pos || Math.hypot(o.pos.x - x, o.pos.z - zz) > 10);
      if ((farFromUser && farFromOther) || tries === 11) {
        z.pos.set(x, 0, zz);
        z.mesh.position.set(x, 0, zz);
        return;
      }
    }
  }

  dispose() {
    this.onFinish = null;
    this.onGoalEvent = null;
    this.onFx = null;
    this.players.forEach((p) => p.dispose());
    this.group.traverse((o) => {
      const m = o as Mesh;
      if (m.userData?.shared) return; // blob shadows share module-level resources
      if (m.isMesh || (o as Points).isPoints || (o as Line).isLine) {
        m.geometry?.dispose();
        const mat = m.material;
        if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
        else mat?.dispose();
      }
    });
    this.group.removeFromParent();
  }

  // ------------------------------------------------------------------ helpers used by AI
  diffFor(team: number): DifficultyDef {
    const d = this.cfg.difficulty;
    if (team === 1) return DIFFICULTY[d];
    // user's AI teammates play at least at NORMAL
    return DIFFICULTY[d === 'EASY' ? 'NORMAL' : d === 'NORMAL' ? 'NORMAL' : 'HARD'];
  }
  slotOf(p: Footballer) {
    return this.slots.get(p) ?? { u: 0.4, v: 0 };
  }
  supportOf(team: number) {
    return this.supports[team];
  }
  goalPos(team: number): Vector3 {
    return this.tmp2.set(this.teams[team].dir * this.pitch.L / 2, 0, 0);
  }
  nearestOpponentTo(team: number, x: number, z: number, outfieldOnly = false): { p: Footballer | null; d: number } {
    let best: Footballer | null = null;
    let bd = 99;
    const list = outfieldOnly ? this.teams[1 - team].outfield : this.teams[1 - team].players;
    for (const o of list) {
      const d = Math.hypot(o.pos.x - x, o.pos.z - z);
      if (d < bd) {
        bd = d;
        best = o;
      }
    }
    return { p: best, d: bd };
  }
  markTarget(p: Footballer): Footballer | null {
    return this.marks.get(p) ?? null;
  }

  private ballDistTo(p: Footballer) {
    return Math.hypot(this.ball.pos.x - p.pos.x, this.ball.pos.z - p.pos.z);
  }

  private updateRoles() {
    this.chasers.clear();
    for (let ti = 0; ti < 2; ti++) {
      const t = this.teams[ti];
      const owner = this.ball.owner;
      const tac = TACTICS[t.tactic];
      const base = t.outfield
        .filter((p) => !owner || owner !== p)
        .map((p) => ({ p, t: this.ballDistTo(p) / Math.max(3, p.topRun) + (p.busy ? 1.5 : 0) }))
        .sort((a, b) => a.t - b.t);
      const loose = !owner;
      const oppHas = !!owner && owner.team !== ti;
      const k = loose ? 1 : oppHas ? tac.pressers : 0;
      let taken = 0;
      for (const e of base) {
        if (taken >= k) break;
        taken++;
        if (e.p.isUser) continue; // human closest = human presses; AI teammates don't double up
        this.chasers.add(e.p);
      }
      // support / marking assignments
      if (owner && owner.team === ti) {
        let bestS: Footballer | null = null;
        let bd = 99;
        for (const p of t.outfield) {
          if (p === owner || p.def.pos === 'DEF' && t.outfield.length > 2) continue;
          const d = Math.hypot(p.pos.x - owner.pos.x, p.pos.z - owner.pos.z);
          if (d < bd) {
            bd = d;
            bestS = p;
          }
        }
        this.supports[ti] = bestS;
      } else this.supports[ti] = null;
      // marking: each non-chaser defender picks nearest unmarked opponent
      const taken2 = new Set<Footballer>();
      for (const p of t.outfield) {
        let best: Footballer | null = null;
        let bd = 99;
        for (const o of this.teams[1 - ti].outfield) {
          if (taken2.has(o) || o === this.ball.owner) continue;
          const d = Math.hypot(o.pos.x - p.pos.x, o.pos.z - p.pos.z) + (o.def.pos === 'FWD' ? -2 : 0);
          if (d < bd) {
            bd = d;
            best = o;
          }
        }
        if (best) taken2.add(best);
        this.marks.set(p, best);
      }
    }
    if (this.sp) this.chasers.clear();
  }

  // ------------------------------------------------------------------ ownership / kicks
  setUser(p: Footballer | null) {
    if (this.user) this.user.isUser = false;
    this.user = p;
    if (p) p.isUser = true;
    this.pendingSwitch = null;
  }

  private setOwner(p: Footballer | null) {
    const b = this.ball;
    if (b.owner === p) return;
    if (b.owner) b.owner.hasBall = false;
    b.owner = p;
    if (p) {
      p.hasBall = true;
      b.lastTouch = p;
      this.ownerSince = this.time;
      if (this.possession !== p.team) {
        this.possession = p.team;
        this.possessionSince = this.time;
      }
      p.receive = null;
    }
  }

  kick(p: Footballer, dir: Vector3, speed: number, lift: number, kind: 'shot' | 'pass', curl = 0) {
    const b = this.ball;
    if (this.sp?.taker === p) this.clearSetPiece();
    b.vel.set(dir.x * speed + p.vel.x * 0.12, lift, dir.z * speed + p.vel.z * 0.12);
    b.spin.set(-dir.z * speed * 0.2, curl, dir.x * speed * 0.2);
    if (b.pos.y < b.r + 0.02) b.pos.y = b.r + 0.03;
    // nudge away from the player's feet so we don't instantly re-collide
    b.pos.x += dir.x * 0.15;
    b.pos.z += dir.z * 0.15;
    this.setOwnerNull();
    b.lastTouch = p;
    b.lastKickTeam = p.team;
    b.lastKickTime = this.time;
    b.shotId++;
    p.kickCooldown = 0.34;
    p.hasBall = false;
    p.dribbling = false;
    p.setAction('KICK', 0.42, clamp(speed / 28, 0.2, 1));
    p.yaw += angDiff(p.yaw, Math.atan2(dir.x, dir.z)) * 0.8;
    this.possession = p.team;
    audio.play(kind === 'shot' ? 'kick' : 'pass', clamp(speed / 22, 0.3, 1.4));
    if (speed > 12) this.onFx?.('kick', p.pos.x, p.pos.z, clamp(speed / 28, 0.3, 1));
  }

  private setOwnerNull() {
    const b = this.ball;
    if (b.owner) b.owner.hasBall = false;
    if (b.owner && b.owner.holding) b.owner.holding = false;
    b.owner = null;
  }

  canKick(p: Footballer) {
    const b = this.ball;
    if (p.kickCooldown > 0 || p.busy) return false;
    if (b.owner && b.owner !== p) return false;
    return this.ballDistTo(p) < 1.45 && b.pos.y < 1.7;
  }

  private goalAimPoint(p: Footballer, out: Vector3): Vector3 {
    const t = this.teams[p.team];
    const gx = t.dir * this.pitch.L / 2;
    const opp = this.teams[1 - p.team].gk;
    const half = this.pitch.goalW / 2 - 0.75;
    let z = (rand() < 0.5 ? -1 : 1) * half * (0.55 + rand() * 0.45);
    if (opp) z = (opp.pos.z > 0 ? -1 : 1) * half * (0.5 + rand() * 0.5);
    return out.set(gx, 0, z);
  }

  /** One shared strike model for AI and player shots. Aim is never made perfect. */
  shoot(
    p: Footballer,
    aim: Vector3,
    power: number,
    lob: boolean,
    low: boolean,
    assist: boolean,
    errMul: number,
    opts?: { powerShot?: boolean; finesse?: boolean; clean?: boolean }
  ) {
    const st = p.def.stats;
    const pw = clamp(power, 0.1, 1);
    const isPower = !!opts?.powerShot;
    const isFinesse = !!opts?.finesse;
    const shotType = isPower ? 'power' : isFinesse ? 'finesse' : lob ? 'chip' : low ? 'low' : 'normal';
    let speed = shotType === 'power' ? 23 + 12 * pw : shotType === 'chip' ? 10 + 11 * pw : shotType === 'finesse' ? 13 + 13 * pw : 12 + 16 * pw;
    speed *= 0.87 + 0.13 * st.shooting / 100;
    const goalX = this.teams[p.team].dir * this.pitch.L / 2;
    const distance = Math.hypot(goalX - p.pos.x, p.pos.z);
    // Scale the lift to the shot's flight time. A powerful shot stays below the bar;
    // a chip has a deliberately higher, slower arc.
    const flight = clamp(distance / Math.max(8, speed), 0.25, 1.18);
    let lift = low ? 0.3 : shotType === 'chip'
      ? 6.4 + pw * 4.2
      : clamp(((shotType === 'finesse' ? 1.32 : shotType === 'power' ? 0.9 : 1.05) - this.ball.r + 0.5 * 17 * flight * flight) / flight, 2.4, 11);

    let dx = aim.x;
    let dz = aim.z;
    const l0 = Math.hypot(dx, dz) || 1;
    dx /= l0;
    dz /= l0;
    const t = this.teams[p.team];

    if (assist && !isPower) {
      const gp = this.goalAimPoint(p, this.tmp);
      const gdx = gp.x - p.pos.x;
      const gdz = gp.z - p.pos.z;
      const gl = Math.hypot(gdx, gdz);
      const diff = Math.abs(angDiff(Math.atan2(dx, dz), Math.atan2(gdx, gdz)));
      if (diff < 0.8 && gl < this.pitch.L * 0.62 && (gdx * t.dir) > 0) {
        const k = 0.28 + 0.32 * (1 - diff / 0.8);
        dx = dx * (1 - k) + (gdx / gl) * k;
        dz = dz * (1 - k) + (gdz / gl) * k;
      }
    }

    const composure = opts?.clean ? 0.66 : pw > 0.93 ? 1.4 : 1;
    const movePenalty = 1 + p.speed * 0.022 + Math.min(0.35, Math.abs(p.turnRate) * 0.02);
    const err = (0.025 + (1 - st.shooting / 100) * 0.16) * composure * (isPower ? 1.55 : isFinesse ? 0.8 : 1) * movePenalty * (1 + (1 - p.stamFactor)) * errMul;
    const ang = Math.atan2(dx, dz) + gauss() * err * 1.3;
    this.tmp.set(Math.sin(ang), 0, Math.cos(ang));
    const curl = isFinesse ? (p.pos.z >= 0 ? -1 : 1) * t.dir * (5 + pw * 3.5) : clamp(-p.turnRate * 0.42 + gauss() * 2.5, -5, 5);
    if (opts?.clean && !low && !lob) lift *= 0.95;
    t.shots++;
    p.gShots++;
    this.lastShotSpeedKmh = Math.round(speed * 3.6);
    this.lastShotType = shotType;
    this.lastShooter = p;
    this.lastShotAt = this.time;
    this.goalDistanceM = Math.round(distance);
    this.shotInfoT = p.isUser ? 1.25 : 0;
    this.kick(p, this.tmp, speed, lift, 'shot', curl);
    if (isPower) {
      p.setAction('POWER_SHOT', 0.62, 1);
      p.actionT = 0.27;
      audio.play('powerKick', 0.8);
    } else if (isFinesse) p.setAction('FINESSE', 0.42, pw);
    if (p.isUser) this.shotFlash = isPower ? 1.3 : 0.8;

    // on target?
    const gx = t.dir * this.pitch.L / 2;
    const tHit = (gx - p.pos.x) / (this.tmp.x * speed || 1e-3);
    const zHit = p.pos.z + this.tmp.z * speed * tHit;
    if (tHit > 0 && Math.abs(zHit) < this.pitch.goalW / 2 + 0.2) t.shotsOn++;
  }

  aiShoot(p: Footballer) {
    const t = this.teams[p.team];
    const gp = this.goalAimPoint(p, this.tmp2);
    const dir = new Vector3(gp.x - p.pos.x, 0, gp.z - p.pos.z).normalize();
    const dist = Math.hypot(gp.x - p.pos.x, gp.z - p.pos.z);
    const pw = clamp(0.45 + dist / (this.pitch.L * 0.7) + rand() * 0.15, 0.4, 1);
    const D = this.diffFor(p.team);
    const lob = dist > 6 && dist < 16 && rand() < 0.1;
    this.shoot(p, dir, pw, lob, !lob && rand() < 0.4, false, D.shotError);
    void t;
  }

  private passDir(p: Footballer, target: Vector3, kind: 'normal' | 'through' | 'lob', charge: number, errMul: number, mate: Footballer | null) {
    const st = p.def.stats;
    const dx = target.x - p.pos.x;
    const dz = target.z - p.pos.z;
    const dist = Math.hypot(dx, dz) || 1;
    // Short passes arrive at a controllable pace; driven balls still challenge the receiver.
    let speed = clamp(6.5 + 0.48 * dist + 0.006 * dist * dist, 8, 24) * (0.88 + 0.22 * charge);
    let lift = 0.15;
    if (kind === 'lob') {
      const T = 0.7 + dist * 0.04;
      lift = 8.5 * T;
      speed = (dist / T) * 1.03;
    } else if (kind === 'through') speed = clamp(speed * 1.17, 10, 28);
    const err = (1 - st.passing / 100) * 0.12 * (0.55 + dist / 38) * (1 + (1 - p.stamFactor)) * (1 + p.speed * 0.02) * errMul;
    const ang = Math.atan2(dx, dz) + gauss() * err * 1.4;
    const dir = new Vector3(Math.sin(ang), 0, Math.cos(ang));
    // pass power error
    speed *= 1 + gauss() * err * 0.6;
    p.gPasses++;
    this.kick(p, dir, speed, lift, 'pass', gauss() * err * 5);
    if (mate) {
      const flight = dist / Math.max(6, speed * 0.62) + 0.15;
      mate.receive = { until: this.time + flight + 1.6, target: target.clone() };
      mate.decisionCd = 0;
      mate.thinkT = 0;
    }
    return mate;
  }

  aiPass(p: Footballer, mate: Footballer, through: boolean) {
    const D = this.diffFor(p.team);
    const t = this.teams[p.team];
    const target = new Vector3();
    if (through) {
      target.set(mate.pos.x + mate.vel.x * 0.8 + t.dir * (5 + rand() * 2), 0, mate.pos.z + mate.vel.z * 0.8);
    } else {
      const dist = Math.hypot(mate.pos.x - p.pos.x, mate.pos.z - p.pos.z);
      const lead = Math.min(0.9, dist / 25);
      target.set(mate.pos.x + mate.vel.x * lead, 0, mate.pos.z + mate.vel.z * lead);
    }
    this.clampToPitch(target);
    const dist = Math.hypot(target.x - p.pos.x, target.z - p.pos.z);
    const lob = !through && dist > 14 && laneClearance(this, p.team, p.pos.x, p.pos.z, target.x, target.z, true) < 1.4 && rand() < 0.5;
    this.passDir(p, target, lob ? 'lob' : through ? 'through' : 'normal', 0, D.passError, mate);
  }

  private clampToPitch(v: Vector3) {
    v.x = clamp(v.x, -this.pitch.L / 2 + 1, this.pitch.L / 2 - 1);
    v.z = clamp(v.z, -this.pitch.W / 2 + 1, this.pitch.W / 2 - 1);
  }

  private chooseMate(p: Footballer, aim: Vector3, preview = false): Footballer | null {
    const t = this.teams[p.team];
    const aimAng = Math.atan2(aim.x, aim.z);
    let best: Footballer | null = null;
    let bs = -9;
    for (const m of t.outfield) {
      if (m === p) continue;
      const vx = m.pos.x - p.pos.x;
      const vz = m.pos.z - p.pos.z;
      const dist = Math.hypot(vx, vz);
      if (dist < 1.8) continue;
      const ang = Math.abs(angDiff(aimAng, Math.atan2(vx, vz)));
      if (ang > 1.15) continue;
      const risk = preview ? 9 : laneClearance(this, p.team, p.pos.x, p.pos.z, m.pos.x, m.pos.z, true);
      const sc = (1 - ang / 1.15) * 1.6 + (1 - Math.min(dist, 36) / 36) * 0.5 - (risk < 1.2 ? 0.8 : risk < 2.4 ? 0.25 : 0);
      if (sc > bs) {
        bs = sc;
        best = m;
      }
    }
    // With no directional input, a short pass should find a sensible teammate
    // even if the player's body still faces the wrong way after a turn/restart.
    if (!best && p.moveDir.lengthSq() < 0.04) return bestPass(this, p)?.mate ?? null;
    return best;
  }

  userPass(p: Footballer, kind: 'normal' | 'through' | 'lob', charge: number) {
    const aim = p.moveDir.lengthSq() > 0.04 ? this.tmp2.copy(p.moveDir).normalize() : this.tmp2.copy(p.fwd);
    const aimC = aim.clone();
    const mate = this.chooseMate(p, aimC);
    const t = this.teams[p.team];
    const target = new Vector3();
    if (mate) {
      if (kind === 'through') {
        target.set(mate.pos.x + mate.vel.x * 0.9 + t.dir * (5.5 + charge * 3), 0, mate.pos.z + mate.vel.z * 0.9);
      } else {
        const dist = Math.hypot(mate.pos.x - p.pos.x, mate.pos.z - p.pos.z);
        const lead = Math.min(0.9, dist / 25);
        target.set(mate.pos.x + mate.vel.x * lead, 0, mate.pos.z + mate.vel.z * lead);
      }
    } else {
      const d = kind === 'through' ? 20 : 14 + charge * 10;
      target.set(p.pos.x + aimC.x * d, 0, p.pos.z + aimC.z * d);
    }
    this.clampToPitch(target);
    this.passDir(p, target, kind, charge, 1, mate);
    if (mate && this.cfg.settings.autoSwitch) this.pendingSwitch = mate;
  }

  // ------------------------------------------------------------------ tackle / keeper
  startTackle(p: Footballer, slide: boolean) {
    if (p.busy || p.tackleCd > 0) return false;
    p.setAction(slide ? 'SLIDE' : 'TACKLE', slide ? 1.05 : 0.6);
    p.tackleCd = slide ? 1.6 : 0.8;
    if (slide) p.stamina = Math.max(0, p.stamina - 8);
    audio.play('pass', 0.4);
    return true;
  }

  keeperDive(gk: Footballer, dir: Vector3, height: number) {
    if (gk.busy) return;
    gk.diveDir.copy(dir);
    gk.diveHeight = height;
    gk.setAction('SAVE', 1.0);
    gk.tackleCd = 0.8;
  }

  private resolveTackles() {
    const b = this.ball;
    for (const p of this.players) {
      if ((p.action !== 'TACKLE' && p.action !== 'SLIDE') || p.actionResolved) continue;
      const slide = p.action === 'SLIDE';
      const t = p.actionT;
      if (t < (slide ? 0.04 : 0.05) || t > (slide ? 0.7 : 0.32)) continue;
      const f = p.fwd;
      const reach = slide ? 1.25 : 0.9;
      const fx = p.pos.x + f.x * (slide ? 0.95 : 0.7);
      const fz = p.pos.z + f.z * (slide ? 0.95 : 0.7);
      const owner = b.owner;
      const rad = slide ? 1.2 : 0.85;
      if (owner && owner.team !== p.team && !owner.holding) {
        const dBall = Math.hypot(b.pos.x - fx, b.pos.z - fz);
        const dOwner = Math.hypot(owner.pos.x - fx, owner.pos.z - fz);
        if (dBall < reach + 0.2 || dOwner < rad) {
          p.actionResolved = true;
          const D = this.diffFor(p.team);
          let chance = (slide ? 0.68 : 0.5) + (p.def.stats.defending - owner.def.stats.dribbling) * 0.006 + (p.stamFactor - 1) * 0.3;
          if (owner.speed > 6.5) chance -= 0.06;
          if (!p.isUser) chance *= 0.6 + 0.55 * D.tackle;
          chance = clamp(chance, 0.12, 0.92);
          if (owner.action === 'SKILL' || owner.action === 'ROULETTE') chance *= 0.48;
          if (rand() < chance) {
            // A well-timed standing tackle wins controlled possession; a slide is a clearance.
            if (!slide && b.pos.y < 1.05) {
              this.setOwner(p);
              b.pos.set(p.pos.x + f.x * 0.7, b.r, p.pos.z + f.z * 0.7);
              b.vel.set(p.vel.x * 0.55, 0, p.vel.z * 0.55);
            } else {
              this.setOwnerNull();
              const sp = slide ? 8 : 5.2;
              b.vel.set(f.x * sp + gauss() * 1.2, 0.6, f.z * sp + gauss() * 1.2);
              b.lastTouch = p;
            }
            owner.kickCooldown = 0.5;
            owner.stunned = 0.45;
            if (slide && rand() < 0.6) owner.setAction('FALL', 0.95);
            p.kickCooldown = 0;
            p.gTackles++;
            audio.play('tackle');
            this.onFx?.('tackle', owner.pos.x, owner.pos.z, slide ? 1 : 0.5);
            if (p.isUser) this.showBanner(slide ? 'CLEARED' : 'BALL WON', '', 'info', 0.6);
          } else {
            audio.play('pass', 0.5);
            if (p.isUser) this.showBanner('MISSED', '', 'info', 0.6);
          }
          continue;
        }
      } else if (!owner || owner.team === p.team) {
        if (!owner && Math.hypot(b.pos.x - fx, b.pos.z - fz) < reach && b.pos.y < 1) {
          p.actionResolved = true;
          b.vel.set(f.x * (slide ? 9 : 6), 0.5, f.z * (slide ? 9 : 6));
          b.lastTouch = p;
          this.possession = p.team;
          audio.play('tackle', 0.6);
        }
      }
    }
  }

  /** Auto-contact for playable crosses: a well-placed runner can redirect an aerial ball. */
  private resolveAerialContacts() {
    const b = this.ball;
    if (b.owner || b.pos.y < 1.35 || b.pos.y > 2.35 || b.speed < 2) return;
    for (const p of this.players) {
      if (p.isGK || p.busy || p.kickCooldown > 0 || p.holding) continue;
      if (Math.abs(b.pos.y - 1.85) > 0.5 || this.ballDistTo(p) > 0.7) continue;
      const goalX = this.teams[p.team].dir * this.pitch.L / 2;
      const goalDist = Math.hypot(goalX - p.pos.x, p.pos.z);
      const mate = goalDist > 23 ? bestPass(this, p, false)?.mate : null;
      const dir = p.isUser && p.moveDir.lengthSq() > 0.1
        ? this.tmp.copy(p.moveDir).normalize()
        : mate ? this.tmp.set(mate.pos.x - p.pos.x, 0, mate.pos.z - p.pos.z).normalize()
          : this.tmp.set(goalX - p.pos.x, 0, -p.pos.z * 1.15).normalize();
      const accuracy = (1 - p.def.stats.ballControl / 100) * 0.18;
      dir.z += gauss() * accuracy;
      dir.normalize();
      const speed = 8 + p.def.stats.physical * 0.09;
      b.vel.set(dir.x * speed, 2.5 + p.def.stats.physical * 0.012, dir.z * speed);
      b.spin.set(-dir.z * 2, 0, dir.x * 2);
      b.lastTouch = p;
      b.lastKickTeam = p.team;
      b.lastKickTime = this.time;
      b.shotId++;
      p.kickCooldown = 0.55;
      p.setAction('HEADER', 0.46);
      p.yaw += angDiff(p.yaw, Math.atan2(dir.x, dir.z)) * 0.65;
      this.possession = p.team;
      if (!mate && goalDist < 23) {
        this.teams[p.team].shots++;
        p.gShots++;
        this.lastShooter = p;
        this.lastShotAt = this.time;
        this.lastShotType = 'header';
        this.lastShotSpeedKmh = Math.round(speed * 3.6);
        this.goalDistanceM = Math.round(goalDist);
        this.shotInfoT = p.isUser ? 1 : 0;
      }
      audio.play('bounce', 0.85);
      break;
    }
  }

  private resolveKeepers() {
    const b = this.ball;
    for (const t of this.teams) {
      const gk = t.gk;
      if (!gk) continue;
      if (gk.holding) continue;
      const hand = this.tmp.set(gk.pos.x, 1.05, gk.pos.z);
      const dive = gk.action === 'SAVE';
      let reach = 1.0 + gk.def.stats.defending * 0.003 + 0.0;
      if (dive) {
        // hands stretch in the dive direction
        hand.x += gk.diveDir.x * 0.9;
        hand.z += gk.diveDir.z * 0.9;
        hand.y = 0.6 + gk.diveHeight * 1.5;
        reach += 0.45;
      }
      const dx = b.pos.x - hand.x;
      const dy = b.pos.y - hand.y;
      const dz = b.pos.z - hand.z;
      const d = Math.hypot(dx, dy * 0.8, dz);
      if (d > reach) continue;
      if (b.owner) continue;
      if (b.lastKickTeam === gk.team && b.speed > 6) continue; // own team's pass
      if (gk.saveShot === b.shotId) continue; // already attempted for this shot
      const fast = b.speed;
      if (fast < 7.5 && b.pos.y < 2.2) {
        // loose slow ball: just pick up
        if (gk.kickCooldown <= 0 && this.inOwnBox(gk, b.pos)) this.keeperCatch(gk);
        continue;
      }
      // shot save attempt – once per shot
      gk.saveShot = b.shotId;
      const D = this.diffFor(gk.team);
      const quality = (t.def.goalkeeper / 100) * D.gkSave;
      const speedFactor = clamp(1 - (fast - 8) / 34, 0.1, 1);
      let pSave = (0.3 + 0.5 * quality) * (0.45 + 0.55 * speedFactor) + 0.22 * (1 - d / reach);
      if (dive) pSave += 0.1;
      else if (d < 0.5) pSave += 0.18; // shots directly at the keeper should be caught
      else if (b.pos.y > 1.6) pSave -= 0.16;
      pSave = clamp(pSave, 0.08, 0.94);
      if (!gk.busy) {
        this.tmp2.set(0, 0, Math.sign(dz) || 1);
        this.keeperDive(gk, this.tmp2, clamp(b.pos.y / 2.4, 0, 1));
      }
      if (rand() < pSave) {
        gk.gSaves++;
        const catchable = fast < 17 && b.pos.y < 2.0 && rand() < 0.5 + quality * 0.3;
        if (catchable) {
          this.keeperCatch(gk);
        } else {
          // parry – push the ball away from goal, mostly wide
          const away = t.dir;
          const side = Math.sign(dz) || (rand() < 0.5 ? 1 : -1);
          const sp = clamp(fast * 0.38 + 3, 4, 12);
          b.vel.set(away * sp * (0.5 + rand() * 0.6), 1.5 + rand() * 3, side * sp * (0.4 + rand() * 0.9));
          b.lastTouch = gk;
          b.lastKickTeam = gk.team;
          b.shotId++;
          gk.saveShot = b.shotId;
          audio.play('save');
          if (this.teams[1 - gk.team].players.some((p) => p.isUser)) this.showBanner('SAVED!', '', 'info', 0.9);
        }
        this.possession = gk.team;
      } else {
        // fingertip: slows the shot a bit but it might still go in
        b.vel.multiplyScalar(0.8);
        b.vel.y += 0.6;
        audio.play('save', 0.5);
      }
    }
  }

  private inOwnBox(gk: Footballer, pos: Vector3) {
    const t = this.teams[gk.team];
    const lineX = -t.dir * this.pitch.L / 2;
    return Math.abs(pos.x - lineX) < this.pitch.boxD && Math.abs(pos.z) < this.pitch.boxW / 2;
  }

  private keeperCatch(gk: Footballer) {
    this.setOwner(gk);
    gk.holding = true;
    gk.holdTimer = 1.2 + rand() * 0.6;
    this.ball.vel.set(0, 0, 0);
    this.ball.spin.set(0, 0, 0);
    audio.play('save', 0.8);
    if (!gk.busy) gk.setAction('SAVE', 0.5);
  }

  private keeperRelease(gk: Footballer) {
    const t = this.teams[gk.team];
    const options = t.outfield.filter((p) => !p.busy);
    let target = options[0] ?? null;
    let bs = -9;
    for (const o of options) {
      const risk = laneClearance(this, gk.team, gk.pos.x, gk.pos.z, o.pos.x, o.pos.z, true);
      const s = Math.min(risk, 5) + Math.min(this.nearestOpponentTo(gk.team, o.pos.x, o.pos.z).d, 8) * 0.5 + rand();
      if (s > bs) {
        bs = s;
        target = o;
      }
    }
    gk.holding = false;
    gk.kickCooldown = 0;
    this.setOwnerNull();
    if (target) {
      this.tmp.set(target.pos.x, 0, target.pos.z);
      const dist = Math.hypot(target.pos.x - gk.pos.x, target.pos.z - gk.pos.z);
      this.passDir(gk, this.tmp.clone(), dist > 22 ? 'lob' : 'normal', 0, 1.2, target);
      target.receive = { until: this.time + 3, target: target.pos.clone() };
    } else this.kick(gk, new Vector3(t.dir, 0, 0), 14, 3, 'pass');
  }

  // ------------------------------------------------------------------ skill moves, out of play & restarts
  /** throw-in / corner currently being taken (null during open play) */
  sp: SetPiece | null = null;

  startSkill(p: Footballer) {
    if (p.busy || p.skillCd > 0 || p.holding) return;
    const isSprinting = p.sprint || p.speed > 5.2;
    const action = isSprinting ? 'ROULETTE' : 'SKILL';
    p.setAction(action, action === 'ROULETTE' ? 0.65 : 0.52);
    p.skillCd = 1.25;
    p.stamina = Math.max(0, p.stamina - 6);
    audio.play('whoosh', 0.85);
    const opponent = this.nearestOpponentTo(p.team, p.pos.x, p.pos.z, true);
    if (opponent.p && opponent.d < 2.25) {
      const fwd = p.fwd;
      const inFront = ((opponent.p.pos.x - p.pos.x) * fwd.x + (opponent.p.pos.z - p.pos.z) * fwd.z) > -0.3;
      const chance = clamp(0.48 + (p.def.stats.dribbling - opponent.p.def.stats.defending) * 0.008, 0.2, 0.78);
      if (inFront && rand() < chance) opponent.p.stunned = Math.max(opponent.p.stunned, 0.2);
    }
  }

  /** AI corner delivery: a lofted ball into the box */
  aiCross(p: Footballer, mate: Footballer) {
    const target = new Vector3(mate.pos.x + mate.vel.x * 0.6, 0, mate.pos.z + mate.vel.z * 0.6);
    this.clampToPitch(target);
    this.passDir(p, target, 'lob', 0, this.diffFor(p.team).passError * 1.2, mate);
  }

  /** per-step hook: first-to-N finish, dead-ball handling and out-of-play detection */
  private extraUpdate(dt: number) {
    if (this.sp) this.updateSetPiece(dt);
  }

  private checkOut() {
    const b = this.ball;
    const lt = b.lastTouch;
    if (b.owner || !lt) return;
    const p = this.pitch;
    const hl = p.L / 2;
    const hw = p.W / 2;
    const ax = Math.abs(b.pos.x);
    const az = Math.abs(b.pos.z);
    if (az > hw + 0.1 && ax < hl + 0.5) {
      const sz = Math.sign(b.pos.z) || 1;
      this.startSetPiece('throw', 1 - lt.team, clamp(b.pos.x, -hl + 2, hl - 2), sz * hw);
      return;
    }
    if (ax > hl + 0.25) {
      if (az < p.goalW / 2 + 0.05 && b.pos.y < p.goalH + 0.1) return; // inside the goal – handled by goal detection
      const side = b.pos.x > 0 ? 1 : -1;
      const att = this.teams.findIndex((t) => t.dir === side);
      const def = 1 - att;
      if (lt.team === def) {
        const sz = Math.sign(b.pos.z) || 1;
        this.startSetPiece('corner', att, side * (hl - 0.35), sz * (hw - 0.35));
      } else this.startGoalKick(def);
    }
  }

  private startSetPiece(kind: 'throw' | 'corner', team: number, x: number, z: number) {
    const t = this.teams[team];
    let taker: Footballer | null = null;
    let bd = 1e9;
    for (const q of t.outfield) {
      if (q.busy) continue;
      const d = Math.hypot(q.pos.x - x, q.pos.z - z);
      if (d < bd) {
        bd = d;
        taker = q;
      }
    }
    taker = taker ?? t.outfield[0] ?? null;
    if (!taker) return;
    this.setOwnerNull();
    this.ball.reset(x, z);
    this.ball.lastKickTeam = team;
    this.sp = { kind, team, spot: new Vector3(x, 0, z), taker, state: 'fetch', t: 0 };
    this.possession = team;
    this.possessionSince = this.time;
    if (team === 0) this.setUser(taker);
    this.showBanner(kind === 'throw' ? 'THROW-IN' : 'CORNER KICK', t.def.name, 'info', 1.5);
    audio.play('whistle');
  }

  private startGoalKick(team: number) {
    const t = this.teams[team];
    const gk = t.gk;
    this.setOwnerNull();
    if (!gk) {
      this.ball.reset(0, 0);
      return;
    }
    this.ball.reset(gk.pos.x + t.dir * 0.4, gk.pos.z);
    gk.action = 'IDLE';
    this.keeperCatch(gk);
    gk.holdTimer = 1.3 + rand() * 0.5;
    this.possession = team;
    this.showBanner('GOAL KICK', t.def.name, 'info', 1.2);
  }

  private updateSetPiece(dt: number) {
    const sp = this.sp!;
    const tk = sp.taker;
    const b = this.ball;
    const { L } = this.pitch;
    sp.t += dt;
    // the opposition keeps its distance from the restart
    for (const q of this.teams[1 - sp.team].players) {
      if (q.isGK) continue;
      const dx = q.pos.x - sp.spot.x;
      const dz = q.pos.z - sp.spot.z;
      const d = Math.hypot(dx, dz);
      if (d < 4 && d > 0.01) {
        q.pos.x += (dx / d) * (4 - d) * 0.08;
        q.pos.z += (dz / d) * (4 - d) * 0.08;
      }
    }
    if (sp.state === 'fetch') {
      b.vel.set(0, 0, 0);
      b.pos.set(sp.spot.x, b.r, sp.spot.z);
      const d = Math.hypot(tk.pos.x - sp.spot.x, tk.pos.z - sp.spot.z);
      if (d < 1.1 || sp.t > 8) {
        sp.state = 'ready';
        sp.t = 0;
        if (sp.kind === 'throw') {
          const side = Math.sign(sp.spot.z) || 1;
          tk.pos.set(sp.spot.x, 0, sp.spot.z + side * 0.55);
          tk.yaw = side > 0 ? Math.PI : 0;
          tk.throwPose = true;
        } else {
          const gx = this.teams[sp.team].dir * L / 2;
          tk.pos.set(sp.spot.x - Math.sign(sp.spot.x) * 0.5, 0, sp.spot.z - Math.sign(sp.spot.z) * 0.5);
          tk.yaw = Math.atan2(gx - tk.pos.x, -tk.pos.z);
          tk.throwPose = false;
        }
        tk.vel.set(0, 0, 0);
        this.setOwner(tk);
        tk.holding = true;
        tk.holdTimer = 99;
      }
      return;
    }
    // ready: the taker is rooted until the ball is kicked
    if (b.owner !== tk) {
      this.sp = null;
      tk.throwPose = false;
      return;
    }
    tk.moveDir.set(0, 0, 0);
    if (tk.isUser && sp.t > 7) {
      const bp = bestPass(this, tk, true);
      if (bp) {
        if (sp.kind === 'corner') this.aiCross(tk, bp.mate);
        else this.aiPass(tk, bp.mate, false);
      }
    }
  }

  private clearSetPiece() {
    if (this.sp) {
      this.sp.taker.holding = false;
      this.sp.taker.throwPose = false;
      this.sp = null;
    }
  }

  // ------------------------------------------------------------------ user control
  switchPlayer(auto = false) {
    const t = this.teams[0];
    const u = this.user;
    let best: Footballer | null = null;
    let bs = -1e9;
    const b = this.ball;
    for (const p of t.outfield) {
      if (p === u) continue;
      const d = this.ballDistTo(p);
      // facing the ball?
      const toBall = Math.atan2(b.pos.x - p.pos.x, b.pos.z - p.pos.z);
      const facing = Math.cos(angDiff(p.yaw, toBall));
      // useful defensive position: between ball and own goal
      const ownX = -t.dir * this.pitch.L / 2;
      const between = (p.pos.x - ownX) * t.dir < (b.pos.x - ownX) * t.dir ? 1 : 0;
      const sc = -d + facing * 2 + between * 1.5 + (b.owner === p ? 6 : 0);
      if (sc > bs) {
        bs = sc;
        best = p;
      }
    }
    if (best) {
      if (auto && u && this.ballDistTo(best) > this.ballDistTo(u) - 4) return;
      this.setUser(best);
      this.autoSwitchT = 1.0;
    }
  }

  private handleUser(inp: Input, dt: number) {
    const u = this.user;
    if (!u) return;
    if (this.sp && this.sp.taker !== u) {
      u.moveDir.set(0, 0, 0);
      u.sprint = false;
      return;
    }
    if (this.cfg.settings.camera === 'BROADCAST') {
      // Side-on television view: directions follow the screen, not the attacking half.
      u.moveDir.set(inp.moveX, 0, -inp.moveY);
    } else {
      const fx = Math.sin(this.camYaw);
      const fz = Math.cos(this.camYaw);
      u.moveDir.set(fx * inp.moveY - fz * inp.moveX, 0, fz * inp.moveY + fx * inp.moveX);
    }
    u.sprint = inp.down.sprint;
    this.shootCharge = inp.down.shoot ? clamp(inp.holdTime.shoot / 0.9, 0.02, 1) : 0;
    this.passCharge = inp.down.pass ? clamp(inp.holdTime.pass / 0.7, 0.02, 1) : 0;
    if (this.phase !== 'PLAY') return;
    if (this.sp && this.sp.state !== 'ready') return;
    if (this.pendingPower) {
      u.moveDir.set(0, 0, 0);
      return;
    }
    if (inp.pressed.switch && !this.sp) {
      this.switchPlayer();
      return;
    }
    const canAct = !u.busy && u.stunned <= 0.15;
    const aim = u.moveDir.lengthSq() > 0.04 ? this.tmp2.copy(u.moveDir).normalize().clone() : u.fwd;
    // A fast pointer click may begin and end between frames. Its latched edge
    // must still inherit the selected strike type.
    if (inp.down.shoot || inp.pressed.shoot || inp.released.shoot) {
      if (inp.down.powershot) this.shotModifier = 'power';
      else if (inp.down.finesse) this.shotModifier = 'finesse';
      else if (inp.down.lob) this.shotModifier = 'chip';
      else if (inp.down.low) this.shotModifier = 'low';
      this.powerShotActive = this.shotModifier === 'power';
      this.powerShotCharge = this.powerShotActive ? this.shootCharge : 0;
    }

    if (inp.pressed.pass && inp.down.shoot && canAct && !this.sp && this.canKick(u)) {
      // A cancel is a readable body feint, not a free stun against every defender.
      this.fakeShotQueued = true;
      this.suppressPass = true;
      u.setAction('SKILL', 0.38);
      u.skillCd = 0.85;
      audio.play('whoosh', 0.5);
      const defender = this.nearestOpponentTo(u.team, u.pos.x, u.pos.z, true);
      if (defender.p && defender.d < 2.2) defender.p.stunned = Math.max(defender.p.stunned, 0.16);
      this.showBanner('BODY FEINT', '', 'info', 0.55);
    }

    if (inp.released.shoot) {
      const power = clamp(inp.lastHold.shoot / 0.9, 0.12, 1);
      const modifier = this.shotModifier;
      this.shotModifier = 'normal';
      this.powerShotActive = false;
      this.powerShotCharge = 0;
      if (this.fakeShotQueued) {
        this.fakeShotQueued = false;
        return;
      }
      if (canAct && this.canKick(u)) {
        if (this.sp?.kind === 'throw') this.userPass(u, 'normal', power);
        else {
          const clean = power >= 0.6 && power <= 0.88;
          this.timedState = clean ? 'green' : power < 0.35 ? 'early' : power > 0.93 ? 'late' : null;
          this.timedStateT = this.timedState ? 0.75 : 0;
          if (clean) audio.play('timedGreen', 0.38);
          if (modifier === 'power' && !this.sp) {
            this.pendingPower = { shooter: u, aim: aim.clone(), power, clean, delay: 0.18 };
            u.setAction('POWER_SHOT', 0.64, power);
            u.stamina = Math.max(0, u.stamina - 7);
            audio.play('whoosh', 0.65);
          } else this.shoot(u, aim, power, modifier === 'chip', modifier === 'low', this.cfg.settings.aimAssist, 1,
            { finesse: modifier === 'finesse', clean });
          return;
        }
      } else if (canAct) u.setAction('KICK', 0.3, 0.3);
    }

    if (inp.released.pass) {
      if (this.suppressPass) this.suppressPass = false;
      else if (canAct && this.canKick(u)) {
        const charged = clamp(inp.lastHold.pass / 0.7, 0.16, 1);
        this.userPass(u, inp.down.lob ? 'lob' : inp.down.sprint ? 'through' : 'normal', charged);
        return;
      }
    }
    if (inp.pressed.through && canAct) {
      if (this.canKick(u)) {
        this.userPass(u, inp.down.lob ? 'lob' : 'through', 0);
        return;
      }
    }
    if (inp.pressed.skill && canAct && u.skillCd <= 0 && !u.holding) this.startSkill(u);
    if (inp.pressed.slide && canAct && u.tackleCd <= 0) {
      this.startTackle(u, true);
    } else if (inp.pressed.tackle && canAct && u.tackleCd <= 0) {
      this.startTackle(u, inp.down.sprint && u.stamina > 10);
    }
    // pass target preview (cheap, 10 Hz)
    this.passPreviewT -= dt;
    if (this.passPreviewT <= 0) {
      this.passPreviewT = 0.1;
      this.passPreview = this.ball.owner === u ? this.chooseMate(u, aim, true) : null;
    }
  }

  // ------------------------------------------------------------------ flow
  showBanner(text: string, sub: string, kind: 'goal' | 'info' | 'final', dur: number) {
    this.banner = { text, sub, kind };
    this.bannerT = dur;
  }

  private kickoffSpots(team: number): Map<Footballer, { x: number; z: number }> {
    const t = this.teams[team];
    const { L, W, circleR } = this.pitch;
    const d = t.dir;
    const out = new Map<Footballer, { x: number; z: number }>();
    const uMax = 0.5 - (circleR + 1.6) / L;
    for (const p of t.players) {
      if (p.isGK) {
        out.set(p, { x: -d * L / 2 + d * 1.2, z: 0 });
        continue;
      }
      const s = this.slotOf(p);
      const u = Math.min(s.u, uMax);
      out.set(p, { x: d * (-L / 2 + u * L), z: d * s.v * (W / 2 - 3.5) });
    }
    if (team === this.kickoffTeam && t.outfield.length > 0) {
      // the most advanced outfield player takes the kick-off
      const k = [...t.outfield].sort((a, b) => this.slotOf(b).u - this.slotOf(a).u)[0];
      out.set(k, { x: -d * 0.62, z: 0 });
    }
    return out;
  }

  placeKickoff(kicker: number, instant: boolean) {
    this.clearSetPiece();
    this.pendingPower = null;
    this.powerShotActive = false;
    this.powerShotCharge = this.shootCharge = this.passCharge = 0;
    this.fakeShotQueued = this.suppressPass = false;
    this.shotModifier = 'normal';
    if (this.cfg.street) this.half = 2; // street games are one continuous period
    this.kickoffTeam = kicker;
    this.ball.reset(0, 0);
    this.setOwnerNull();
    this.possession = -1;
    this.chasers.clear();
    for (let ti = 0; ti < 2; ti++) {
      const spots = this.kickoffSpots(ti);
      for (const [p, s] of spots) {
        p.home.set(s.x, 0, s.z);
        if (instant) p.place(s.x, s.z, this.teams[ti].dir > 0 ? Math.PI / 2 : -Math.PI / 2);
      }
    }
    if (this.cfg.mode === 'training' && this.user) {
      this.user.place(-this.pitch.L * 0.15, 0, Math.PI / 2);
    }
    // user controls the kicker if on their team
    if (kicker === 0 && this.cfg.mode === 'match') {
      const k = [...this.teams[0].outfield].sort((a, b) => this.slotOf(b).u - this.slotOf(a).u)[0];
      if (k) this.setUser(k);
    }
  }

  private beginKickoffCountdown() {
    this.phase = 'KICKOFF';
    this.phaseT = 0;
  }

  private startPlay() {
    this.phase = 'PLAY';
    this.phaseT = 0;
    this.playStart = this.time;
    this.kickoffLock = 1.1;
    audio.play('whistle');
  }

  private goalScored(team: number) {
    const t = this.teams[team];
    t.score++;
    const b = this.ball;
    const lt = b.lastTouch;
    const scorer = lt && lt.team === team ? lt : null;
    this.lastScorer = scorer;
    const strikeGoal = !!scorer && scorer === this.lastShooter && this.time - this.lastShotAt < 4;
    this.goalSpeedKmh = strikeGoal ? this.lastShotSpeedKmh : 0;
    if (!strikeGoal) this.goalDistanceM = 0;
    this.pendingPower = null;
    if (scorer) scorer.gGoals++;
    const mins = this.minuteLabel();
    if (scorer) this.scorers.push({ name: scorer.def.name, team: team as 0 | 1, minute: mins });
    else this.scorers.push({ name: lt ? `${lt.def.name} (OG)` : 'Own goal', team: team as 0 | 1, minute: mins });
    audio.play('goal');
    audio.play('whistle');
    this.onFx?.('goal', t.dir * this.pitch.L / 2, 0, 1);
    this.onGoalEvent?.();
    this.shotFlash = 1;
    this.setOwnerNull();
    this.phase = 'GOAL';
    this.phaseT = 0;
    const finishDetail = this.goalSpeedKmh ? `  |  ${this.goalSpeedKmh} KM/H from ${this.goalDistanceM} m` : '';
    this.showBanner('GOAL!', scorer ? `${scorer.def.name}  |  ${t.def.name}${finishDetail}` : t.def.name, 'goal', 2.3);
    this.celebrateFocus.set(scorer ? scorer.pos.x : b.pos.x, 0, scorer ? scorer.pos.z : b.pos.z);
    let i = 0;
    for (const p of t.players) {
      if (p.busy && p.action !== 'CELEBRATE') p.action = 'IDLE';
      p.setAction('CELEBRATE', 2.4 + (i++ % 3) * 0.1);
      p.moveDir.set(0, 0, 0);
    }
    for (const p of this.teams[1 - team].players) p.moveDir.set(0, 0, 0);
  }

  private minuteLabel() {
    const total = this.cfg.duration;
    const c = this.overtime ? total + this.overtimeClock : this.clock;
    const m = Math.min(120, Math.ceil((c / total) * 90));
    return `${Math.max(1, m)}'`;
  }

  private finish(forcedWinner: 0 | 1 | null = null) {
    if (this.finished) return;
    this.finished = true;
    const [a, b] = [this.teams[0], this.teams[1]];
    let winner: 0 | 1 | -1 = a.score > b.score ? 0 : b.score > a.score ? 1 : -1;
    let pens = false;
    if (winner === -1 && forcedWinner !== null) {
      winner = forcedWinner;
      pens = true;
    }
    const tp = a.possTime + b.possTime || 1;
    let mom: Footballer | null = null;
    let momR = -1;
    for (const p of this.players) {
      const r = this.ratingOf(p, winner);
      if (r > momR) {
        momR = r;
        mom = p;
      }
    }
    const featured = this.teams[0].outfield.find((p) => p.def.id === 'custom') ?? this.user;
    const userRating = featured ? this.ratingOf(featured, winner) : 6;
    this.result = {
      homeScore: a.score, awayScore: b.score, winner, pens,
      shots: [a.shots, b.shots], shotsOn: [a.shotsOn, b.shotsOn],
      possession: [Math.round((a.possTime / tp) * 100), 100 - Math.round((a.possTime / tp) * 100)],
      scorers: this.scorers,
      rating: userRating,
      manOfMatch: mom ? `${mom.def.name} · ${momR.toFixed(1)}` : '',
      contrib: featured ? { goals: featured.gGoals, shots: featured.gShots, passes: featured.gPasses, tackles: featured.gTackles } : undefined,
    };
    this.phase = 'FULLTIME';
    this.phaseT = 0;
    audio.play('whistleLong');
    audio.play(winner === 0 ? 'cheer' : winner === 1 ? 'groan' : 'cheer', 0.8);
    this.showBanner('FULL TIME', `${a.score} - ${b.score}${pens ? (winner === 0 ? ' (won on penalties)' : ' (lost on penalties)') : ''}`, 'final', 3.5);
    setTimeout(() => this.onFinish?.(this.result!), 2600);
  }

  continueFromHalftime() {
    if (this.phase !== 'HALFTIME') return;
    this.half = 2;
    // Both sides change ends at the interval, keeping attacking controls intuitive.
    for (const t of this.teams) t.dir = (t.dir * -1) as 1 | -1;
    this.placeKickoff(1, true);
    this.beginKickoffCountdown();
  }

  resetBall() {
    if (!this.user) return;
    const u = this.user;
    this.setOwnerNull();
    const f = u.fwd;
    this.ball.reset(
      clamp(u.pos.x + f.x * 1.2, -this.pitch.L / 2 + 1.5, this.pitch.L / 2 - 1.5),
      clamp(u.pos.z + f.z * 1.2, -this.pitch.W / 2 + 1.5, this.pitch.W / 2 - 1.5),
    );
    this.goalLatched = false;
    this.trainingResetAt = -1;
  }

  // ------------------------------------------------------------------ main update
  update(dt: number, inp: Input | null) {
    dt = Math.min(dt, 0.066);
    // a goal gets a short slow-motion beat before play resumes
    if (this.phase === 'GOAL') {
      const k = clamp(1 - this.phaseT / 1.2, 0, 1);
      this.timeScale = 1 - 0.6 * k * k;
    } else {
      this.timeScale += (1 - this.timeScale) * Math.min(1, dt * 5);
    }
    const sdt = dt * this.timeScale;
    if (inp && this.user) {
      this.handleUser(inp, dt);
      if (inp.pressed.reset && this.cfg.mode === 'training') this.resetBall();
    }
    this.acc += sdt;
    let n = 0;
    while (this.acc >= STEP && n < 6) {
      this.simStep(STEP);
      this.acc -= STEP;
      n++;
    }
    if (n === 6) this.acc = 0;
    // visuals
    for (const p of this.players) p.animate(sdt);
    this.updateIndicator(sdt);
    this.updateTrail(dt);
    this.shotFlash = Math.max(0, this.shotFlash - dt * 2.2);
    this.shotInfoT = Math.max(0, this.shotInfoT - dt);
    if (this.bannerT > 0) {
      this.bannerT -= dt;
      if (this.bannerT <= 0 && this.phase !== 'FULLTIME' && this.phase !== 'HALFTIME') this.banner = null;
    }
    this.updateTrainingVisuals(dt);
  }

  private updateIndicator(dt: number) {
    const u = this.user;
    if (!u) {
      this.indicator.visible = false;
      return;
    }
    this.indicator.visible = true;
    const t = this.time;
    this.ring.position.set(u.pos.x, 0.04, u.pos.z);

    // The selection ring breathes with a strike's charge.
    const charge = Math.max(this.shootCharge, this.passCharge, this.powerShotCharge);
    const rmat = this.ring.material as MeshBasicMaterial;
    if (charge > 0.05) {
      this.ring.scale.setScalar(1 + charge * 0.38);
      rmat.color.set(this.powerShotActive ? '#e89061' : '#d5dd75');
      rmat.opacity = 0.95;
    } else {
      this.ring.scale.setScalar(1);
      rmat.color.set('#d5dd75');
      rmat.opacity = 0.55;
    }

    this.cone.position.set(u.pos.x, 2.45 + Math.sin(t * 6) * 0.06, u.pos.z);
    this.cone.rotation.y = this.camYaw + Math.PI;

    // Timed finishing flash update on the triangle
    const halo = this.cone.children[0] as Mesh | undefined;
    if (halo) {
      const hmat = halo.material as MeshBasicMaterial;
      if (this.timedStateT > 0) {
        this.timedStateT -= dt;
        hmat.opacity = Math.min(1, this.timedStateT * 2.2);
        if (this.timedState === 'green') {
          hmat.color.set('#d5dd75');
          (this.cone.material as MeshBasicMaterial).color.set('#d5dd75');
        } else {
          hmat.color.set('#e89061');
          (this.cone.material as MeshBasicMaterial).color.set('#e89061');
        }
      } else {
        hmat.opacity = 0;
        (this.cone.material as MeshBasicMaterial).color.set(this.powerShotActive ? '#e89061' : '#d5dd75');
      }
    }

    const pm = this.passMarker;
    if (this.passPreview && this.phase === 'PLAY') {
      pm.visible = true;
      pm.position.set(this.passPreview.pos.x, 2.3 + Math.sin(t * 7) * 0.08, this.passPreview.pos.z);
      pm.rotation.y = this.camYaw + Math.PI;
    } else pm.visible = false;
    const showPath = !!this.passPreview && this.passCharge > 0.05 && this.ball.owner === u && this.phase === 'PLAY';
    this.passLine.visible = showPath;
    if (showPath && this.passPreview) {
      const attr = this.passLine.geometry.attributes.position as BufferAttribute;
      attr.setXYZ(0, u.pos.x, 0.16, u.pos.z);
      attr.setXYZ(1, this.passPreview.pos.x, 0.16, this.passPreview.pos.z);
      attr.needsUpdate = true;
      this.passLine.geometry.computeBoundingSphere();
    }
  }

  /** thin additive trail behind a struck ball – the one bit of post-processing the game needs */
  private buildTrail() {
    const n = 22;
    this.trailPos = new Float32Array(n * 3);
    const g = new BufferGeometry();
    g.setAttribute('position', new BufferAttribute(this.trailPos, 3));
    const m = new PointsMaterial({
      color: '#ffffff', size: 0.17, transparent: true, opacity: 0, depthWrite: false,
      blending: AdditiveBlending, sizeAttenuation: true,
    });
    this.trail = new Points(g, m);
    this.trail.frustumCulled = false;
    this.trail.visible = false;
    this.group.add(this.trail);
  }

  private updateTrail(dt: number) {
    const t = this.trail;
    if (!t) return;
    const arr = this.trailPos;
    const n = arr.length / 3;
    for (let i = n - 1; i > 0; i--) {
      arr[i * 3] = arr[(i - 1) * 3];
      arr[i * 3 + 1] = arr[(i - 1) * 3 + 1];
      arr[i * 3 + 2] = arr[(i - 1) * 3 + 2];
    }
    const b = this.ball;
    arr[0] = b.pos.x;
    arr[1] = b.pos.y;
    arr[2] = b.pos.z;
    (t.geometry.attributes.position as BufferAttribute).needsUpdate = true;
    const mat = t.material as PointsMaterial;
    const want = !b.owner && b.speed > 9.5 ? Math.min(0.8, (b.speed - 8) / 26) : 0;
    mat.opacity += (want - mat.opacity) * Math.min(1, dt * 9);
    t.visible = mat.opacity > 0.03;
  }

  /** how well an individual played – shown after full time */
  private ratingOf(p: Footballer, winner: 0 | 1 | -1) {
    let r = 6.2;
    r += p.gGoals * 1.15;
    r += p.gTackles * 0.26;
    r += p.gSaves * 0.45;
    r += Math.min(1.1, p.gPasses * 0.055);
    if (p.gShots >= 3 && p.gGoals === 0) r -= 0.3;
    if (winner === p.team) r += 0.6;
    else if (winner === -1) r += 0.15;
    return clamp(Math.round(r * 10) / 10, 3, 10);
  }

  private updateTrainingVisuals(dt: number) {
    for (const tg of this.tTargets) {
      if (!tg.alive) {
        tg.respawn -= dt;
        tg.mesh.scale.setScalar(Math.max(0.001, 1 - Math.max(0, tg.respawn) / 1.2) * 0.001 + (tg.respawn <= 0 ? 1 : 0));
        if (tg.respawn <= 0) {
          tg.alive = true;
          tg.mesh.visible = true;
          tg.mesh.scale.setScalar(1);
        }
      }
    }
    for (const z of this.tZones) z.mesh.rotation.y += dt * 0.6;
  }

  private simStep(dt: number) {
    this.time += dt;
    this.phaseT += dt;
    const b = this.ball;
    const { L, W } = this.pitch;

    // ---- phase logic
    switch (this.phase) {
      case 'KICKOFF':
        if (this.phaseT > (this.cfg.mode === 'training' ? 0.3 : 1.3)) this.startPlay();
        break;
      case 'GOAL':
        // phaseT runs on simulation time, which is slowed for the replay beat
        if (this.phaseT > 2.0) {
          const firstTo = this.cfg.goalTarget ?? 0;
          if (this.overtime || (firstTo > 0 && Math.max(this.teams[0].score, this.teams[1].score) >= firstTo) || (this.half === 2 && this.clock >= this.cfg.duration && this.teams[0].score !== this.teams[1].score)) {
            this.finish();
            break;
          }
          this.phase = 'RESET';
          this.phaseT = 0;
          this.placeKickoff(1 - this.lastGoalTeam(), false);
          this.ball.reset(0, 0);
        }
        break;
      case 'RESET':
        {
          // players jog back to their kick-off spots – only stragglers get snapped after a timeout
          const arrived = this.players.every((p) => Math.hypot(p.pos.x - p.home.x, p.pos.z - p.home.z) < 1.6);
          if ((this.phaseT > 1.0 && arrived) || this.phaseT > 5) {
            for (const p of this.players) p.place(p.home.x, p.home.z, this.teams[p.team].dir > 0 ? Math.PI / 2 : -Math.PI / 2);
            this.beginKickoffCountdown();
          }
        }
        break;
      case 'HALFTIME':
        if (this.phaseT > 6) this.continueFromHalftime();
        break;
      default:
        break;
    }

    const live = this.phase === 'PLAY';
    if (this.kickoffLock > 0) this.kickoffLock -= dt;

    // ---- clock
    if (live && this.cfg.mode === 'match') {
      if (!this.overtime) {
        this.clock += dt;
        if (this.half === 1 && this.clock >= this.cfg.duration / 2) {
          this.clock = this.cfg.duration / 2;
          this.phase = 'HALFTIME';
          this.phaseT = 0;
          this.setOwnerNull();
          for (const p of this.players) p.moveDir.set(0, 0, 0);
          audio.play('whistleLong');
          this.showBanner('HALF TIME', `${this.teams[0].score} - ${this.teams[1].score}`, 'info', 6);
        } else if (this.half === 2 && this.clock >= this.cfg.duration) {
          this.clock = this.cfg.duration;
          if (this.teams[0].score === this.teams[1].score && this.cfg.knockout) {
            this.overtime = true;
            this.overtimeClock = 0;
            audio.play('whistle');
            this.showBanner('GOLDEN GOAL', 'Next goal wins!', 'info', 2.2);
          } else this.finish();
        }
      } else {
        this.overtimeClock += dt;
        if (this.overtimeClock > 90) {
          const a = this.teams[0].def.rating;
          const bb = this.teams[1].def.rating;
          this.finish(rand() < a / (a + bb) ? 0 : 1);
        }
      }
    }

    if (this.phase === 'FULLTIME' || this.phase === 'HALFTIME') {
      // everyone idles
      for (const p of this.players) {
        p.moveDir.set(0, 0, 0);
        p.step(dt, 1, false);
      }
      b.step(dt, this.pitch);
      return;
    }

    // ---- roles (10 Hz)
    this.roleT -= dt;
    if (this.roleT <= 0) {
      this.roleT = 0.12;
      this.updateRoles();
    }

    // ---- intents
    for (const p of this.players) {
      p.decisionCd -= dt;
      if (this.phase === 'RESET') {
        p.target.copy(p.home);
        p.sprint = p.stamina > 30;
        steerToTarget(this, p);
        continue;
      }
      if (this.phase === 'GOAL' || this.phase === 'KICKOFF') {
        if (p.action !== 'CELEBRATE') p.moveDir.set(0, 0, 0);
        continue;
      }
      if (p.isUser) continue;
      if (p.action === 'CELEBRATE') continue;
      if (p.isGK) {
        updateKeeper(this, p, dt);
        if (p.holding) {
          p.holdTimer -= dt;
          if (p.holdTimer <= 0) this.keeperRelease(p);
        }
        continue;
      }
      if (this.cfg.mode === 'training') continue;
      p.thinkT -= dt;
      if (p.thinkT <= 0) {
        thinkOutfield(this, p);
        const D = this.diffFor(p.team);
        p.thinkT = D.think * (0.75 + rand() * 0.5);
      }
      // continuous tracking
      if (p.state === 'CHASE_BALL' && !p.receive) chaseTarget(this, p, p.target);
      else if (p.state === 'PRESS' && b.owner) {
        p.target.set(b.owner.pos.x + b.owner.vel.x * 0.2, 0, b.owner.pos.z + b.owner.vel.z * 0.2);
      }
      steerToTarget(this, p);
    }

    this.extraUpdate(dt);
    if (this.sp?.state === 'fetch' && this.sp.taker.isUser) {
      this.sp.taker.target.copy(this.sp.spot);
      steerToTarget(this, this.sp.taker);
    }

    // user-controlled player during restart phases: keep frozen/auto walk
    if (this.user && (this.phase === 'GOAL' || this.phase === 'KICKOFF') && this.user.action !== 'CELEBRATE') this.user.moveDir.set(0, 0, 0);
    if (this.user && this.phase === 'RESET') {
      this.user.target.copy(this.user.home);
      steerToTarget(this, this.user);
    }

    // ---- movement
    for (const p of this.players) {
      const D = this.diffFor(p.team);
      const sm = p.isUser ? 1 : D.speed;
      p.step(dt, sm, p.hasBall);
      p.clampTo(L / 2 + 1.6, W / 2 + 1.6);
    }
    this.separatePlayers();

    // The planted heavy strike can be intercepted during its short windup.
    if (this.pendingPower) {
      const shot = this.pendingPower;
      shot.delay -= dt;
      const bDist = this.ballDistTo(shot.shooter);
      if (!live || shot.shooter.stunned > 0 || (b.owner && b.owner !== shot.shooter) || bDist > 1.8) {
        this.pendingPower = null;
        if (shot.shooter.action === 'POWER_SHOT') shot.shooter.action = 'IDLE';
      } else if (shot.delay <= 0) {
        this.pendingPower = null;
        this.shoot(shot.shooter, shot.aim, shot.power, false, false, false, 1, { powerShot: true, clean: shot.clean });
      }
    }

    // ---- pass auto-switch
    if (this.pendingSwitch && this.user) {
      const mate = this.pendingSwitch;
      if (this.ballDistTo(mate) < 9 || b.owner === mate) {
        this.setUser(mate);
      } else if (b.owner && b.owner !== this.user && b.owner.team !== 0) this.pendingSwitch = null;
    }
    // auto switch while defending
    this.autoSwitchT -= dt;
    if (live && !this.sp && this.autoSwitchT <= 0 && this.cfg.settings.autoSwitch && this.cfg.mode === 'match' && this.user && b.owner?.team !== 0) {
      this.autoSwitchT = 0.4;
      const cur = this.user;
      let best: Footballer | null = null;
      let bd = this.ballDistTo(cur) - 5.5;
      for (const p of this.teams[0].outfield) {
        const d = this.ballDistTo(p);
        if (d < bd && !p.busy) {
          bd = d;
          best = p;
        }
      }
      if (best) {
        this.setUser(best);
        this.autoSwitchT = 1.2;
      }
    }

    // ---- ball
    if (live || this.phase === 'GOAL') this.updateBallControl(dt, live);
    if (this.phase === 'KICKOFF' || this.phase === 'RESET') {
      b.vel.set(0, 0, 0);
    }
    if (live && !this.sp) {
      this.resolveTackles();
      this.resolveKeepers();
      this.resolveAerialContacts();
    }
    b.step(dt, this.pitch);

    // possession time
    if (live && b.owner) this.teams[b.owner.team].possTime += dt;

    // ---- goal detection
    if (live || this.cfg.mode === 'training') this.detectGoal();
    if (live && !this.sp && !this.goalLatched && this.cfg.mode === 'match' && !this.cfg.street) this.checkOut();
    // training logic
    if (this.cfg.mode === 'training') this.trainingStep();
  }

  private lastGoalTeam(): number {
    // the team that conceded kicks off – derive from scorers list
    const last = this.scorers[this.scorers.length - 1];
    return last ? last.team : 0;
  }

  private detectGoal() {
    const b = this.ball;
    const p = this.pitch;
    if (this.goalLatched) {
      if (Math.abs(b.pos.x) < p.L / 2 - 1.5) this.goalLatched = false;
      return;
    }
    if (Math.abs(b.pos.x) > p.L / 2 + 0.12 && Math.abs(b.pos.z) < p.goalW / 2 - 0.02 && b.pos.y < p.goalH - 0.05) {
      const side = b.pos.x > 0 ? 1 : -1;
      const team = this.teams.findIndex((t) => t.dir === side);
      if (this.cfg.mode === 'training') {
        if (side !== 1) return;
        this.goalLatched = true;
        this.training.goals++;
        this.showBanner('GOAL!', 'Nice finish', 'goal', 1.2);
        audio.play('goal', 0.5);
        this.trainingResetAt = this.time + 1.6;
        return;
      }
      if (team >= 0) {
        this.goalScored(team);
        this.goalLatched = true;
      }
    }
  }

  private trainingStep() {
    const b = this.ball;
    if (this.trainingResetAt > 0 && this.time >= this.trainingResetAt) {
      this.trainingResetAt = -1;
      this.resetBall();
    }
    for (const tg of this.tTargets) {
      if (!tg.alive) continue;
      if (b.pos.x > this.pitch.L / 2 && Math.hypot(b.pos.x - tg.pos.x, b.pos.y - tg.pos.y, b.pos.z - tg.pos.z) < 0.8) {
        tg.alive = false;
        tg.mesh.visible = false;
        tg.respawn = 2.5;
        this.training.targets++;
        this.training.streak++;
        this.training.best = Math.max(this.training.best, this.training.streak);
        audio.play('tick', 1);
        this.showBanner('TARGET!', `+1  ·  streak ${this.training.streak}`, 'info', 0.8);
      }
    }
    const u = this.user;
    for (const z of this.tZones) {
      if (b.owner === null && b.lastTouch === u && b.speed < 8 && b.onGround && Math.hypot(b.pos.x - z.pos.x, b.pos.z - z.pos.z) < z.r - 0.2) {
        this.training.zones++;
        audio.play('tick', 1);
        this.showBanner('PASS ZONE!', '+1', 'info', 0.8);
        this.moveZone(z);
      }
    }
    // reset streak when ball leaves play without hitting
    if (u && b.speed < 0.3 && b.pos.x > this.pitch.L / 2 - 6 && this.training.streak > 0 && this.trainingResetAt < 0 && !b.owner) {
      // ball stopped near goal – keep streak (nothing)
    }
  }

  private separatePlayers() {
    const ps = this.players;
    for (let i = 0; i < ps.length; i++) {
      for (let j = i + 1; j < ps.length; j++) {
        const a = ps[i];
        const c = ps[j];
        if (a.action === 'SLIDE' || c.action === 'SLIDE') continue;
        const dx = c.pos.x - a.pos.x;
        const dz = c.pos.z - a.pos.z;
        const d2 = dx * dx + dz * dz;
        const min = a.isGK || c.isGK ? 0.55 : 0.7;
        if (d2 < min * min && d2 > 1e-6) {
          const d = Math.sqrt(d2);
          const push = (min - d) * 0.5;
          const nx = dx / d;
          const nz = dz / d;
          // stronger player holds ground
          const wa = a.def.stats.physical / (a.def.stats.physical + c.def.stats.physical);
          a.pos.x -= nx * push * (1 - wa) * 2;
          a.pos.z -= nz * push * (1 - wa) * 2;
          c.pos.x += nx * push * wa * 2;
          c.pos.z += nz * push * wa * 2;
        }
      }
    }
  }

  private updateBallControl(dt: number, live: boolean) {
    const b = this.ball;
    let o = b.owner;
    if (o) {
      if (o.holding) {
        const f = o.fwd;
        if (o.isGK) b.pos.set(o.pos.x + f.x * 0.35, 1.1, o.pos.z + f.z * 0.35);
        else if (this.sp && this.sp.kind === 'corner') b.pos.set(this.sp.spot.x, b.r, this.sp.spot.z);
        else b.pos.set(o.pos.x + f.x * 0.12, 1.55, o.pos.z + f.z * 0.12);
        b.vel.set(0, 0, 0);
        o.hasBall = true;
        return;
      }
      const d = this.ballDistTo(o);
      const lost = d > 1.9 || b.pos.y > 1.4 || o.kickCooldown > 0 || o.action === 'FALL' || o.action === 'SLIDE' || o.action === 'SAVE' || o.action === 'CELEBRATE';
      if (lost) {
        this.setOwnerNull();
        o = null;
      }
    }
    // while a throw-in / corner is being fetched nobody else may pick the ball up
    if (!o && live && !(this.sp && this.sp.state === 'fetch')) {
      let best: Footballer | null = null;
      let bd = 9;
      for (const p of this.players) {
        if (p.kickCooldown > 0 || p.stunned > 0 || p.action === 'FALL' || p.action === 'SLIDE' || p.action === 'CELEBRATE') continue;
        if (p.isGK && (p.action === 'SAVE')) continue;
        const d = this.ballDistTo(p);
        const reach = p.isGK ? 1.0 : 0.82 + (p.action === 'TACKLE' ? 0.35 : 0);
        const h = p.isGK ? 1.6 : 0.95;
        if (d < reach && b.pos.y < h && d < bd) {
          bd = d;
          best = p;
        }
      }
      if (best) {
        if (best.isGK) {
          if (b.speed < 7.5 && this.inOwnBox(best, b.pos) && best.kickCooldown <= 0) this.keeperCatch(best);
          else if (b.speed < 7.5) {
            this.setOwner(best);
          }
        } else {
          const rvx = b.vel.x - best.vel.x;
          const rvz = b.vel.z - best.vel.z;
          const rel = Math.hypot(rvx, rvz, b.vel.y * 0.5);
          const expected = best.receive && this.time < best.receive.until ? best.def.stats.ballControl * 0.032 : 0;
          const thr = 7.5 + best.def.stats.ballControl * 0.13 + expected + (best.isUser ? 1.2 : 0);
          if (rel < thr) {
            this.setOwner(best);
            b.vel.x = best.vel.x * 0.95;
            b.vel.z = best.vel.z * 0.95;
            if (b.vel.y > 0) b.vel.y = 0;
            b.lastTouch = best;
            this.possession = best.team;
          } else {
            // heavy touch – ball deflects away
            b.vel.x *= 0.45;
            b.vel.z *= 0.45;
            b.vel.x += gauss() * 3 + best.vel.x * 0.2;
            b.vel.z += gauss() * 3 + best.vel.z * 0.2;
            b.lastTouch = best;
            best.kickCooldown = 0.25;
            this.possession = best.team;
            audio.play('bounce', 0.6);
          }
        }
      }
    }
    o = b.owner;
    if (o && !o.isGK) {
      // dribble control: soft spring toward a spot in front of the feet
      const st = o.def.stats;
      const f = o.fwd;
      const sp = o.speed;
      const sprinting = sp > 7;
      // Move the touch toward the player's intended direction at low speeds;
      // sprinting remains heavier so a defender can time a tackle.
      if (o.moveDir.lengthSq() > 0.12 && sp < 6.8) {
        f.lerp(this.tmp2.copy(o.moveDir).normalize(), clamp((6.8 - sp) / 8.5, 0.06, 0.58)).normalize();
      }
      const dist = 0.6 + (sprinting ? 0.4 : sp > 3 ? 0.15 : 0) * (1.15 - st.ballControl / 145);
      const spotX = o.pos.x + f.x * dist;
      const spotZ = o.pos.z + f.z * dist;
      // turning sharply reduces control
      const turn = Math.min(1, Math.abs(o.turnRate) / 9);
      let control = 0.55 + (st.ballControl / 100) * 0.4 + (st.dribbling / 100) * 0.15 - turn * 0.2 * (sp / 8) - (sprinting ? 0.1 : 0);
      if (o.action === 'SKILL' || o.action === 'ROULETTE') control += 0.13;
      control = clamp(control, 0.3, 1);
      const ex = spotX - b.pos.x;
      const ez = spotZ - b.pos.z;
      const desX = o.vel.x * 0.85 + ex * 11;
      const desZ = o.vel.z * 0.85 + ez * 11;
      const k = 1 - Math.exp(-(12 * control) * dt);
      b.vel.x += (desX - b.vel.x) * k;
      b.vel.z += (desZ - b.vel.z) * k;
      if (control < 0.5 && sp > 4) {
        // loose touch: ball gets pushed a bit too far
        b.vel.x += f.x * (0.5 - control) * 6 * dt * 20 * Math.max(0, gauss());
        b.vel.z += f.z * (0.5 - control) * 6 * dt * 20 * Math.max(0, gauss());
      }
      o.dribbling = true;
      // opponents can steal with body contact
      if (live) {
        for (const q of this.teams[1 - o.team].outfield) {
          if (q.busy || q.stunned > 0 || q.kickCooldown > 0) continue;
          const dq = this.ballDistTo(q);
          if (dq < 0.75) {
            const dd = this.diffFor(q.team);
            const skillFactor = o.action === 'SKILL' || o.action === 'ROULETTE' ? 0.35 : 1;
            const rate = 0.45 * skillFactor * clamp((q.def.stats.defending + q.def.stats.ballControl) / (st.dribbling + st.ballControl), 0.5, 1.6) * (q.isUser ? 1 : 0.5 + dd.tackle * 0.6) * (sprinting ? 0.5 : 1);
            if (rand() < rate * dt) {
              this.setOwnerNull();
              b.vel.x += (q.pos.x - o.pos.x) * 3;
              b.vel.z += (q.pos.z - o.pos.z) * 3;
              o.kickCooldown = 0.4;
              o.stunned = 0.25;
              audio.play('tackle', 0.5);
              break;
            }
          }
        }
      }
    }
    for (const p of this.players) if (p !== b.owner) p.dribbling = false;
  }

  // ------------------------------------------------------------------ outputs for engine
  cameraFocus(out: Vector3): Vector3 {
    const u = this.user;
    const b = this.ball;
    if (this.phase === 'GOAL') return out.copy(this.celebrateFocus);
    if (!u) return out.copy(b.pos);
    // Keep the ball in view even across long passes without jerking the camera away
    // from the player while dribbling.
    const bx = b.pos.x - u.pos.x;
    const bz = b.pos.z - u.pos.z;
    const d = Math.hypot(bx, bz);
    const blend = b.owner === u ? 0.32 : b.owner?.team === u.team ? 0.6 : 0.78;
    const s = d > 0.01 ? Math.min(d * blend, b.owner === u ? 8 : 34) / d : 0;
    return out.set(u.pos.x + bx * s, 0, u.pos.z + bz * s);
  }

  hud(): HudState {
    const a = this.teams[0];
    const bT = this.teams[1];
    const u = this.user;
    const training = this.cfg.mode === 'training';
    let clock = '00:00';
    if (!training) {
      const c = this.overtime ? this.cfg.duration + this.overtimeClock : this.clock;
      const mm = Math.floor(c / 60);
      const ss = Math.floor(c % 60);
      clock = `${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}`;
    }
    const half = training
      ? 'FREE PRACTICE'
      : this.overtime
        ? 'GOLDEN GOAL'
        : this.cfg.street
          ? `STREET · FIRST TO ${this.cfg.goalTarget ?? 5}`
          : this.half === 1
            ? '1ST HALF'
            : '2ND HALF';
    const extra: HudState['extra'] = training
      ? [
          { label: 'TARGETS', value: this.training.targets },
          { label: 'ZONES', value: this.training.zones },
          { label: 'GOALS', value: this.training.goals },
          { label: 'BEST STREAK', value: this.training.best },
        ]
      : [];
    let hint = '';
    if (this.phase === 'HALFTIME') hint = 'Second half starts shortly — press ENTER to continue';
    else if (training) hint = 'B: reset ball · Hold LMB to charge shots · Q pass · RMB through';
    else if (this.phase === 'PLAY' && this.time - this.playStart < 12) {
      hint = this.cfg.street
        ? 'WASD move  |  C beat your marker  |  Q pass  |  hold LMB to strike  |  walls stay live'
        : 'WASD move  |  Q pass  |  LMB strike  |  F + LMB bend  |  V + LMB drive  |  C skill  |  E tackle';
    }
    return {
      mode: training ? 'training' : 'match',
      homeName: a.def.name, awayName: bT.def.name, homeShort: a.def.short, awayShort: bT.def.short,
      homeColor: a.kit.primary, awayColor: bT.kit.primary,
      homeScore: a.score, awayScore: bT.score,
      clock, half, phase: this.phase, banner: this.banner,
      stamina: u ? u.stamina : 100, shootCharge: this.shootCharge, passCharge: this.passCharge,
      playerName: u ? u.def.name : '', playerNumber: u ? u.def.number : 0, playerPos: u ? u.def.pos : '',
      canSwitch: a.outfield.length > 1,
      attacking: training || this.ball.owner?.team === 0 || (this.ball.owner === null && this.possession === 0),
      face: u ? { skin: u.def.skin, hair: u.def.hair, hairColor: hairColorFor(u.def.number + u.def.skin) } : undefined,
      tactic: a.tactic, difficulty: this.cfg.difficulty, extra, hint,
      countdown: this.phase === 'KICKOFF' ? Math.max(0, 1.3 - this.phaseT) : 0,
      setPiece: this.sp ? { kind: this.sp.kind, team: this.sp.team, state: this.sp.state } : undefined,
      powerShotActive: this.powerShotActive || this.pendingPower !== null,
      powerShotCharge: this.powerShotCharge,
      timedState: this.timedStateT > 0 ? this.timedState : null,
      lastShotSpeedKmh: this.lastShotSpeedKmh,
      lastShotType: this.lastShotType,
      shotStyle: this.shootCharge > 0 ? this.shotModifier : undefined,
      shotInfoT: this.shotInfoT,
      goalSpeedKmh: this.goalSpeedKmh,
      goalDistanceM: this.goalDistanceM,
    };
  }

  setTactic(t: Tactic) {
    this.teams[0].tactic = t;
  }
}

function bootColor(id: string): string {
  const map: Record<string, string> = { black: '#15171c', white: '#f1f3f6', orange: '#ff7a1a', lime: '#b6ff2e', gold: '#f4c430', pink: '#ff3d9a' };
  return map[id] ?? '#15171c';
}

export type { Pos };
export { bestPass };
