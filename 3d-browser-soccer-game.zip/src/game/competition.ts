import { NATIONS, TEAMS, getTeam } from './config';
import { updateSave, type CompState, type Fx } from './save';

// National League (8 clubs, single round robin) and International Cup (8 nations: 2 groups → semis → final).

export const SEMI_NAMES = ['Semifinal', 'Final'];

function shuffle<T>(a: T[]): T[] {
  const r = [...a];
  for (let i = r.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [r[i], r[j]] = [r[j], r[i]];
  }
  return r;
}

/** circle-method round robin */
function roundRobin(ids: string[]): Fx[][] {
  const t = [...ids];
  if (t.length % 2) t.push('');
  const n = t.length;
  const rounds: Fx[][] = [];
  for (let r = 0; r < n - 1; r++) {
    const row: Fx[] = [];
    for (let i = 0; i < n / 2; i++) {
      const a = t[i];
      const b = t[n - 1 - i];
      if (a && b) row.push(r % 2 ? { a: b, b: a } : { a, b });
    }
    rounds.push(row);
    t.splice(1, 0, t.pop() as string);
  }
  return rounds;
}

export function createLeague(teamId: string): CompState {
  const ids = shuffle(TEAMS.map((t) => t.id));
  return { kind: 'league', teamId, groups: [ids], rounds: roundRobin(ids), ko: [], day: 0, stage: 'group', status: 'active' };
}

export function createCup(teamId: string): CompState {
  const ids = shuffle(NATIONS.map((t) => t.id));
  const gA = ids.slice(0, 4);
  const gB = ids.slice(4);
  const ra = roundRobin(gA);
  const rb = roundRobin(gB);
  return { kind: 'cup', teamId, groups: [gA, gB], rounds: ra.map((r, i) => [...r, ...rb[i]]), ko: [], day: 0, stage: 'group', status: 'active' };
}

// ---------------------------------------------------------------- simulation of AI-vs-AI games
function poisson(l: number): number {
  const L = Math.exp(-l);
  let k = 0;
  let p = 1;
  do {
    k++;
    p *= Math.random();
  } while (p > L && k < 9);
  return k - 1;
}
function simInto(f: Fx, knockout: boolean) {
  const A = getTeam(f.a);
  const B = getTeam(f.b);
  const lam = (att: number, def: number, gk: number) => 1.45 * Math.pow(att / (def * 0.6 + gk * 0.4), 4);
  let ga = poisson(lam(A.attack, B.defense, B.goalkeeper));
  let gb = poisson(lam(B.attack, A.defense, A.goalkeeper));
  if (knockout && ga === gb) {
    if (Math.random() < A.rating / (A.rating + B.rating)) ga++;
    else gb++;
    f.pens = true;
  }
  f.ga = ga;
  f.gb = gb;
}
const winnerOf = (f: Fx) => ((f.ga ?? 0) > (f.gb ?? 0) ? f.a : f.b);

// ---------------------------------------------------------------- tables
export interface Row { id: string; p: number; w: number; d: number; l: number; gf: number; ga: number; gd: number; pts: number }

export function table(s: CompState, gi: number): Row[] {
  const rows = new Map<string, Row>();
  for (const id of s.groups[gi] ?? []) rows.set(id, { id, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, gd: 0, pts: 0 });
  for (const r of s.rounds) {
    for (const f of r) {
      if (f.ga === undefined || f.gb === undefined) continue;
      const A = rows.get(f.a);
      const B = rows.get(f.b);
      if (!A || !B) continue;
      A.p++;
      B.p++;
      A.gf += f.ga;
      A.ga += f.gb;
      B.gf += f.gb;
      B.ga += f.ga;
      if (f.ga > f.gb) {
        A.w++;
        B.l++;
        A.pts += 3;
      } else if (f.ga < f.gb) {
        B.w++;
        A.l++;
        B.pts += 3;
      } else {
        A.d++;
        B.d++;
        A.pts++;
        B.pts++;
      }
    }
  }
  const out = [...rows.values()];
  for (const r of out) r.gd = r.gf - r.ga;
  return out.sort((x, y) => y.pts - x.pts || y.gd - x.gd || y.gf - x.gf || x.id.localeCompare(y.id));
}

// ---------------------------------------------------------------- progression
export function currentList(s: CompState): Fx[] {
  if (s.stage === 'group') return s.rounds[s.day] ?? [];
  if (s.stage === 'semi') return s.ko[0] ?? [];
  if (s.stage === 'final') return s.ko[1] ?? [];
  return [];
}

export function nextFixture(s: CompState | null): Fx | null {
  if (!s || s.status !== 'active') return null;
  return currentList(s).find((f) => (f.a === s.teamId || f.b === s.teamId) && f.ga === undefined) ?? null;
}

export const isKnockout = (s: CompState) => s.stage === 'semi' || s.stage === 'final';

export function stageLabel(s: CompState): string {
  if (s.kind === 'league') return `Matchday ${Math.min(s.day + 1, s.rounds.length)} of ${s.rounds.length}`;
  if (s.stage === 'group') return `Group stage · Matchday ${s.day + 1} of ${s.rounds.length}`;
  if (s.stage === 'semi') return 'Semifinal';
  if (s.stage === 'final') return 'Final';
  return 'Finished';
}

function advance(s: CompState) {
  if (s.stage === 'group') {
    s.day++;
    if (s.day < s.rounds.length) return;
    if (s.kind === 'league') {
      s.stage = 'done';
      s.status = table(s, 0)[0].id === s.teamId ? 'champion' : 'finished';
      return;
    }
    const ta = table(s, 0);
    const tb = table(s, 1);
    s.ko = [[{ a: ta[0].id, b: tb[1].id }, { a: tb[0].id, b: ta[1].id }], []];
    if ([ta[0].id, ta[1].id, tb[0].id, tb[1].id].includes(s.teamId)) {
      s.stage = 'semi';
    } else {
      // eliminated in the groups – play out the rest for the record
      s.status = 'eliminated';
      s.ko[0].forEach((f) => simInto(f, true));
      s.ko[1] = [{ a: winnerOf(s.ko[0][0]), b: winnerOf(s.ko[0][1]) }];
      simInto(s.ko[1][0], true);
      s.stage = 'done';
    }
    return;
  }
  if (s.stage === 'semi') {
    const w = s.ko[0].map(winnerOf);
    s.ko[1] = [{ a: w[0], b: w[1] }];
    if (!w.includes(s.teamId)) {
      s.status = 'eliminated';
      simInto(s.ko[1][0], true);
      s.stage = 'done';
    } else s.stage = 'final';
    return;
  }
  if (s.stage === 'final') {
    s.stage = 'done';
    s.status = winnerOf(s.ko[1][0]) === s.teamId ? 'champion' : 'eliminated';
  }
}

/** Record the human's result, simulate every other fixture of the round and advance the competition. */
export function recordResult(kind: 'league' | 'cup', userGoals: number, oppGoals: number, userWon: boolean) {
  updateSave((d) => {
    const s = kind === 'league' ? d.league : d.cup;
    if (!s || s.status !== 'active') return;
    const ko = isKnockout(s);
    const list = currentList(s);
    const f = list.find((x) => (x.a === s.teamId || x.b === s.teamId) && x.ga === undefined);
    if (!f) return;
    const userIsA = f.a === s.teamId;
    let ug = userGoals;
    let og = oppGoals;
    if (ko && ug === og) {
      if (userWon) ug++;
      else og++;
      f.pens = true;
    }
    f.ga = userIsA ? ug : og;
    f.gb = userIsA ? og : ug;
    for (const o of list) if (o.ga === undefined) simInto(o, ko);
    advance(s);
    if ((s.status as string) === 'champion' && kind === 'cup') d.stats.tournaments++;
  });
}

export function userPlace(s: CompState): number {
  return table(s, s.groups.findIndex((g) => g.includes(s.teamId))).findIndex((r) => r.id === s.teamId) + 1;
}
