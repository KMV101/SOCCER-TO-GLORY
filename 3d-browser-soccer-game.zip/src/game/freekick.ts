import { BufferAttribute, BufferGeometry, CircleGeometry, Group, Mesh, MeshBasicMaterial, Points, PointsMaterial, RingGeometry, Vector3, type Scene } from 'three';
import { DIFFICULTY, getRoster, makePitch, teamPattern, type Difficulty, type PitchSpec, type TeamDef } from './config';
import { Ball, GRAVITY } from './ball';
import { Footballer } from './entities';
import { audio } from './audio';
import { contrastColor, gkColor, hairColorFor, type KitSpec } from './models';
import type { Input } from './input';
import type { Custom, Settings } from './save';
import type { HudState, MatchResult } from './match';

export interface FkHud {
  attempts: ('goal' | 'miss')[];
  total: number;
  goals: number;
  stage: string;
  power: number;
  curve: number;
  aimU: number;
  aimV: number;
  dist: number;
  wall: number;
  blockedPreview: boolean;
}

export interface FreeKickConfig {
  home: TeamDef;
  away: TeamDef;
  homeKit: { primary: string; secondary: string; pattern?: number };
  difficulty: Difficulty;
  custom: Custom;
  level: number;
  attempts: number;
  settings: Settings;
}

type Stage = 'INTRO' | 'AIM' | 'RUNUP' | 'FLIGHT' | 'RESULT' | 'DONE';
const rand = Math.random;
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const gauss = () => rand() + rand() + rand() - 1.5;
const SKINS = ['#f6d3b3', '#e8b48a', '#c98e62', '#a46a43', '#7a4a2d', '#4d2e1c'];
const BOOTS: Record<string, string> = { black: '#15171c', white: '#f1f3f6', orange: '#ff7a1a', lime: '#b6ff2e', gold: '#f4c430', pink: '#ff3d9a' };

interface Sim { y: number; z: number; t: number; path: Vector3[] }

/** mirrors Ball.step air physics (gravity, drag, magnus) so the aim preview matches the real flight */
function simulate(from: Vector3, vx: number, vy: number, vz: number, spinY: number, goalX: number): Sim {
  const p = from.clone();
  const v = new Vector3(vx, vy, vz);
  let sy = spinY;
  const path: Vector3[] = [];
  const dt = 1 / 120;
  let t = 0;
  let n = 0;
  while (t < 3) {
    v.y -= GRAVITY * dt;
    v.multiplyScalar(Math.max(0, 1 - 0.0042 * v.length() * dt));
    const ax = sy * v.z * 0.014 * dt;
    const az = -sy * v.x * 0.014 * dt;
    v.x += ax;
    v.z += az;
    sy *= 1 - 0.25 * dt;
    const px = p.x;
    const py = p.y;
    const pz = p.z;
    p.addScaledVector(v, dt);
    t += dt;
    if (++n % 6 === 0) path.push(p.clone());
    if (p.x >= goalX) {
      const k = (goalX - px) / (p.x - px || 1);
      return { y: py + (p.y - py) * k, z: pz + (p.z - pz) * k, t, path };
    }
    if (p.y < 0.24) return { y: 0.24, z: p.z, t, path };
  }
  return { y: p.y, z: p.z, t, path };
}

export class FreeKickGame {
  readonly pitch: PitchSpec;
  readonly ball = new Ball();
  readonly group = new Group();
  stage: Stage = 'INTRO';
  stageT = 0;
  time = 0;
  attempts: ('goal' | 'miss')[] = [];
  goals = 0;
  aimU = 0;
  aimV = 0.7;
  curve = 0;
  power = 0;
  charging = false;
  message = '';
  messageT = 0;
  shotFlash = 0;
  justScored = false;
  result: MatchResult | null = null;
  onFinish: ((r: MatchResult) => void) | null = null;

  private kicker: Footballer;
  private keeper: Footballer;
  private wall: Footballer[] = [];
  private wallN = 3;
  private wallCenter = new Vector3();
  private dirU = new Vector3(1, 0, 0);
  private perp = new Vector3(0, 0, 1);
  private spot = new Vector3();
  private dist = 20;
  private reticle: Mesh;
  private reticleDot: Mesh;
  private trail: Points;
  private trailPos: Float32Array;
  private blockedPreview = false;
  private flags = { saved: false, post: false, blocked: false, blockedAt: 0, resolved: false, keeperTried: false };
  private dive = { at: -1, started: false, t0: 0, fromZ: 0, toZ: 0, height: 1 };
  private land = { y: 1, z: 0, t: 1 };
  private jumpAt = -1;
  private jumpUntil = 0;
  private done = false;

  cancelCharge() {
    this.charging = false;
    if (this.stage === 'AIM') this.power = 0;
  }

  constructor(private cfg: FreeKickConfig, scene: Scene, shadows: boolean) {
    this.pitch = makePitch(5);
    scene.add(this.group);
    this.group.add(this.ball.mesh, this.ball.shadow);
    this.ball.onEvent = (e, s) => {
      if (e === 'post') {
        this.flags.post = true;
        audio.play('post', 0.6 + s);
      } else if (e === 'net') audio.play('net', s);
      else if (e === 'bounce') audio.play('bounce', s);
    };
    const away = cfg.away;
    const clash = cfg.away.primary.toLowerCase() === cfg.homeKit.primary.toLowerCase();
    const awayKit = clash ? { primary: away.secondary, secondary: away.primary, pattern: 0 } : { primary: away.primary, secondary: away.secondary, pattern: teamPattern(away.id) };
    const gk = gkColor([cfg.homeKit.primary, awayKit.primary]);
    // kicker = the player's custom character
    const c = cfg.custom;
    const b = Math.min(12, cfg.level * 0.9) + cfg.home.attack - 6;
    const s = (v: number) => clamp(Math.round(b + v), 40, 99);
    const kd = {
      id: 'custom', name: c.name || 'ROOKIE', number: c.number, pos: 'FWD' as const, archetype: 'Finisher' as const, hair: c.hair, skin: c.skin,
      stats: { speed: s(2), acceleration: s(2), shooting: s(7), passing: s(0), dribbling: s(2), defending: s(-10), physical: s(0), stamina: s(4), ballControl: s(3) },
    };
    const kitK: KitSpec = {
      primary: cfg.homeKit.primary, secondary: cfg.homeKit.secondary, shorts: cfg.homeKit.secondary, socks: cfg.homeKit.primary, boots: BOOTS[c.boots] ?? '#15171c',
      skin: SKINS[c.skin % 6], hairColor: hairColorFor(c.number + c.skin), hair: c.hair, number: c.number, pattern: cfg.homeKit.pattern ?? 0, seed: 1 + (c.number % 6),
    };
    this.kicker = new Footballer(kd, 0, 1, kitK, shadows);
    const roster = getRoster(away);
    const gkDef = roster.find((p) => p.pos === 'GK')!;
    this.keeper = new Footballer(gkDef, 1, 0, {
      primary: gk, secondary: contrastColor(gk), shorts: '#1a1d24', socks: '#1a1d24', boots: '#15171c', skin: SKINS[gkDef.skin % 6],
      hairColor: hairColorFor(gkDef.number + gkDef.skin), hair: gkDef.hair, number: gkDef.number, gloves: '#f4f6fa', seed: 1 + (gkDef.number % 6),
    }, shadows);
    const outfield = roster.filter((p) => p.pos !== 'GK').slice(0, 5);
    for (const pd of outfield) {
      const w = new Footballer(pd, 1, 2, {
        primary: awayKit.primary, secondary: awayKit.secondary, shorts: awayKit.secondary, socks: awayKit.primary, boots: '#15171c', skin: SKINS[pd.skin % 6],
        hairColor: hairColorFor(pd.number + pd.skin), hair: pd.hair, number: pd.number, pattern: awayKit.pattern, seed: 1 + (pd.number % 6),
      }, shadows);
      w.lookAt = this.ball.pos;
      this.wall.push(w);
      this.group.add(w.group);
    }
    this.keeper.lookAt = this.ball.pos;
    this.group.add(this.kicker.group, this.keeper.group);

    this.reticle = new Mesh(new RingGeometry(0.3, 0.38, 24), new MeshBasicMaterial({ color: '#ffe14d', transparent: true, opacity: 0.95, depthTest: false }));
    this.reticleDot = new Mesh(new CircleGeometry(0.06, 10), new MeshBasicMaterial({ color: '#ffffff', depthTest: false }));
    this.reticle.renderOrder = 10;
    this.reticleDot.renderOrder = 10;
    this.reticle.rotation.y = -Math.PI / 2;
    this.reticleDot.rotation.y = -Math.PI / 2;
    this.group.add(this.reticle, this.reticleDot);

    this.trailPos = new Float32Array(40 * 3);
    const tg = new BufferGeometry();
    tg.setAttribute('position', new BufferAttribute(this.trailPos, 3));
    this.trail = new Points(tg, new PointsMaterial({ color: '#ffffff', size: 0.2, transparent: true, opacity: 0.9, depthTest: false }));
    this.trail.frustumCulled = false;
    this.trail.renderOrder = 9;
    this.group.add(this.trail);

    this.setup();
    this.stage = 'INTRO';
    this.say('FREE KICK CHALLENGE', 2);
  }

  private say(m: string, t = 1.8) {
    this.message = m;
    this.messageT = t;
  }

  dispose() {
    this.onFinish = null;
    [this.kicker, this.keeper, ...this.wall].forEach((p) => p.dispose());
    this.group.traverse((o) => {
      const m = o as Mesh;
      if (m.userData?.shared) return; // blob shadows share module-level resources
      if (m.isMesh || (o as Points).isPoints) {
        (o as Mesh).geometry?.dispose();
        const mat = (o as Mesh).material;
        if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
        else mat?.dispose();
      }
    });
    this.group.removeFromParent();
  }

  // ---------------------------------------------------------------- setup of one attempt
  private setup() {
    const p = this.pitch;
    const d = 17 + rand() * 10;
    const ang = (rand() * 2 - 1) * 0.62;
    this.dist = d;
    this.spot.set(p.L / 2 - d * Math.cos(ang), 0, d * Math.sin(ang));
    this.dirU.set(Math.cos(ang), 0, -Math.sin(ang));
    this.perp.set(-this.dirU.z, 0, this.dirU.x);
    this.ball.reset(this.spot.x, this.spot.z);

    const hard = this.cfg.difficulty === 'HARD' || this.cfg.difficulty === 'PRO';
    this.wallN = d < 20 ? 3 : hard && d > 22 ? 5 : 4;
    this.wallCenter.copy(this.spot).addScaledVector(this.dirU, 9.15);
    this.wall.forEach((w, i) => {
      w.group.visible = i < this.wallN;
      const off = (i - (this.wallN - 1) / 2) * 0.72;
      const x = this.wallCenter.x + this.perp.x * off;
      const z = this.wallCenter.z + this.perp.z * off;
      w.place(x, z, Math.atan2(this.spot.x - x, this.spot.z - z));
      w.lookAt = this.ball.pos;
    });
    this.keeper.place(p.L / 2 - 0.35, clamp(this.spot.z * 0.15, -1, 1), -Math.PI / 2);
    this.keeper.lookAt = this.ball.pos;
    this.kicker.place(this.spot.x - this.dirU.x * 2.6, this.spot.z - this.dirU.z * 2.6, Math.atan2(this.dirU.x, this.dirU.z));
    this.aimU = 0;
    this.aimV = 0.72;
    this.curve = 0;
    this.power = 0;
    this.charging = false;
    this.flags = { saved: false, post: false, blocked: false, blockedAt: 0, resolved: false, keeperTried: false };
    this.dive = { at: -1, started: false, t0: 0, fromZ: 0, toZ: 0, height: 1 };
    this.jumpAt = -1;
    this.jumpUntil = 0;
    this.stage = 'AIM';
    this.stageT = 0;
  }

  // ---------------------------------------------------------------- physics solver
  private solve(from: Vector3, ty: number, tz: number, speed: number, curve: number) {
    const gx = this.pitch.L / 2;
    const dx = gx - from.x;
    const spin = -curve * 28;
    let ay = ty;
    let az = tz;
    const vel = new Vector3();
    let sim: Sim = { y: 0, z: 0, t: 1, path: [] };
    for (let i = 0; i < 6; i++) {
      const dz = az - from.z;
      const T = Math.hypot(dx, dz) / speed;
      vel.set(dx / T, (ay - from.y + 0.5 * GRAVITY * T * T) / T, dz / T);
      sim = simulate(from, vel.x, vel.y, vel.z, spin, gx);
      ay += (ty - sim.y) * 0.9;
      az += (tz - sim.z) * 0.9;
    }
    return { vel, spin, sim };
  }

  private target() {
    const p = this.pitch;
    return { ty: Math.max(0.15, this.aimV * p.goalH), tz: this.aimU * (p.goalW / 2) };
  }

  private launch() {
    const b = this.ball;
    const { ty, tz } = this.target();
    const power = Math.max(0.2, this.power);
    const speed = 17 + 14 * power;
    const st = this.kicker.def.stats;
    const err = (0.05 + (1 - st.shooting / 100) * 0.28) * (1 + 1.8 * Math.abs(power - 0.72)) * (1 + (1 - this.kicker.stamFactor));
    const from = new Vector3(b.pos.x, b.pos.y, b.pos.z);
    const sol = this.solve(from, ty + gauss() * err * 1.4, tz + gauss() * err * 3.2, speed, this.curve);
    b.vel.copy(sol.vel);
    b.spin.set(0, sol.spin, 0);
    b.shotId++;
    b.lastKickTeam = 0;
    b.owner = null;
    this.land = { y: sol.sim.y, z: sol.sim.z, t: sol.sim.t };
    this.kicker.setAction('KICK', 0.45, power);
    this.kicker.kickCooldown = 1;
    audio.play('kick', 0.8 + power * 0.5);
    this.shotFlash = 1;
    this.stage = 'FLIGHT';
    this.stageT = 0;

    // keeper & wall reactions
    const D = DIFFICULTY[this.cfg.difficulty];
    const gw = this.pitch.goalW / 2;
    const read = rand() < 0.22 + 0.55 * D.awareness;
    const wantZ = read ? this.land.z : (rand() < 0.5 ? -1 : 1) * gw * (0.35 + rand() * 0.55);
    const react = D.gkReaction * 0.9 + 0.08;
    const reachMax = Math.max(0, 6.8 * (this.land.t - react));
    const dz = clamp(wantZ - this.keeper.pos.z, -reachMax, reachMax);
    this.dive = {
      at: this.time + react, started: false, t0: 0, fromZ: this.keeper.pos.z, toZ: clamp(this.keeper.pos.z + dz, -gw - 0.7, gw + 0.7),
      height: clamp(read ? this.land.y : 0.9, 0.3, 2.1),
    };
    this.jumpAt = rand() < 0.65 ? this.time + 0.12 + rand() * 0.08 : -1;
  }

  private startDive() {
    const gk = this.keeper;
    this.dive.started = true;
    this.dive.t0 = this.time;
    this.dive.fromZ = gk.pos.z;
    gk.diveDir.set(0, 0, Math.sign(this.dive.toZ - gk.pos.z) || 1);
    gk.diveHeight = clamp(this.dive.height / 2, 0, 1);
    gk.setAction('SAVE', 1.0);
  }

  private keeperCheck() {
    if (this.flags.saved || this.flags.keeperTried) return;
    const b = this.ball;
    const gk = this.keeper;
    const p = this.pitch;
    const hy = this.dive.started ? clamp(this.dive.height, 0.4, 2.1) : 1.05;
    const d = Math.hypot((b.pos.x - gk.pos.x) * 0.6, b.pos.y - hy, b.pos.z - gk.pos.z);
    const reach = (this.dive.started ? 1.2 : 0.85) + (gk.def.stats.defending - 70) * 0.004;
    if (d < reach && b.pos.x > p.L / 2 - 1.4 && b.vel.x > 0) {
      this.flags.keeperTried = true;
      const D = DIFFICULTY[this.cfg.difficulty];
      const quality = clamp(0.62 * D.gkSave + 0.2, 0.2, 0.95);
      const speedPenalty = clamp((b.speed - 20) / 40, 0, 0.35);
      if (rand() < quality - speedPenalty) {
        this.flags.saved = true;
        if (b.speed < 21 && rand() < 0.5) {
          b.vel.set(0, 0, 0);
          b.pos.x = gk.pos.x - 0.3;
        } else b.vel.set(-b.speed * 0.35 - 2, 2 + rand() * 2.5, Math.sign(b.pos.z - gk.pos.z || 1) * (3 + rand() * 4));
        if (gk.action !== 'SAVE') gk.setAction('SAVE', 0.7);
        audio.play('save');
      } else {
        b.vel.multiplyScalar(0.85);
        audio.play('save', 0.5);
      }
    }
  }

  private wallCollide() {
    if (this.flags.blocked) return;
    const b = this.ball;
    const jumping = this.time < this.jumpUntil;
    for (let i = 0; i < this.wallN; i++) {
      const w = this.wall[i];
      const h = 1.95 + (jumping ? 0.45 : 0);
      const dx = b.pos.x - w.pos.x;
      const dz = b.pos.z - w.pos.z;
      const d = Math.hypot(dx, dz);
      const min = 0.34 + b.r;
      if (d < min && b.pos.y < h + 0.1 && d > 1e-4) {
        const nx = dx / d;
        const nz = dz / d;
        const vn = b.vel.x * nx + b.vel.z * nz;
        if (vn < 0) {
          b.vel.x -= 1.5 * vn * nx;
          b.vel.z -= 1.5 * vn * nz;
          b.vel.x *= 0.55;
          b.vel.z *= 0.55;
          b.vel.y = Math.max(b.vel.y * 0.4, 2.2);
          b.pos.x += nx * (min - d);
          b.pos.z += nz * (min - d);
          this.flags.blocked = true;
          this.flags.blockedAt = this.time;
          audio.play('tackle', 0.7);
          return;
        }
      }
    }
  }

  // ---------------------------------------------------------------- update
  update(dt: number, inp: Input | null) {
    dt = Math.min(dt, 0.05);
    this.time += dt;
    this.stageT += dt;
    this.shotFlash = Math.max(0, this.shotFlash - dt * 2);
    if (this.messageT > 0) this.messageT -= dt;
    const p = this.pitch;
    const b = this.ball;
    const gw = p.goalW / 2;

    if (this.stage === 'INTRO' && this.stageT > 1.3) {
      this.stage = 'AIM';
      this.stageT = 0;
    }

    switch (this.stage) {
      case 'AIM':
        if (inp) {
          this.aimU = clamp(this.aimU + inp.moveX * dt * 1.1, -1.25, 1.25);
          this.aimV = clamp(this.aimV + inp.moveY * dt * 0.85, 0.08, 1.2);
          if (inp.pressed.shoot && inp.released.shoot) {
            this.charging = false;
            this.power = 0.2;
            this.stage = 'RUNUP';
            this.stageT = 0;
            break;
          }
          const cl = inp.keys.has('KeyQ') || inp.down.lob || inp.pressed.lob || inp.pressed.pass;
          const cr = inp.keys.has('KeyE') || inp.down.sprint || inp.pressed.sprint || inp.pressed.tackle;
          if (cl !== cr) {
            const tapped = inp.pressed.lob || inp.pressed.sprint || inp.pressed.pass || inp.pressed.tackle;
            this.curve = clamp(this.curve + (cr ? 1 : -1) * Math.max(dt * 1.8, tapped ? 0.14 : 0), -1, 1);
          }
          const holding = inp.down.shoot || inp.down.switch;
          if (holding) {
            this.charging = true;
            this.power = clamp(Math.max(inp.holdTime.shoot, inp.holdTime.switch) / 1.1, 0.02, 1);
          } else if (this.charging) {
            this.charging = false;
            this.stage = 'RUNUP';
            this.stageT = 0;
          }
        }
        break;
      case 'RUNUP':
        this.kicker.moveDir.copy(this.dirU).setLength(0.85);
        if (this.stageT > 0.4) {
          this.kicker.moveDir.set(0, 0, 0);
          this.launch();
        }
        break;
      case 'FLIGHT': {
        if (this.jumpAt > 0 && this.time >= this.jumpAt) {
          this.jumpAt = -1;
          this.jumpUntil = this.time + 0.55;
          for (let i = 0; i < this.wallN; i++) this.wall[i].setAction('CELEBRATE', 0.55);
        }
        if (!this.dive.started && this.dive.at > 0 && this.time >= this.dive.at) this.startDive();
        this.wallCollide();
        this.keeperCheck();
        const inGoal = b.pos.x > p.L / 2 + 0.12 && Math.abs(b.pos.z) < gw - 0.02 && b.pos.y < p.goalH - 0.05;
        if (inGoal && !this.flags.saved) this.resolve('goal');
        else if (this.flags.blocked && this.time - this.flags.blockedAt > 0.9) this.resolve('blocked');
        else if (this.flags.saved && (b.speed < 1.5 || b.pos.x < this.spot.x + 1 || this.stageT > 2.2)) this.resolve('save');
        else if (b.pos.x > p.L / 2 + 0.3 || this.stageT > 3 || (this.stageT > 0.8 && b.speed < 0.6)) this.resolve(this.flags.post ? 'post' : 'miss');
        break;
      }
      case 'RESULT':
        if (this.stageT > 2.2) {
          if (this.attempts.length >= this.cfg.attempts) this.finish();
          else this.setup();
        }
        break;
      default:
        break;
    }

    // actors
    this.kicker.step(dt, 0.8, false);
    if (this.stage !== 'RUNUP') this.kicker.vel.multiplyScalar(0.5);
    for (let i = 0; i < this.wall.length; i++) {
      this.wall[i].moveDir.set(0, 0, 0);
      this.wall[i].step(dt, 1, false);
      this.wall[i].vel.set(0, 0, 0);
      this.wall[i].animate(dt);
    }
    const gk = this.keeper;
    gk.moveDir.set(0, 0, 0);
    const zBefore = gk.pos.z;
    gk.step(dt, 1, false);
    gk.vel.set(0, 0, 0);
    gk.pos.x = p.L / 2 - 0.35;
    if (this.dive.started) {
      const t = clamp((this.time - this.dive.t0) / 0.45, 0, 1);
      gk.pos.z = this.dive.fromZ + (this.dive.toZ - this.dive.fromZ) * (1 - Math.pow(1 - t, 2));
    } else gk.pos.z = this.stage === 'AIM' || this.stage === 'INTRO' ? Math.sin(this.time * 2.2) * 0.4 : zBefore;
    this.kicker.animate(dt);
    gk.animate(dt);
    b.step(dt, p);

    // aim reticle + trajectory preview
    const aiming = this.stage === 'AIM' || this.stage === 'INTRO';
    this.reticle.visible = this.reticleDot.visible = aiming;
    const { ty, tz } = this.target();
    this.reticle.position.set(p.L / 2 - 0.05, ty, tz);
    this.reticleDot.position.set(p.L / 2 - 0.06, ty, tz);
    this.reticle.scale.setScalar(1 + (this.charging ? this.power * 0.5 : 0) + Math.sin(this.time * 6) * 0.05);
    this.trail.visible = this.stage === 'AIM';
    if (this.stage === 'AIM') this.updatePreview();
  }

  private updatePreview() {
    const b = this.ball;
    const { ty, tz } = this.target();
    const sol = this.solve(new Vector3(b.pos.x, b.pos.y, b.pos.z), ty, tz, 17 + 14 * Math.max(0.5, this.power || 0.72), this.curve);
    const pts = sol.sim.path;
    this.blockedPreview = false;
    for (const q of pts) {
      const rx = q.x - this.wallCenter.x;
      const rz = q.z - this.wallCenter.z;
      const along = rx * this.dirU.x + rz * this.dirU.z;
      const lateral = rx * this.perp.x + rz * this.perp.z;
      if (Math.abs(along) < 0.6 && Math.abs(lateral) < (this.wallN * 0.72) / 2 + 0.25 && q.y < 2.0) this.blockedPreview = true;
    }
    const n = Math.min(40, pts.length);
    for (let i = 0; i < 40; i++) {
      const q = pts[Math.min(i, n - 1)] ?? b.pos;
      this.trailPos[i * 3] = q.x;
      this.trailPos[i * 3 + 1] = q.y;
      this.trailPos[i * 3 + 2] = q.z;
    }
    (this.trail.geometry.attributes.position as BufferAttribute).needsUpdate = true;
    (this.trail.material as PointsMaterial).color.set(this.blockedPreview ? '#ff5a5a' : '#ffffff');
  }

  private resolve(kind: 'goal' | 'save' | 'blocked' | 'post' | 'miss') {
    if (this.flags.resolved) return;
    this.flags.resolved = true;
    this.attempts.push(kind === 'goal' ? 'goal' : 'miss');
    if (kind === 'goal') {
      this.goals++;
      this.justScored = true;
      audio.play('goal', 0.8);
      this.say('GOAL!', 2);
      this.kicker.setAction('CELEBRATE', 2);
    } else {
      audio.play('groan');
      this.say(kind === 'save' ? 'SAVED!' : kind === 'blocked' ? 'BLOCKED BY THE WALL' : kind === 'post' ? 'OFF THE POST!' : 'MISSED!', 2);
      if (kind === 'save') this.keeper.setAction('CELEBRATE', 1.4);
    }
    this.stage = 'RESULT';
    this.stageT = 0;
  }

  private finish() {
    if (this.done) return;
    this.done = true;
    this.stage = 'DONE';
    const total = this.cfg.attempts;
    this.result = {
      homeScore: this.goals, awayScore: total, winner: this.goals * 2 >= total ? 0 : 1, pens: false,
      shots: [total, total], shotsOn: [this.goals, this.goals], possession: [50, 50], scorers: [],
    };
    audio.play('whistleLong');
    audio.play(this.goals * 2 >= total ? 'cheer' : 'groan');
    this.say(`${this.goals} / ${total}`, 3);
    setTimeout(() => this.onFinish?.(this.result!), 2400);
  }

  // ---------------------------------------------------------------- outputs
  camera(out: { pos: Vector3; look: Vector3; fov: number }) {
    const k = this.stage === 'FLIGHT' || this.stage === 'RESULT' ? 1 : 0;
    const back = 8.8 - k * 3.6;
    out.pos.set(this.spot.x - this.dirU.x * back, 2.9 - k * 0.7 + this.dist * 0.02, this.spot.z - this.dirU.z * back);
    out.look.set(this.spot.x + this.dirU.x * this.dist * 0.85, 1.2, this.spot.z + this.dirU.z * this.dist * 0.85);
    out.fov = 52 - k * 4;
  }

  hud(): HudState & { fk: FkHud } {
    const a = this.cfg.home;
    const bT = this.cfg.away;
    const aiming = this.stage === 'AIM';
    return {
      mode: 'freekick', homeName: a.name, awayName: bT.name, homeShort: a.short, awayShort: bT.short,
      homeColor: this.cfg.homeKit.primary, awayColor: bT.primary, homeScore: this.goals, awayScore: this.attempts.length,
      clock: `${this.attempts.length}/${this.cfg.attempts}`, half: 'FREE KICK CHALLENGE', phase: this.stage,
      banner: this.messageT > 0 ? { text: this.message, sub: '', kind: this.message.startsWith('GOAL') ? 'goal' : 'info' } : null,
      stamina: 100, shootCharge: this.charging ? this.power : 0, passCharge: 0,
      playerName: this.kicker.def.name, playerNumber: this.kicker.def.number, playerPos: 'TAKER',
      tactic: 'BALANCED', difficulty: this.cfg.difficulty, extra: [],
      hint: aiming ? 'WASD aim · Q / E curve the ball · hold SPACE or LMB to charge · release to shoot' : '', countdown: 0,
      fk: {
        attempts: this.attempts, total: this.cfg.attempts, goals: this.goals, stage: this.stage, power: this.charging ? this.power : 0, curve: this.curve,
        aimU: this.aimU, aimV: this.aimV, dist: Math.round(this.dist), wall: this.wallN, blockedPreview: this.blockedPreview && aiming,
      },
    };
  }
}
