import { CircleGeometry, Group, Mesh, MeshBasicMaterial, RingGeometry, Vector3, type Scene } from 'three';
import { DIFFICULTY, getRoster, makePitch, teamPattern, type Difficulty, type PitchSpec, type TeamDef } from './config';
import { Ball, GRAVITY } from './ball';
import { Footballer } from './entities';
import { audio } from './audio';
import { contrastColor, gkColor, hairColorFor, type KitSpec } from './models';
import type { Input } from './input';
import type { Custom, Settings } from './save';
import type { HudState, MatchResult } from './match';

export interface PenHud {
  home: string[];
  away: string[];
  round: number;
  shooterTeam: 0 | 1;
  role: 'shoot' | 'keep';
  power: number;
  aimU: number;
  aimV: number;
  stage: string;
  message: string;
  sudden: boolean;
  diveUsed: boolean;
}

export interface PenaltyConfig {
  home: TeamDef;
  away: TeamDef;
  homeKit: { primary: string; secondary: string; pattern?: number };
  difficulty: Difficulty;
  custom: Custom;
  level: number;
  settings: Settings;
}

type Stage = 'INTRO' | 'AIM' | 'RUNUP' | 'FLIGHT' | 'RESULT' | 'DONE';
const rand = Math.random;
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const gauss = () => rand() + rand() + rand() - 1.5;
const SKINS = ['#f6d3b3', '#e8b48a', '#c98e62', '#a46a43', '#7a4a2d', '#4d2e1c'];

export class PenaltyGame {
  readonly pitch: PitchSpec;
  readonly ball = new Ball();
  readonly group = new Group();
  stage: Stage = 'INTRO';
  stageT = 0;
  time = 0;
  kicker: 0 | 1 = 0;
  kicks: [string[], string[]] = [[], []];
  score: [number, number] = [0, 0];
  aimU = 0;
  aimV = 0.45;
  power = 0;
  charging = false;
  message = '';
  messageT = 0;
  onFinish: ((r: MatchResult) => void) | null = null;
  result: MatchResult | null = null;
  shotFlash = 0;

  private shooters: Footballer[] = [];
  private keepers: Footballer[] = [];
  private reticle: Mesh;
  private reticleDot: Mesh;
  private aiPlan: { u: number; v: number; power: number; at: number } | null = null;
  private dive = { started: false, t0: 0, fromZ: 0, toZ: 0, height: 0.5, at: -1, wantSide: 0 };
  private flags = { saved: false, post: false, resolved: false, keeperTried: false };
  private humanKeeps = false;
  private done = false;
  private tmp = new Vector3();

  constructor(private cfg: PenaltyConfig, scene: Scene, shadows: boolean) {
    this.pitch = makePitch(3);
    scene.add(this.group);
    this.group.add(this.ball.mesh, this.ball.shadow);
    this.ball.onEvent = (e, s) => {
      if (e === 'post') {
        this.flags.post = true;
        audio.play('post', 0.6 + s);
      } else if (e === 'net') audio.play('net', s);
      else if (e === 'bounce') audio.play('bounce', s);
    };
    const kits: { primary: string; secondary: string; pattern?: number }[] = [cfg.homeKit, cfg.away.primary === cfg.homeKit.primary ? { primary: cfg.away.secondary, secondary: cfg.away.primary } : { primary: cfg.away.primary, secondary: cfg.away.secondary }];
    const defs = [cfg.home, cfg.away];
    const gks = [gkColor([kits[0].primary, kits[1].primary]), gkColor([kits[1].primary, kits[0].primary])];
    if (gks[0] === gks[1]) gks[1] = gks[0] === '#2bf08a' ? '#ff7a1a' : '#2bf08a';
    for (let t = 0; t < 2; t++) {
      const roster = getRoster(defs[t]);
      const fw = roster.filter((p) => p.pos === 'FWD')[0];
      const gkDef = roster.find((p) => p.pos === 'GK')!;
      let sd = fw;
      if (t === 0) {
        const c = cfg.custom;
        const b = Math.min(12, cfg.level * 0.9) + defs[0].attack - 6;
        const s = (v: number) => clamp(Math.round(b + v), 40, 99);
        sd = { id: 'custom', name: c.name || 'ROOKIE', number: c.number, pos: 'FWD', archetype: 'Finisher', hair: c.hair, skin: c.skin, stats: { speed: s(2), acceleration: s(2), shooting: s(6), passing: s(0), dribbling: s(2), defending: s(-10), physical: s(0), stamina: s(4), ballControl: s(2) } };
      }
      const boots = t === 0 ? ({ black: '#15171c', white: '#f1f3f6', orange: '#ff7a1a', lime: '#b6ff2e', gold: '#f4c430', pink: '#ff3d9a' } as Record<string, string>)[cfg.custom.boots] ?? '#15171c' : '#15171c';
      const kit = (pd: typeof fw, gk: boolean): KitSpec => ({
        primary: gk ? gks[t] : kits[t].primary, secondary: gk ? contrastColor(gks[t]) : kits[t].secondary, shorts: gk ? '#1a1d24' : kits[t].secondary,
        socks: gk ? '#1a1d24' : kits[t].primary, boots: gk ? '#15171c' : boots, skin: SKINS[pd.skin % 6], hairColor: hairColorFor(pd.number + pd.skin), hair: pd.hair, number: pd.number,
        pattern: gk ? 0 : t === 0 ? cfg.homeKit.pattern ?? 0 : kits[1].primary === cfg.away.primary ? teamPattern(cfg.away.id) : 0,
        seed: 1 + (pd.number % 6),
        gloves: gk ? '#f4f6fa' : undefined,
      });
      const shooter = new Footballer(sd, t as 0 | 1, 1, kit(sd, false), shadows);
      const keeper = new Footballer(gkDef, t as 0 | 1, 0, kit(gkDef, true), shadows);
      this.shooters.push(shooter);
      this.keepers.push(keeper);
      this.group.add(shooter.group, keeper.group);
    }
    this.reticle = new Mesh(new RingGeometry(0.28, 0.36, 24), new MeshBasicMaterial({ color: '#ffe14d', transparent: true, opacity: 0.95, depthTest: false }));
    this.reticleDot = new Mesh(new CircleGeometry(0.06, 10), new MeshBasicMaterial({ color: '#ffffff', depthTest: false }));
    this.reticle.renderOrder = 10;
    this.reticleDot.renderOrder = 10;
    this.reticle.rotation.y = -Math.PI / 2;
    this.reticleDot.rotation.y = -Math.PI / 2;
    this.group.add(this.reticle, this.reticleDot);
    this.setupKick();
    this.setMessage('PENALTY SHOOTOUT', 2);
  }

  get spotX() {
    return this.pitch.L / 2 - this.pitch.spotD;
  }
  private setMessage(m: string, t = 1.8) {
    this.message = m;
    this.messageT = t;
  }

  dispose() {
    this.onFinish = null;
    this.shooters.forEach((p) => p.dispose());
    this.keepers.forEach((p) => p.dispose());
    this.group.traverse((o) => {
      const m = o as Mesh;
      if (m.userData?.shared) return; // blob shadows share module-level resources
      if (m.isMesh) {
        m.geometry?.dispose();
        const mat = m.material;
        if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
        else mat?.dispose();
      }
    });
    this.group.removeFromParent();
  }

  private setupKick() {
    const p = this.pitch;
    this.humanKeeps = this.kicker === 1;
    for (let t = 0; t < 2; t++) {
      const isShooter = t === this.kicker;
      this.shooters[t].group.visible = isShooter;
      this.keepers[t].group.visible = !isShooter;
    }
    const sh = this.shooters[this.kicker];
    const gk = this.keepers[1 - this.kicker];
    sh.place(this.spotX - 1.8, -0.6, Math.PI / 2);
    gk.place(p.L / 2 - 0.15, 0, -Math.PI / 2);
    gk.isUser = false;
    this.ball.reset(this.spotX, 0);
    this.aimU = 0;
    this.aimV = 0.45;
    this.power = 0;
    this.charging = false;
    this.aiPlan = null;
    this.dive = { started: false, t0: 0, fromZ: 0, toZ: 0, height: 0.5, at: -1, wantSide: 0 };
    this.flags = { saved: false, post: false, resolved: false, keeperTried: false };
    this.stage = 'AIM';
    this.stageT = 0;
  }

  private taken(t: number) {
    return this.kicks[t].length;
  }
  private checkDone(): boolean {
    const h = this.taken(0);
    const a = this.taken(1);
    const [sh, sa] = this.score;
    if (h <= 5 && a <= 5 && (h < 5 || a < 5)) {
      if (sh > sa + (5 - a)) return true;
      if (sa > sh + (5 - h)) return true;
      return false;
    }
    return h === a && h >= 5 && sh !== sa;
  }

  // ---------------------------------------------------------------- shot
  private launch(u: number, v: number, power: number, shooter: Footballer, err: number) {
    const p = this.pitch;
    const b = this.ball;
    const dx = p.L / 2 - b.pos.x;
    const tz = (u + gauss() * err) * (p.goalW / 2);
    const ty = Math.max(0.1, (v + gauss() * err * 0.8) * p.goalH);
    const speed = 14 + 16 * power;
    const T = dx / (speed * 0.97);
    b.vel.set(dx / T, (ty - b.r + 0.5 * GRAVITY * T * T) / T, tz / T);
    b.spin.set(0, gauss() * 2, 0);
    b.shotId++;
    b.lastKickTeam = shooter.team;
    b.owner = null;
    shooter.setAction('KICK', 0.45, power);
    shooter.kickCooldown = 1;
    audio.play('kick', 0.7 + power * 0.5);
    this.shotFlash = 1;
    this.stage = 'FLIGHT';
    this.stageT = 0;
    // AI keeper plan
    const gk = this.keepers[1 - this.kicker];
    if (!this.humanKeeps) return;
    void gk;
  }

  private startDive(gk: Footballer, targetZ: number, height: number) {
    if (this.dive.started) return;
    this.dive.started = true;
    this.dive.t0 = this.time;
    this.dive.fromZ = gk.pos.z;
    this.dive.toZ = targetZ;
    this.dive.height = height;
    const dirZ = Math.sign(targetZ - gk.pos.z) || 0;
    gk.diveDir.set(0, 0, dirZ || 1);
    gk.diveHeight = clamp(height / 1.9, 0, 1);
    if (Math.abs(targetZ - gk.pos.z) > 0.4) gk.setAction('SAVE', 1.0);
    else gk.setAction('SAVE', 0.7);
  }

  private keeperInput(inp: Input, gk: Footballer) {
    if (this.dive.started) return;
    const sx = inp.pressed.diveLeft ? -1 : inp.pressed.diveRight ? 1 : Math.abs(inp.moveX) > 0.5 ? Math.sign(inp.moveX) : 0;
    const hv = inp.down.diveHigh || inp.pressed.diveHigh || inp.moveY > 0.5 ? 1.7 : inp.down.diveLow || inp.pressed.diveLow || inp.moveY < -0.5 ? 0.45 : 1.0;
    if (sx !== 0 || inp.pressed.switch || inp.pressed.shoot) {
      // the camera looks from behind the goal, so screen-right is world -z
      this.startDive(gk, -sx * (this.pitch.goalW / 2 - 0.3), hv);
    }
  }

  cancelCharge() {
    this.charging = false;
    if (this.stage === 'AIM') this.power = 0;
  }

  // ---------------------------------------------------------------- update
  update(dt: number, inp: Input | null) {
    dt = Math.min(dt, 0.05);
    this.time += dt;
    this.stageT += dt;
    this.shotFlash = Math.max(0, this.shotFlash - dt * 2);
    if (this.messageT > 0) this.messageT -= dt;
    const D = DIFFICULTY[this.cfg.difficulty];
    const sh = this.shooters[this.kicker];
    const gk = this.keepers[1 - this.kicker];
    const p = this.pitch;
    const b = this.ball;

    switch (this.stage) {
      case 'INTRO':
        break;
      case 'AIM': {
        if (!this.humanKeeps) {
          // human shooting
          if (inp) {
            this.aimU = clamp(this.aimU + inp.moveX * dt * 1.25, -1.2, 1.2);
            this.aimV = clamp(this.aimV + inp.moveY * dt * 0.9, 0.08, 1.15);
            if (inp.pressed.shoot && inp.released.shoot) {
              this.charging = false;
              this.power = 0.2;
              this.aiPlan = { u: this.aimU, v: this.aimV, power: this.power, at: 0 };
              this.stage = 'RUNUP';
              this.stageT = 0;
              break;
            }
            const holding = inp.down.shoot || inp.down.switch || inp.down.pass;
            if (holding) {
              this.charging = true;
              this.power = clamp(Math.max(inp.holdTime.shoot, inp.holdTime.switch, inp.holdTime.pass) / 1.1, 0.02, 1);
            } else if (this.charging) {
              this.charging = false;
              this.stage = 'RUNUP';
              this.stageT = 0;
              this.aiPlan = { u: this.aimU, v: this.aimV, power: Math.max(0.2, this.power), at: 0 };
            }
          }
        } else if (this.stageT > 1.5 + rand() * 0.6) {
          // AI shooter chooses corner
          const side = rand() < 0.5 ? -1 : 1;
          const high = rand() < 0.45;
          this.aiPlan = { u: side * (0.45 + rand() * 0.45), v: high ? 0.6 + rand() * 0.4 : 0.12 + rand() * 0.25, power: 0.6 + rand() * 0.35, at: 0 };
          this.stage = 'RUNUP';
          this.stageT = 0;
        }
        break;
      }
      case 'RUNUP': {
        // shooter steps to the ball
        sh.moveDir.set(1, 0, 0.3);
        sh.sprint = false;
        sh.moveDir.setLength(0.8);
        if (this.stageT > 0.42 && this.aiPlan) {
          sh.moveDir.set(0, 0, 0);
          const plan = this.aiPlan;
          const st = sh.def.stats;
          let err = (0.06 + (1 - st.shooting / 100) * 0.3) * (1.5 - 1 * (1 - Math.min(1, Math.abs(plan.power - 0.8) / 0.8)));
          if (this.humanKeeps) err *= D.shotError * 0.9;
          let v = plan.v;
          if (plan.power > 0.96) {
            err *= 2.2;
            v += 0.5;
          }
          this.launch(plan.u, v, plan.power, sh, err);
          // AI keeper decision
          if (!this.humanKeeps) {
            const read = rand() < 0.28 * D.awareness + 0.08;
            const side = read ? Math.sign(plan.u) || 1 : rand() < 0.5 ? -1 : 1;
            const center = !read && rand() < 0.15;
            const h = read ? clamp(plan.v * p.goalH, 0.3, 1.9) : rand() < 0.5 ? 0.5 : 1.6;
            this.dive.at = this.time + D.gkReaction * 0.5;
            this.dive.wantSide = center ? 0 : side;
            this.dive.height = h;
          }
        }
        // human keeper may start diving as soon as the run-up begins (a guess before the kick)
        if (this.humanKeeps && inp) this.keeperInput(inp, gk);
        break;
      }
      case 'FLIGHT': {
        if (this.flags.resolved) break;
        // keeper dive triggers
        if (this.humanKeeps && inp) this.keeperInput(inp, gk);
        if (!this.humanKeeps && !this.dive.started && this.dive.at > 0 && this.time >= this.dive.at) {
          this.startDive(gk, this.dive.wantSide * (p.goalW / 2 - 0.4) * 0.95, this.dive.height);
        }
        this.keeperCheck(gk, D.gkSave);
        // result detection
        const outX = b.pos.x > p.L / 2 + 0.12;
        if (outX && Math.abs(b.pos.z) < p.goalW / 2 - 0.02 && b.pos.y < p.goalH - 0.05 && !this.flags.saved) {
          this.resolve('goal');
        } else if (this.flags.saved && (b.speed < 1.5 || b.pos.x < this.spotX + 1 || this.stageT > 2.2)) {
          this.resolve('save');
        } else if (b.pos.x > p.L / 2 + 0.3 || this.stageT > 2.8 || (this.stageT > 0.6 && b.speed < 0.6)) {
          this.resolve(this.flags.post ? 'post' : 'miss');
        }
        break;
      }
      case 'RESULT':
        if (this.stageT > 2.1) {
          if (this.checkDone()) {
            this.finishGame();
          } else {
            this.kicker = (1 - this.kicker) as 0 | 1;
            this.setupKick();
          }
        }
        break;
      case 'DONE':
        break;
    }
    if (this.stage === 'INTRO' && this.stageT > 1.2) {
      this.stage = 'AIM';
      this.stageT = 0;
    }

    // update actors
    for (const f of [sh, gk]) {
      if (f === gk) {
        const vel0 = gk.pos.z;
        gk.moveDir.set(0, 0, 0);
        gk.step(dt, 1, false);
        if (this.dive.started) {
          const t = clamp((this.time - this.dive.t0) / 0.42, 0, 1);
          const e = 1 - Math.pow(1 - t, 2);
          gk.pos.z = this.dive.fromZ + (this.dive.toZ - this.dive.fromZ) * e;
          gk.pos.x = p.L / 2 - 0.15;
        } else {
          gk.pos.x = p.L / 2 - 0.15;
          gk.pos.z = vel0;
          // keeper sways a little on the line
          if (this.stage === 'AIM' || this.stage === 'INTRO') gk.pos.z = Math.sin(this.time * 2) * 0.35;
        }
        gk.vel.set(0, 0, 0);
      } else {
        sh.step(dt, 0.8, false);
        if (this.stage !== 'RUNUP') sh.vel.multiplyScalar(0.5);
      }
    }
    sh.animate(dt);
    gk.animate(dt);
    b.step(dt, p);

    // reticle (only while the human shoots)
    const showRet = !this.humanKeeps && (this.stage === 'AIM' || this.stage === 'INTRO');
    this.reticle.visible = this.reticleDot.visible = showRet;
    const ry = this.aimV * p.goalH;
    const rz = this.aimU * (p.goalW / 2);
    this.reticle.position.set(p.L / 2 - 0.05, ry, rz);
    this.reticleDot.position.set(p.L / 2 - 0.06, ry, rz);
    const s = 1 + (this.charging ? this.power * 0.5 : 0) + Math.sin(this.time * 6) * 0.05;
    this.reticle.scale.setScalar(s);
  }

  private keeperCheck(gk: Footballer, saveSkill: number) {
    const b = this.ball;
    if (this.flags.saved || this.flags.keeperTried) return;
    const p = this.pitch;
    const dive = this.dive.started;
    const hy = dive ? clamp(this.dive.height, 0.4, 2.0) : 1.05;
    // hands extend in front of the keeper along the goal line
    const dz = b.pos.z - gk.pos.z;
    const dy = b.pos.y - hy;
    const dx = b.pos.x - gk.pos.x;
    const reach = (dive ? 1.15 : 0.85) + (gk.def.stats.defending - 70) * 0.004;
    const d = Math.hypot(dx * 0.6, dy, dz);
    if (d < reach && b.pos.x > p.L / 2 - 1.4 && b.vel.x > 0) {
      this.flags.keeperTried = true;
      const human = this.humanKeeps;
      const quality = human ? 0.92 : clamp(0.72 * saveSkill + 0.15, 0.2, 0.95);
      const speedPenalty = clamp((b.speed - 18) / 40, 0, 0.35);
      if (rand() < quality - speedPenalty) {
        this.flags.saved = true;
        const catchIt = b.speed < 21 && rand() < 0.55;
        if (catchIt) {
          b.vel.set(0, 0, 0);
          b.pos.x = gk.pos.x - 0.3;
        } else {
          b.vel.set(-b.speed * 0.35 - 2, 2 + rand() * 2.5, Math.sign(dz || 1) * (3 + rand() * 4));
        }
        if (gk.action !== 'SAVE') gk.setAction('SAVE', 0.7);
        audio.play('save');
      } else {
        // got a hand to it but not enough
        b.vel.multiplyScalar(0.85);
        audio.play('save', 0.5);
      }
    }
  }

  private resolve(kind: 'goal' | 'save' | 'miss' | 'post') {
    if (this.flags.resolved) return;
    this.flags.resolved = true;
    const t = this.kicker;
    this.kicks[t].push(kind === 'goal' ? 'goal' : 'miss');
    if (kind === 'goal') {
      this.score[t]++;
      audio.play('goal', 0.8);
      this.setMessage('GOAL!', 2);
      this.shooters[t].setAction('CELEBRATE', 2);
    } else {
      audio.play('groan');
      this.setMessage(kind === 'save' ? 'SAVED!' : kind === 'post' ? 'OFF THE WOODWORK!' : 'MISSED!', 2);
      if (kind === 'save') this.keepers[1 - t].setAction('CELEBRATE', 1.6);
    }
    this.stage = 'RESULT';
    this.stageT = 0;
  }

  private finishGame() {
    if (this.done) return;
    this.done = true;
    this.stage = 'DONE';
    const w: 0 | 1 = this.score[0] > this.score[1] ? 0 : 1;
    this.result = {
      homeScore: this.score[0], awayScore: this.score[1], winner: w, pens: true,
      shots: [this.kicks[0].length, this.kicks[1].length], shotsOn: [this.score[0], this.score[1]], possession: [50, 50], scorers: [],
    };
    audio.play('whistleLong');
    audio.play(w === 0 ? 'cheer' : 'groan');
    this.setMessage(w === 0 ? 'YOU WIN THE SHOOTOUT!' : 'YOU LOSE THE SHOOTOUT', 3);
    setTimeout(() => this.onFinish?.(this.result!), 2600);
  }

  // ---------------------------------------------------------------- outputs
  camera(out: { pos: Vector3; look: Vector3; fov: number }) {
    const p = this.pitch;
    if (!this.humanKeeps) {
      const k = this.stage === 'FLIGHT' || this.stage === 'RESULT' ? 1 : 0;
      out.pos.set(this.spotX - 9.5 + k * 3, 2.7 - k * 0.5, 0);
      out.look.set(p.L / 2, 1.1, 0);
      out.fov = 46;
    } else {
      out.pos.set(p.L / 2 + 3.5, 1.9, 0);
      out.look.set(this.spotX - 2, 1.0, 0);
      out.fov = 52;
    }
    void this.tmp;
  }

  hud(): HudState & { pen: PenHud } {
    const a = this.cfg.home;
    const bT = this.cfg.away;
    const role = this.humanKeeps ? 'keep' : 'shoot';
    const taken = Math.max(this.taken(0), this.taken(1));
    const sudden = taken >= 5 && this.taken(0) >= 5 && this.taken(1) >= 5;
    let hint = '';
    if (this.stage === 'AIM') hint = role === 'shoot' ? 'WASD: aim · Hold SPACE / LMB: charge power (sweet spot 70–90%) · release to shoot' : 'Shooter is preparing… Dive with A / D (W high, S low) once they run up!';
    else if (this.stage === 'RUNUP' || this.stage === 'FLIGHT') hint = role === 'keep' ? 'DIVE! A / D to pick a side (W high · S low)' : '';
    return {
      mode: 'penalty',
      homeName: a.name, awayName: bT.name, homeShort: a.short, awayShort: bT.short,
      homeColor: this.cfg.homeKit.primary, awayColor: bT.primary, homeScore: this.score[0], awayScore: this.score[1],
      clock: '', half: 'PENALTY SHOOTOUT', phase: this.stage,
      banner: this.messageT > 0 ? { text: this.message, sub: '', kind: this.message.startsWith('GOAL') ? 'goal' : 'info' } : null,
      stamina: 100, shootCharge: this.charging ? this.power : 0, passCharge: 0,
      playerName: this.shooters[0].def.name, playerNumber: this.shooters[0].def.number, playerPos: role === 'shoot' ? 'TAKER' : 'KEEPER',
      tactic: 'BALANCED', difficulty: this.cfg.difficulty, extra: [], hint, countdown: 0,
      pen: {
        home: this.kicks[0], away: this.kicks[1], round: Math.floor(Math.min(this.taken(0), this.taken(1))) + 1,
        shooterTeam: this.kicker, role, power: this.charging ? this.power : 0, aimU: this.aimU, aimV: this.aimV, stage: this.stage, message: this.message, sudden,
        diveUsed: this.dive.started,
      },
    };
  }
}
