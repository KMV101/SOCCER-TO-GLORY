// CrazyGames HTML5 SDK v3 wrapper. Every call is guarded – the game runs identically
// when the SDK is missing (local dev, other portals, offline).

import { audio } from './audio';

interface CGSDK {
  init(): Promise<void>;
  environment?: string;
  game: {
    gameplayStart(): void;
    gameplayStop(): void;
    loadingStart?(): void;
    loadingStop?(): void;
    happytime?(): void;
    settings?: { muteAudio?: boolean };
    addSettingsChangeListener?(l: (s: { muteAudio?: boolean }) => void): void;
  };
  ad?: {
    requestAd(type: 'midgame' | 'rewarded', cb: { adStarted?: () => void; adFinished?: () => void; adError?: (e: unknown) => void }): void;
  };
}
declare global {
  interface Window {
    CrazyGames?: { SDK: CGSDK };
  }
}

const SDK_URL = 'https://sdk.crazygames.com/crazygames-sdk-v3.js';

let sdk: CGSDK | null = null;
let ready = false;
let initializing = false;
let playing = false;
let adRunning = false;
let onAdState: ((running: boolean) => void) | null = null;

const sdkMuted = () => !!sdk?.game.settings?.muteAudio;
function applyMute() {
  audio.setExternalMute(sdkMuted() || adRunning);
}

export const crazy = {
  /** true when the SDK loaded AND we are running inside CrazyGames (ads/etc. available) */
  get active() {
    return ready && !!sdk && sdk.environment !== 'disabled';
  },

  setAdListener(fn: (running: boolean) => void) {
    onAdState = fn;
  },

  async init(): Promise<void> {
    if (ready || initializing) return;
    initializing = true;
    try {
      if (!window.CrazyGames) {
        await new Promise<void>((res, rej) => {
          const s = document.createElement('script');
          s.src = SDK_URL;
          s.async = true;
          s.onload = () => res();
          s.onerror = () => rej(new Error('sdk load failed'));
          document.head.appendChild(s);
          setTimeout(() => rej(new Error('sdk timeout')), 4000);
        });
      }
      sdk = window.CrazyGames?.SDK ?? null;
      if (!sdk) return;
      await Promise.race([sdk.init(), new Promise((_, rej) => setTimeout(() => rej(new Error('init timeout')), 4000))]);
      ready = true;
      sdk.game.addSettingsChangeListener?.(() => applyMute());
      applyMute();
      try {
        sdk.game.loadingStop?.();
      } catch {
        /* ignore */
      }
      // A fast player may have started a match while the external script loaded.
      if (playing) sdk.game.gameplayStart();
    } catch {
      sdk = null;
      ready = false;
    } finally {
      initializing = false;
    }
  },

  loadingStart() {
    try {
      window.CrazyGames?.SDK.game.loadingStart?.();
    } catch {
      /* ignore */
    }
  },

  gameplay(on: boolean) {
    if (on === playing) return;
    playing = on;
    if (!ready || !sdk) return;
    try {
      if (on) sdk.game.gameplayStart();
      else sdk.game.gameplayStop();
    } catch {
      /* ignore */
    }
  },

  happy() {
    try {
      if (ready) sdk?.game.happytime?.();
    } catch {
      /* ignore */
    }
  },

  /** Show an ad. Resolves when it finished / failed / is unavailable. `true` = rewarded ad completed. */
  ad(type: 'midgame' | 'rewarded'): Promise<boolean> {
    return new Promise((resolve) => {
      if (!ready || !sdk?.ad || sdk.environment === 'disabled') {
        resolve(false);
        return;
      }
      let done = false;
      const end = (ok: boolean) => {
        if (done) return;
        done = true;
        adRunning = false;
        applyMute();
        onAdState?.(false);
        resolve(ok);
      };
      try {
        sdk.ad.requestAd(type, {
          adStarted: () => {
            adRunning = true;
            applyMute();
            onAdState?.(true);
          },
          adFinished: () => end(true),
          adError: () => end(false),
        });
      } catch {
        end(false);
      }
      setTimeout(() => end(false), 90000);
    });
  },
};
