import {
  AdditiveBlending, BackSide, BoxGeometry, BufferAttribute, BufferGeometry, CanvasTexture, CapsuleGeometry, Color, ConeGeometry, CylinderGeometry, DirectionalLight, DoubleSide,
  Fog, Group, HemisphereLight, InstancedMesh, Mesh, MeshBasicMaterial, MeshLambertMaterial, MeshStandardMaterial, PlaneGeometry,
  Points, PointsMaterial, RepeatWrapping, Scene, SphereGeometry, SRGBColorSpace, Sprite, SpriteMaterial, Texture, Vector3, type Material, type Object3D,
} from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { AD_BRANDS, type PitchSpec, type StadiumTheme } from './config';
import type { Quality } from './save';

export interface QualityCfg {
  shadows: boolean; shadowSize: number; shadowRange: number; crowdSpacing: number; crowdAnim: boolean; heads: boolean; beams: boolean;
  pixelCap: number; stars: number; antialias: boolean; fx: number;
}
export const QUALITY: Record<Quality, QualityCfg> = {
  LOW: { shadows: false, shadowSize: 512, shadowRange: 20, crowdSpacing: 2.4, crowdAnim: false, heads: false, beams: false, pixelCap: 1.25, stars: 0, antialias: false, fx: 90 },
  MEDIUM: { shadows: true, shadowSize: 1024, shadowRange: 24, crowdSpacing: 1.5, crowdAnim: true, heads: true, beams: true, pixelCap: 1.5, stars: 120, antialias: true, fx: 200 },
  HIGH: { shadows: true, shadowSize: 2048, shadowRange: 30, crowdSpacing: 1.05, crowdAnim: true, heads: true, beams: true, pixelCap: 2, stars: 260, antialias: true, fx: 320 },
};

function canvas(w: number, h: number) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  return { c, x: c.getContext('2d')! };
}

const STEP_D = 1.0;
const STEP_H = 0.6;
const ROWS = 11;
const SKINS = ['#f6d3b3', '#e8b48a', '#c98e62', '#a46a43', '#7a4a2d', '#4d2e1c'];

// ------------------------------------------------------------------ pooled particles
export class Fx {
  readonly points: Points;
  private n: number;
  private pos: Float32Array;
  private col: Float32Array;
  private vel: Float32Array;
  private life: Float32Array;
  private grav: Float32Array;
  private cursor = 0;
  private tmp = new Color();

  constructor(scene: Scene, n: number) {
    this.n = n;
    this.pos = new Float32Array(n * 3).fill(0);
    this.col = new Float32Array(n * 3).fill(1);
    this.vel = new Float32Array(n * 3);
    this.life = new Float32Array(n);
    this.grav = new Float32Array(n);
    for (let i = 0; i < n; i++) this.pos[i * 3 + 1] = -100;
    const g = new BufferGeometry();
    g.setAttribute('position', new BufferAttribute(this.pos, 3));
    g.setAttribute('color', new BufferAttribute(this.col, 3));
    const m = new PointsMaterial({ size: 0.24, vertexColors: true, transparent: true, opacity: 0.95, depthWrite: false });
    this.points = new Points(g, m);
    this.points.frustumCulled = false;
    scene.add(this.points);
  }

  emit(x: number, y: number, z: number, count: number, colors: string[], hSpeed: number, vSpeed: number, life: number, grav: number) {
    for (let k = 0; k < count; k++) {
      const i = this.cursor;
      this.cursor = (this.cursor + 1) % this.n;
      const a = Math.random() * Math.PI * 2;
      const s = hSpeed * (0.3 + Math.random() * 0.7);
      this.pos[i * 3] = x + (Math.random() - 0.5) * 0.4;
      this.pos[i * 3 + 1] = y;
      this.pos[i * 3 + 2] = z + (Math.random() - 0.5) * 0.4;
      this.vel[i * 3] = Math.cos(a) * s;
      this.vel[i * 3 + 1] = vSpeed * (0.4 + Math.random() * 0.6);
      this.vel[i * 3 + 2] = Math.sin(a) * s;
      this.life[i] = life * (0.6 + Math.random() * 0.4);
      this.grav[i] = grav;
      this.tmp.set(colors[Math.floor(Math.random() * colors.length)]);
      this.col[i * 3] = this.tmp.r;
      this.col[i * 3 + 1] = this.tmp.g;
      this.col[i * 3 + 2] = this.tmp.b;
    }
    (this.points.geometry.attributes.color as BufferAttribute).needsUpdate = true;
  }

  update(dt: number) {
    let any = false;
    for (let i = 0; i < this.n; i++) {
      if (this.life[i] <= 0) continue;
      any = true;
      this.life[i] -= dt;
      if (this.life[i] <= 0) {
        this.pos[i * 3 + 1] = -100;
        continue;
      }
      this.vel[i * 3 + 1] -= this.grav[i] * dt;
      const drag = Math.max(0, 1 - 1.6 * dt);
      this.vel[i * 3] *= drag;
      this.vel[i * 3 + 2] *= drag;
      this.pos[i * 3] += this.vel[i * 3] * dt;
      this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt;
      this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      if (this.pos[i * 3 + 1] < 0.03) {
        this.pos[i * 3 + 1] = 0.03;
        this.vel[i * 3 + 1] = 0;
      }
    }
    if (any) (this.points.geometry.attributes.position as BufferAttribute).needsUpdate = true;
  }

  dispose() {
    this.points.geometry.dispose();
    (this.points.material as Material).dispose();
    this.points.removeFromParent();
  }
}

// ------------------------------------------------------------------ world
export class World {
  scene = new Scene();
  sun: DirectionalLight;
  hemi: HemisphereLight;
  fx: Fx;
  excite = 0;
  readonly menuGroup = new Group();
  private owned: { dispose(): void }[] = [];
  private crowd: InstancedMesh | null = null;
  private heads: InstancedMesh | null = null;
  private crowdBase = new Float32Array(0);
  private crowdPhase = new Float32Array(0);
  private crowdN = 0;
  private crowdAcc = 0;
  private crowdT = 0;
  private boardTex: Texture[] = [];
  private netMat: MeshBasicMaterial | null = null;
  private glowTex: CanvasTexture | null = null;
  private scoreboard: CanvasTexture | null = null;
  private scoreboardKey = '';
  private teamColors = ['#d5dd75', '#e89061'];
  private staff: { root: Group; left: Group; right: Group; phase: number; coach: boolean }[] = [];
  private staffShirts: MeshLambertMaterial[] = [];
  private flags: { cloth: Mesh; phase: number; team: number }[] = [];
  private flagMats: MeshBasicMaterial[] = [];

  constructor(readonly theme: StadiumTheme, readonly pitch: PitchSpec, readonly q: QualityCfg) {
    const s = this.scene;
    s.fog = new Fog(theme.fog, 120, 380);
    this.hemi = new HemisphereLight(new Color(theme.ambient), new Color('#2a3b2a'), 1.05);
    s.add(this.hemi);
    this.sun = new DirectionalLight(new Color(theme.sun), theme.light * 1.7);
    this.sun.position.set(-18, 42, 24);
    s.add(this.sun, this.sun.target);
    const fill = new DirectionalLight(new Color(theme.accent), 0.35);
    fill.position.set(26, 16, -22);
    s.add(fill);
    if (q.shadows) {
      this.sun.castShadow = true;
      const sc = this.sun.shadow.camera;
      sc.left = -q.shadowRange;
      sc.right = q.shadowRange;
      sc.top = q.shadowRange;
      sc.bottom = -q.shadowRange;
      sc.near = 5;
      sc.far = 120;
      this.sun.shadow.mapSize.set(q.shadowSize, q.shadowSize);
      this.sun.shadow.bias = -0.0004;
      this.sun.shadow.normalBias = 0.04;
      this.sun.shadow.radius = 3;
    }
    s.add(this.menuGroup);
    this.buildSky();
    this.buildSkyline();
    this.buildGround();
    this.buildPitch();
    this.buildGoal(1);
    this.buildGoal(-1);
    if (theme.street) {
      this.buildStreetCourt();
      this.buildFloodlights();
    } else {
      this.buildCornerFlags();
      this.buildBoards();
      this.buildStands();
      this.buildFloodlights();
      this.buildTunnel();
      this.buildMatchdayDetails();
    }
    this.fx = new Fx(s, q.fx);
  }

  private own<T extends { dispose(): void }>(o: T): T {
    this.owned.push(o);
    return o;
  }

  private glow(): CanvasTexture {
    if (this.glowTex) return this.glowTex;
    const { c, x } = canvas(64, 64);
    const g = x.createRadialGradient(32, 32, 0, 32, 32, 32);
    g.addColorStop(0, 'rgba(255,248,225,1)');
    g.addColorStop(0.25, 'rgba(255,240,200,0.4)');
    g.addColorStop(1, 'rgba(255,240,200,0)');
    x.fillStyle = g;
    x.fillRect(0, 0, 64, 64);
    this.glowTex = this.own(new CanvasTexture(c));
    return this.glowTex;
  }

  // ---------------------------------------------------------------- effects
  effect(kind: 'kick' | 'tackle' | 'goal', x: number, z: number, power: number, colors?: string[]) {
    const dust = ['#d9e8c2', '#b7cf94', '#9fba7b'];
    if (kind === 'kick') this.fx.emit(x, 0.12, z, Math.round(4 + power * 8), dust, 1.2 + power * 2.2, 1.6, 0.55, 7);
    else if (kind === 'tackle') this.fx.emit(x, 0.12, z, Math.round(10 + power * 12), dust, 2.8, 2.2, 0.7, 7);
    else {
      const cols = [...(colors ?? []), '#ffffff', '#ffe14d', this.theme.accent];
      const sgn = x >= 0 ? 1 : -1;
      this.fx.emit(x - sgn * 2, 2.4, z, 70, cols, 6, 9, 2.8, 5);
      this.fx.emit(x - sgn * 9, 4, z - 6, 40, cols, 5, 8, 2.6, 5);
      this.fx.emit(x - sgn * 9, 4, z + 6, 40, cols, 5, 8, 2.6, 5);
    }
  }

  // ---------------------------------------------------------------- sky
  private buildSky() {
    const t = this.theme;
    const { c, x } = canvas(4, 256);
    const g = x.createLinearGradient(0, 0, 0, 256);
    g.addColorStop(0, t.skyTop);
    g.addColorStop(0.3, t.skyMid);
    g.addColorStop(0.5, t.skyHorizon);
    g.addColorStop(0.53, t.fog);
    g.addColorStop(1, '#0b0f18');
    x.fillStyle = g;
    x.fillRect(0, 0, 4, 256);
    const tex = this.own(new CanvasTexture(c));
    tex.colorSpace = SRGBColorSpace;
    const mat = this.own(new MeshBasicMaterial({ map: tex, side: BackSide, fog: false, depthWrite: false }));
    const sky = new Mesh(this.own(new SphereGeometry(560, 16, 12)), mat);
    sky.renderOrder = -10;
    this.scene.add(sky);
    // moon / sun disc
    const sm = this.own(new SpriteMaterial({ map: this.glow(), color: new Color(t.id === 'sunset' ? '#ffb070' : t.id === 'frost' ? '#ffffff' : '#bcd4ff'), blending: AdditiveBlending, depthWrite: false, fog: false, transparent: true }));
    const sun = new Sprite(sm);
    sun.scale.set(t.id === 'neon' ? 90 : 150, t.id === 'neon' ? 90 : 150, 1);
    sun.position.set(-260, t.id === 'sunset' ? 70 : 190, -380);
    this.scene.add(sun);
    if (this.q.stars > 0 && t.id === 'neon') {
      const n = this.q.stars;
      const pos = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2;
        const e = 0.2 + Math.random() * 1.2;
        pos[i * 3] = Math.cos(a) * Math.cos(e) * 500;
        pos[i * 3 + 1] = Math.sin(e) * 500;
        pos[i * 3 + 2] = Math.sin(a) * Math.cos(e) * 500;
      }
      const geo = this.own(new BufferGeometry());
      geo.setAttribute('position', new BufferAttribute(pos, 3));
      const pm = this.own(new PointsMaterial({ color: 0xffffff, size: 1.8, sizeAttenuation: false, fog: false, transparent: true, opacity: 0.85 }));
      this.scene.add(new Points(geo, pm));
    }
  }

  private buildSkyline() {
    const t = this.theme;
    const day = t.id === 'frost';
    const { c, x } = canvas(64, 64);
    x.fillStyle = day ? '#8b9db6' : '#1b2238';
    x.fillRect(0, 0, 64, 64);
    for (let i = 0; i < 8; i++) for (let j = 0; j < 8; j++) {
      const lit = Math.random() < (day ? 0.2 : 0.5);
      x.fillStyle = lit ? (day ? '#dcebf8' : '#ffd98a') : day ? '#7389a6' : '#2a3354';
      x.fillRect(i * 8 + 2, j * 8 + 2, 4, 5);
    }
    const tex = this.own(new CanvasTexture(c));
    tex.wrapS = tex.wrapT = RepeatWrapping;
    tex.colorSpace = SRGBColorSpace;
    const tint = new Color(t.fog);
    const geos: BufferGeometry[] = [];
    const N = 64;
    const R0 = Math.max(this.pitch.boardX, this.pitch.boardZ) + 80;
    for (let i = 0; i < N; i++) {
      const a = (i / N) * Math.PI * 2 + (Math.random() - 0.5) * 0.08;
      const r = R0 + Math.random() * 80;
      const w = 10 + Math.random() * 18;
      const h = 22 + Math.random() * 70;
      const d = 10 + Math.random() * 18;
      const g = new BoxGeometry(w, h, d);
      const uv = g.attributes.uv;
      for (let k = 0; k < uv.count; k++) uv.setXY(k, uv.getX(k) * (w / 7), uv.getY(k) * (h / 7));
      g.translate(0, h / 2, 0);
      g.rotateY(a + Math.PI / 2);
      g.translate(Math.cos(a) * r, 0, Math.sin(a) * r);
      const shade = 0.55 + Math.random() * 0.45;
      const cc = new Color(1, 1, 1).lerp(tint, 0.25).multiplyScalar(shade);
      const arr = new Float32Array(g.attributes.position.count * 3);
      for (let k = 0; k < g.attributes.position.count; k++) {
        arr[k * 3] = cc.r;
        arr[k * 3 + 1] = cc.g;
        arr[k * 3 + 2] = cc.b;
      }
      g.setAttribute('color', new BufferAttribute(arr, 3));
      geos.push(g);
    }
    const merged = mergeGeometries(geos, false) as BufferGeometry;
    geos.forEach((g) => g.dispose());
    this.own(merged);
    const mat = this.own(new MeshBasicMaterial({ map: tex, vertexColors: true }));
    this.scene.add(new Mesh(merged, mat));
  }

  // ---------------------------------------------------------------- ground + pitch
  private buildGround() {
    const m = this.own(new MeshLambertMaterial({ color: '#262c38' }));
    const g = new Mesh(this.own(new PlaneGeometry(900, 900).rotateX(-Math.PI / 2)), m);
    g.position.y = -0.03;
    g.receiveShadow = this.q.shadows;
    this.scene.add(g);
  }

  private buildPitch() {
    const p = this.pitch;
    const t = this.theme;
    const pw = p.boardX * 2;
    const ph = p.boardZ * 2;
    const ppm = Math.min(30, 2048 / pw);
    const { c, x } = canvas(Math.round(pw * ppm), Math.round(ph * ppm));
    const W = c.width;
    const H = c.height;
    // mowing stripes with soft light gradient inside every stripe
    const nStripes = Math.max(8, Math.round(p.L / 5) * 2);
    const stripeW = W / nStripes;
    for (let i = 0; i < nStripes; i++) {
      const g = x.createLinearGradient(i * stripeW, 0, (i + 1) * stripeW, 0);
      const base = i % 2 ? t.grassA : t.grassB;
      g.addColorStop(0, base);
      g.addColorStop(0.5, i % 2 ? t.grassB : t.grassA);
      g.addColorStop(1, base);
      x.fillStyle = g;
      x.fillRect(i * stripeW, 0, stripeW + 1, H);
    }
    // grass blades
    x.lineWidth = 1;
    for (let i = 0; i < 14000; i++) {
      x.strokeStyle = Math.random() > 0.5 ? 'rgba(255,255,255,0.045)' : 'rgba(0,20,0,0.07)';
      const bx = Math.random() * W;
      const by = Math.random() * H;
      x.beginPath();
      x.moveTo(bx, by);
      x.lineTo(bx + (Math.random() - 0.5) * 3, by + 2 + Math.random() * 5);
      x.stroke();
    }
    const X = (m: number) => (m + pw / 2) * ppm;
    const Z = (m: number) => (m + ph / 2) * ppm;
    // worn patches
    for (const [wx, wz, wr] of [[0, 0, 5], [-p.L / 2 + p.spotD, 0, 4], [p.L / 2 - p.spotD, 0, 4], [-p.L / 2 + 2, 0, 5], [p.L / 2 - 2, 0, 5]] as [number, number, number][]) {
      const g = x.createRadialGradient(X(wx), Z(wz), 0, X(wx), Z(wz), wr * ppm);
      g.addColorStop(0, 'rgba(120,95,50,0.2)');
      g.addColorStop(1, 'rgba(120,95,50,0)');
      x.fillStyle = g;
      x.fillRect(X(wx) - wr * ppm, Z(wz) - wr * ppm, wr * 2 * ppm, wr * 2 * ppm);
    }
    // edge vignette
    const vg = x.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.max(W, H) * 0.65);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, 'rgba(0,15,0,0.28)');
    x.fillStyle = vg;
    x.fillRect(0, 0, W, H);

    if (p.street) {
      // asphalt court with painted zones (overpaints the grass look)
      const ag = x.createLinearGradient(0, 0, W, H);
      ag.addColorStop(0, t.grassA);
      ag.addColorStop(1, t.grassB);
      x.fillStyle = ag;
      x.fillRect(0, 0, W, H);
      for (let i = 0; i < 9000; i++) {
        x.fillStyle = Math.random() > 0.5 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.13)';
        x.fillRect(Math.random() * W, Math.random() * H, 1 + Math.random() * 2, 1 + Math.random() * 2);
      }
      x.strokeStyle = 'rgba(0,0,0,0.25)';
      x.lineWidth = 1.2;
      for (let i = 0; i < 26; i++) {
        let cx = Math.random() * W;
        let cy = Math.random() * H;
        x.beginPath();
        x.moveTo(cx, cy);
        for (let k = 0; k < 5; k++) {
          cx += (Math.random() - 0.5) * 60;
          cy += (Math.random() - 0.5) * 60;
          x.lineTo(cx, cy);
        }
        x.stroke();
      }
      x.fillStyle = 'rgba(255,79,216,0.16)';
      x.fillRect(X(-p.L / 2), Z(-p.W / 2), p.L * ppm, p.W * ppm);
      x.fillStyle = 'rgba(45,212,255,0.22)';
      x.fillRect(X(-p.L / 2), Z(-p.boxW / 2), p.boxD * ppm, p.boxW * ppm);
      x.fillRect(X(p.L / 2 - p.boxD), Z(-p.boxW / 2), p.boxD * ppm, p.boxW * ppm);
      x.fillStyle = 'rgba(255,225,77,0.16)';
      x.beginPath();
      x.arc(X(0), Z(0), p.circleR * ppm, 0, Math.PI * 2);
      x.fill();
    }

    x.strokeStyle = 'rgba(255,255,255,0.93)';
    x.lineWidth = Math.max(2, 0.13 * ppm);
    x.lineCap = 'square';
    const hl = p.L / 2;
    const hw = p.W / 2;
    x.strokeRect(X(-hl), Z(-hw), p.L * ppm, p.W * ppm);
    x.beginPath();
    x.moveTo(X(0), Z(-hw));
    x.lineTo(X(0), Z(hw));
    x.stroke();
    x.beginPath();
    x.arc(X(0), Z(0), p.circleR * ppm, 0, Math.PI * 2);
    x.stroke();
    x.fillStyle = 'rgba(255,255,255,0.95)';
    x.beginPath();
    x.arc(X(0), Z(0), 0.2 * ppm, 0, Math.PI * 2);
    x.fill();
    for (const side of [-1, 1]) {
      const gx = side * hl;
      x.strokeRect(side < 0 ? X(gx) : X(gx - p.boxD), Z(-p.boxW / 2), p.boxD * ppm, p.boxW * ppm);
      x.strokeRect(side < 0 ? X(gx) : X(gx - p.sixD), Z(-p.sixW / 2), p.sixD * ppm, p.sixW * ppm);
      const sx = gx - side * p.spotD;
      x.beginPath();
      x.arc(X(sx), Z(0), 0.2 * ppm, 0, Math.PI * 2);
      x.fill();
      const a = Math.acos(Math.min(1, (p.boxD - p.spotD) / p.circleR));
      x.beginPath();
      if (side < 0) x.arc(X(sx), Z(0), p.circleR * ppm, -a, a);
      else x.arc(X(sx), Z(0), p.circleR * ppm, Math.PI - a, Math.PI + a);
      x.stroke();
    }
    const cr = 1.0 * ppm;
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      x.beginPath();
      const start = sx < 0 ? (sz < 0 ? 0 : -Math.PI / 2) : sz < 0 ? Math.PI / 2 : Math.PI;
      x.arc(X(sx * hl), Z(sz * hw), cr, start, start + Math.PI / 2);
      x.stroke();
    }
    const tex = this.own(new CanvasTexture(c));
    tex.colorSpace = SRGBColorSpace;
    tex.anisotropy = 8;
    const mat = this.own(new MeshLambertMaterial({ map: tex }));
    const mesh = new Mesh(this.own(new PlaneGeometry(pw, ph).rotateX(-Math.PI / 2)), mat);
    mesh.receiveShadow = this.q.shadows;
    this.scene.add(mesh);
  }

  // ---------------------------------------------------------------- street cage (Street Soccer)
  private buildStreetCourt() {
    const p = this.pitch;
    const t = this.theme;
    const bx = p.boardX;
    const bz = p.boardZ;
    const accent = new Color(t.accent);

    // graffiti brick texture
    const { c, x } = canvas(1024, 256);
    x.fillStyle = '#1c1628';
    x.fillRect(0, 0, 1024, 256);
    x.strokeStyle = 'rgba(255,255,255,0.05)';
    x.lineWidth = 2;
    for (let r = 0; r < 16; r++) for (let k = 0; k < 17; k++) x.strokeRect(k * 64 - (r % 2) * 32, r * 16, 64, 16);
    const words = ['KICK', 'STREET', 'SKILLZ', '3D', 'GOAL', 'CAGE', 'NO RULES', 'FLAIR', 'CREW'];
    const cols = [t.accent, '#2dd4ff', '#b6ff2e', '#ffe14d', '#ff7a1a', '#ffffff'];
    for (let i = 0; i < 10; i++) {
      x.save();
      x.translate(40 + Math.random() * 860, 80 + Math.random() * 130);
      x.rotate((Math.random() - 0.5) * 0.35);
      x.font = `900 ${Math.floor(46 + Math.random() * 54)}px Arial Black, Arial, sans-serif`;
      x.fillStyle = cols[i % cols.length];
      x.shadowColor = cols[i % cols.length];
      x.shadowBlur = 14;
      x.fillText(words[i % words.length], 0, 0);
      x.restore();
    }
    const wallTex = this.own(new CanvasTexture(c));
    wallTex.wrapS = RepeatWrapping;
    wallTex.colorSpace = SRGBColorSpace;
    wallTex.anisotropy = 4;

    // chain-link fence texture
    const f = canvas(64, 64);
    f.x.strokeStyle = 'rgba(205,215,235,0.7)';
    f.x.lineWidth = 2.2;
    f.x.beginPath();
    f.x.moveTo(0, 0);
    f.x.lineTo(64, 64);
    f.x.moveTo(64, 0);
    f.x.lineTo(0, 64);
    f.x.stroke();
    const fenceTex = this.own(new CanvasTexture(f.c));
    fenceTex.wrapS = fenceTex.wrapT = RepeatWrapping;
    fenceTex.colorSpace = SRGBColorSpace;

    const kickMat = this.own(new MeshLambertMaterial({ color: '#241a33' }));
    const stripMat = this.own(new MeshBasicMaterial({ color: accent }));
    const postMat = this.own(new MeshLambertMaterial({ color: '#8d96a8' }));
    const FH = 5.2;

    const side = (len: number, px: number, pz: number, ry: number) => {
      const g = new Group();
      g.position.set(px, 0, pz);
      g.rotation.y = ry;
      // kick board
      const board = new Mesh(this.own(new BoxGeometry(len, 1.1, 0.3)), kickMat);
      board.position.y = 0.55;
      const strip = new Mesh(this.own(new BoxGeometry(len, 0.1, 0.34)), stripMat);
      strip.position.y = 1.12;
      // fence mesh
      const ft = fenceTex.clone();
      ft.needsUpdate = true;
      ft.repeat.set(len / 1.1, FH / 1.1);
      this.own(ft);
      const fence = new Mesh(
        this.own(new PlaneGeometry(len, FH)),
        this.own(new MeshBasicMaterial({ map: ft, transparent: true, alphaTest: 0.12, side: DoubleSide, depthWrite: false, fog: false })),
      );
      fence.position.y = 1.1 + FH / 2;
      const rail = new Mesh(this.own(new BoxGeometry(len, 0.12, 0.12)), postMat);
      rail.position.y = 1.1 + FH;
      g.add(board, strip, fence, rail);
      // posts every ~3 m
      const n = Math.max(2, Math.round(len / 3));
      const postGeo = this.own(new BoxGeometry(0.14, FH + 1.1, 0.14));
      for (let i = 0; i <= n; i++) {
        const post = new Mesh(postGeo, postMat);
        post.position.set(-len / 2 + (i / n) * len, (FH + 1.1) / 2, 0);
        g.add(post);
      }
      this.scene.add(g);
    };
    side(bx * 2, 0, bz, Math.PI);
    side(bx * 2, 0, -bz, 0);
    side(bz * 2, bx, 0, -Math.PI / 2);
    side(bz * 2, -bx, 0, Math.PI / 2);

    // tall graffiti walls ringing the court + neon strips
    const ox = bx + 8;
    const oz = bz + 8;
    const wall = (len: number, px: number, pz: number, ry: number) => {
      const wt = wallTex.clone();
      wt.needsUpdate = true;
      wt.repeat.set(len / 22, 1);
      this.own(wt);
      const m = new Mesh(this.own(new PlaneGeometry(len, 13)), this.own(new MeshLambertMaterial({ map: wt })));
      m.position.set(px, 6.5, pz);
      m.rotation.y = ry;
      const neon = new Mesh(this.own(new BoxGeometry(len, 0.25, 0.25)), stripMat);
      neon.position.set(px, 12.6, pz);
      neon.rotation.y = ry;
      this.scene.add(m, neon);
    };
    wall(ox * 2 + 16, 0, oz, Math.PI);
    wall(ox * 2 + 16, 0, -oz, 0);
    wall(oz * 2 + 16, ox, 0, -Math.PI / 2);
    wall(oz * 2 + 16, -ox, 0, Math.PI / 2);
  }

  private buildCornerFlags() {
    const p = this.pitch;
    const pole = this.own(new CylinderGeometry(0.025, 0.025, 1.6, 6));
    const poleMat = this.own(new MeshBasicMaterial({ color: '#f3f4f8' }));
    const flagGeo = this.own(new PlaneGeometry(0.5, 0.34));
    const flagMat = this.own(new MeshBasicMaterial({ color: new Color(this.theme.accent), side: DoubleSide }));
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      const m = new Mesh(pole, poleMat);
      m.position.set(sx * p.L / 2, 0.8, sz * p.W / 2);
      const f = new Mesh(flagGeo, flagMat);
      f.position.set(sx * p.L / 2 - sx * 0.25, 1.43, sz * p.W / 2);
      f.rotation.y = Math.PI / 2;
      this.scene.add(m, f);
    }
  }

  // ---------------------------------------------------------------- goals
  private netPlane(w: number, h: number): BufferGeometry {
    const g = new PlaneGeometry(w, h);
    const uv = g.attributes.uv;
    for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * w * 3, uv.getY(i) * h * 3);
    return this.own(g);
  }
  private buildGoal(side: 1 | -1) {
    const p = this.pitch;
    const grp = new Group();
    grp.position.x = side * p.L / 2;
    grp.rotation.y = side > 0 ? 0 : Math.PI;
    const metal = this.own(new MeshStandardMaterial({ color: '#f4f6fa', roughness: 0.3, metalness: 0.25 }));
    const r = 0.07;
    const postGeo = this.own(new CylinderGeometry(r, r, p.goalH, 10));
    for (const z of [-1, 1]) {
      const post = new Mesh(postGeo, metal);
      post.position.set(0, p.goalH / 2, z * p.goalW / 2);
      post.castShadow = this.q.shadows;
      grp.add(post);
      const back = new Mesh(this.own(new CylinderGeometry(0.04, 0.04, p.goalH, 6)), metal);
      back.position.set(p.goalD, p.goalH / 2, z * p.goalW / 2);
      grp.add(back);
      const top = new Mesh(this.own(new CylinderGeometry(0.035, 0.035, p.goalD, 6).rotateZ(Math.PI / 2)), metal);
      top.position.set(p.goalD / 2, p.goalH, z * p.goalW / 2);
      grp.add(top);
    }
    const bar = new Mesh(this.own(new CylinderGeometry(r, r, p.goalW + r * 2, 10).rotateX(Math.PI / 2)), metal);
    bar.position.set(0, p.goalH, 0);
    bar.castShadow = this.q.shadows;
    grp.add(bar);
    const backBar = new Mesh(this.own(new CylinderGeometry(0.04, 0.04, p.goalW, 6).rotateX(Math.PI / 2)), metal);
    backBar.position.set(p.goalD, p.goalH, 0);
    grp.add(backBar);

    if (!this.netMat) {
      const { c, x } = canvas(64, 64);
      x.strokeStyle = 'rgba(255,255,255,0.9)';
      x.lineWidth = 3;
      x.strokeRect(0, 0, 64, 64);
      const t = this.own(new CanvasTexture(c));
      t.wrapS = t.wrapT = RepeatWrapping;
      t.colorSpace = SRGBColorSpace;
      this.netMat = this.own(new MeshBasicMaterial({ map: t, transparent: true, opacity: 0.6, side: DoubleSide, depthWrite: false, alphaTest: 0.05 }));
    }
    const nm = this.netMat;
    const backNet = new Mesh(this.netPlane(p.goalW, p.goalH), nm);
    backNet.rotation.y = Math.PI / 2;
    backNet.position.set(p.goalD, p.goalH / 2, 0);
    grp.add(backNet);
    for (const z of [-1, 1]) {
      const sidePlane = new Mesh(this.netPlane(p.goalD, p.goalH), nm);
      sidePlane.position.set(p.goalD / 2, p.goalH / 2, z * p.goalW / 2);
      grp.add(sidePlane);
    }
    const roof = new Mesh(this.netPlane(p.goalD, p.goalW), nm);
    roof.rotation.x = Math.PI / 2;
    roof.position.set(p.goalD / 2, p.goalH, 0);
    grp.add(roof);
    this.scene.add(grp);
  }

  // ---------------------------------------------------------------- ad boards (LED, scrolling)
  private buildBoards() {
    const p = this.pitch;
    const { c, x } = canvas(1536, 128);
    const cols = ['#e11d48', '#0ea5e9', '#f59e0b', '#22c55e', '#a855f7', '#f97316', '#14b8a6', '#eab308'];
    const names = [...AD_BRANDS];
    for (let i = 0; i < 4; i++) {
      const bi = (i * 2) % names.length;
      const g = x.createLinearGradient(0, 0, 0, 128);
      g.addColorStop(0, '#171c28');
      g.addColorStop(1, '#0a0d14');
      x.fillStyle = g;
      x.fillRect(i * 384, 0, 384, 128);
      x.fillStyle = cols[bi];
      x.fillRect(i * 384, 0, 384, 12);
      x.fillRect(i * 384, 116, 384, 12);
      x.fillStyle = '#ffffff';
      x.font = '900 58px Arial Black, Arial, sans-serif';
      x.textAlign = 'center';
      x.textBaseline = 'middle';
      x.shadowColor = cols[bi];
      x.shadowBlur = 14;
      x.fillText(names[bi], i * 384 + 192, 66);
      x.shadowBlur = 0;
    }
    const tex = this.own(new CanvasTexture(c));
    tex.wrapS = RepeatWrapping;
    tex.colorSpace = SRGBColorSpace;
    tex.anisotropy = 4;
    const bodyMat = this.own(new MeshLambertMaterial({ color: '#171b24' }));
    const mk = (len: number, px: number, pz: number, ry: number) => {
      const t = tex.clone();
      t.needsUpdate = true;
      t.repeat.set(len / 12, 1);
      this.own(t);
      this.boardTex.push(t);
      const mat = this.own(new MeshBasicMaterial({ map: t }));
      const g = new Group();
      const body = new Mesh(this.own(new BoxGeometry(len, 1.05, 0.25)), bodyMat);
      body.position.y = 0.52;
      const face = new Mesh(this.own(new PlaneGeometry(len, 0.95)), mat);
      face.position.set(0, 0.55, 0.13);
      g.add(body, face);
      g.position.set(px, 0, pz);
      g.rotation.y = ry;
      this.scene.add(g);
    };
    const lenX = p.boardX * 2;
    const lenZ = p.boardZ * 2;
    mk(lenX, 0, p.boardZ, Math.PI);
    mk(lenX, 0, -p.boardZ, 0);
    mk(lenZ, p.boardX, 0, -Math.PI / 2);
    mk(lenZ, -p.boardX, 0, Math.PI / 2);
  }

  // ---------------------------------------------------------------- stands + roof + crowd
  private buildStands() {
    const p = this.pitch;
    const t = this.theme;
    const sideLen = p.boardX * 2 + 4;
    const endLen = p.boardZ * 2 + 2 * (ROWS * STEP_D + 1.5);
    const defs = [
      { len: sideLen, px: 0, pz: p.boardZ + 1.2, ry: 0, end: false },
      { len: sideLen, px: 0, pz: -(p.boardZ + 1.2), ry: Math.PI, end: false },
      { len: endLen, px: p.boardX + 1.2, pz: 0, ry: Math.PI / 2, end: true },
      { len: endLen, px: -(p.boardX + 1.2), pz: 0, ry: -Math.PI / 2, end: true },
    ];
    const cA = new Color(t.standA);
    const cB = new Color(t.standB);
    const accent = new Color(t.accent);
    const standMat = this.own(new MeshLambertMaterial({ vertexColors: true }));
    const accentMat = this.own(new MeshBasicMaterial({ color: accent }));
    const wallMat = this.own(new MeshLambertMaterial({ color: '#141824' }));
    const roofMat = this.own(new MeshLambertMaterial({ color: '#202638' }));

    const sp = this.q.crowdSpacing;
    const seats: number[] = [];
    const colored = (g: BufferGeometry, col: Color) => {
      const n = g.attributes.position.count;
      const a = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) {
        a[i * 3] = col.r;
        a[i * 3 + 1] = col.g;
        a[i * 3 + 2] = col.b;
      }
      g.setAttribute('color', new BufferAttribute(a, 3));
      return g;
    };

    for (const d of defs) {
      const grp = new Group();
      grp.position.set(d.px, 0, d.pz);
      grp.rotation.y = d.ry;
      const rowGeos: BufferGeometry[] = [];
      for (let i = 0; i < ROWS; i++) {
        const h = (i + 1) * STEP_H;
        const g = new BoxGeometry(d.len, h, STEP_D);
        g.translate(0, h / 2, i * STEP_D + STEP_D / 2);
        rowGeos.push(colored(g, i % 2 ? cA : cB));
      }
      const merged = mergeGeometries(rowGeos, false) as BufferGeometry;
      rowGeos.forEach((g) => g.dispose());
      this.own(merged);
      grp.add(new Mesh(merged, standMat));
      const wall = new Mesh(this.own(new BoxGeometry(d.len, 14, 0.6)), wallMat);
      wall.position.set(0, 7, ROWS * STEP_D + 0.5);
      const strip = new Mesh(this.own(new BoxGeometry(d.len, 0.35, 0.2)), accentMat);
      strip.position.set(0, 11.6, ROWS * STEP_D + 0.15);
      grp.add(wall, strip);
      const rail = new Mesh(this.own(new BoxGeometry(d.len, 0.12, 0.12)), accentMat);
      rail.position.set(0, 0.4, -0.1);
      grp.add(rail);
      // roof canopy with LED trim and pillars
      const roof = new Mesh(this.own(new BoxGeometry(d.len, 0.35, 7.5)), roofMat);
      roof.position.set(0, 9.3, ROWS * STEP_D - 3.4);
      roof.rotation.x = -0.1;
      const trim = new Mesh(this.own(new BoxGeometry(d.len, 0.14, 0.14)), accentMat);
      trim.position.set(0, 9.05, ROWS * STEP_D - 7.15);
      grp.add(roof, trim);
      const pillarGeo = this.own(new BoxGeometry(0.5, 9.3, 0.5));
      const nPill = Math.max(2, Math.round(d.len / 16));
      for (let k = 0; k <= nPill; k++) {
        const pl = new Mesh(pillarGeo, roofMat);
        pl.position.set(-d.len / 2 + (k / nPill) * d.len, 4.65, ROWS * STEP_D + 0.0);
        grp.add(pl);
      }
      this.scene.add(grp);

      const cos = Math.cos(d.ry);
      const sin = Math.sin(d.ry);
      for (let i = 0; i < ROWS; i++) {
        const ly = (i + 1) * STEP_H + 0.34;
        const lz = i * STEP_D + STEP_D * 0.55;
        const off = (i % 2) * sp * 0.5;
        for (let lx = -d.len / 2 + 0.7 + off; lx < d.len / 2 - 0.7; lx += sp) {
          if (Math.random() < 0.08) continue;
          const jx = lx + (Math.random() - 0.5) * sp * 0.3;
          const wx = d.px + jx * cos + lz * sin;
          const wz = d.pz - jx * sin + lz * cos;
          if (d.end && Math.abs(wz) > p.boardZ + 0.6 && Math.abs(wx) < p.boardX + 2.4) continue; // hidden behind the side stand
          if (!d.end && d.pz < 0 && Math.abs(jx) < 3.3 && i < 6) continue; // tunnel mouth
          seats.push(wx, ly, wz);
        }
      }
    }

    const n = seats.length / 3;
    this.crowdN = n;
    this.crowdBase = new Float32Array(seats);
    this.crowdPhase = new Float32Array(n);
    const bodyParts: BufferGeometry[] = [
      new CapsuleGeometry(0.19, 0.26, 2, 6),
      new CylinderGeometry(0.065, 0.05, 0.44, 6).rotateZ(-0.32).translate(-0.22, -0.02, 0),
      new CylinderGeometry(0.065, 0.05, 0.44, 6).rotateZ(0.32).translate(0.22, -0.02, 0),
    ];
    const bodyGeo = this.own(mergeGeometries(bodyParts, false) as BufferGeometry);
    bodyParts.forEach((g) => g.dispose());
    const mat = this.own(new MeshLambertMaterial({ color: 0xffffff }));
    const im = new InstancedMesh(bodyGeo, mat, n);
    const hm = this.q.heads ? new InstancedMesh(this.own(new SphereGeometry(0.15, 7, 6)), this.own(new MeshLambertMaterial({ color: 0xffffff })), n) : null;
    const m = new Float32Array(16);
    m[0] = m[5] = m[10] = m[15] = 1;
    for (let i = 0; i < n; i++) {
      this.crowdPhase[i] = Math.random() * Math.PI * 2;
      m[12] = seats[i * 3];
      m[13] = seats[i * 3 + 1];
      m[14] = seats[i * 3 + 2];
      im.instanceMatrix.array.set(m, i * 16);
      if (hm) {
        m[13] = seats[i * 3 + 1] + 0.43;
        hm.instanceMatrix.array.set(m, i * 16);
      }
    }
    im.instanceMatrix.needsUpdate = true;
    im.frustumCulled = false;
    this.crowd = im;
    this.scene.add(im);
    if (hm) {
      hm.instanceMatrix.needsUpdate = true;
      hm.frustumCulled = false;
      this.heads = hm;
      this.scene.add(hm);
      const c = new Color();
      for (let i = 0; i < n; i++) {
        c.set(SKINS[Math.floor(Math.random() * SKINS.length)]);
        hm.setColorAt(i, c);
      }
      if (hm.instanceColor) hm.instanceColor.needsUpdate = true;
    }
    this.setCrowdColors(['#e53935', '#1e88e5']);
  }

  setCrowdColors(teamCols: string[]) {
    this.teamColors = teamCols.slice(0, 2);
    this.staffShirts.forEach((mat, i) => mat.color.set(this.teamColors[i % this.teamColors.length]));
    this.flagMats.forEach((mat, i) => mat.color.set(this.teamColors[this.flags[i]?.team ?? 0]));
    this.scoreboardKey = '';
    const im = this.crowd;
    if (!im) return;
    const neutral = ['#d8dbe3', '#8791a8', '#2f3646', '#c9a66b', '#e8e0d0', '#5d6b86'];
    const c = new Color();
    for (let i = 0; i < this.crowdN; i++) {
      const r = Math.random();
      const col = r < 0.6 ? teamCols[Math.floor(Math.random() * teamCols.length)] : neutral[Math.floor(Math.random() * neutral.length)];
      c.set(col);
      c.multiplyScalar(0.6 + Math.random() * 0.4);
      im.setColorAt(i, c);
    }
    if (im.instanceColor) im.instanceColor.needsUpdate = true;
  }

  cheer(amount = 1) {
    this.excite = Math.min(1.5, this.excite + amount);
  }

  // ---------------------------------------------------------------- floodlights + tunnel
  private buildFloodlights() {
    const p = this.pitch;
    const poleMat = this.own(new MeshLambertMaterial({ color: '#8d96a8' }));
    const { c, x } = canvas(64, 32);
    x.fillStyle = '#fff9e6';
    x.fillRect(0, 0, 64, 32);
    x.fillStyle = '#c9c2a0';
    for (let i = 0; i < 8; i++) for (let j = 0; j < 4; j++) {
      x.beginPath();
      x.arc(4 + i * 8, 4 + j * 8, 2.2, 0, Math.PI * 2);
      x.fill();
    }
    const lt = this.own(new CanvasTexture(c));
    lt.colorSpace = SRGBColorSpace;
    const lampMat = this.own(new MeshBasicMaterial({ map: lt }));
    const glowMat = this.own(new SpriteMaterial({ map: this.glow(), blending: AdditiveBlending, depthWrite: false, fog: false, transparent: true }));
    const poleGeo = this.own(new CylinderGeometry(0.35, 0.6, 32, 8));
    const lampGeo = this.own(new BoxGeometry(8, 3.8, 0.4));
    const beamH = 52;
    const beamGeo = this.own(new ConeGeometry(15, beamH, 20, 1, true).translate(0, -beamH / 2, 0).rotateX(-Math.PI / 2));
    const beamMat = this.own(new MeshBasicMaterial({ color: '#fff3d2', transparent: true, opacity: 0.045, blending: AdditiveBlending, depthWrite: false, side: DoubleSide, fog: false }));
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      const off = p.street ? 11 : 14;
      const px = sx * (p.boardX + off);
      const pz = sz * (p.boardZ + off);
      const pole = new Mesh(poleGeo, poleMat);
      pole.position.set(px, 16, pz);
      const lamp = new Mesh(lampGeo, lampMat);
      lamp.position.set(px, 33, pz);
      lamp.lookAt(0, 8, 0);
      const glow = new Sprite(glowMat);
      glow.scale.set(34, 34, 1);
      glow.position.set(px * 0.98, 33, pz * 0.98);
      this.scene.add(pole, lamp, glow);
      if (this.q.beams) {
        const beam = new Mesh(beamGeo, beamMat);
        beam.position.set(px * 0.98, 33, pz * 0.98);
        beam.lookAt(0, 0, 0);
        this.scene.add(beam);
      }
    }
  }

  private buildTunnel() {
    const p = this.pitch;
    const g = new Group();
    const dark = this.own(new MeshLambertMaterial({ color: '#0d1018' }));
    const frameMat = this.own(new MeshBasicMaterial({ color: new Color(this.theme.accent) }));
    const lit = this.own(new MeshBasicMaterial({ color: '#cfdcff' }));
    const box = new Mesh(this.own(new BoxGeometry(6.4, 3.9, 7.5)), dark);
    box.position.set(0, 1.95, 3.25);
    const inner = new Mesh(this.own(new PlaneGeometry(4.2, 2.9)), lit);
    inner.position.set(0, 1.6, -0.52);
    inner.rotation.y = Math.PI;
    const top = new Mesh(this.own(new BoxGeometry(6.8, 0.22, 0.3)), frameMat);
    top.position.set(0, 3.95, -0.55);
    const l = new Mesh(this.own(new BoxGeometry(0.22, 4.0, 0.3)), frameMat);
    l.position.set(-3.3, 2.0, -0.55);
    const r = l.clone();
    r.position.x = 3.3;
    g.add(box, inner, top, l, r);
    g.position.set(0, 0, -(p.boardZ + 1.2));
    g.rotation.y = Math.PI;
    this.scene.add(g);
  }

  /** A few readable human silhouettes make the touchline feel inhabited at little GPU cost. */
  private buildMatchdayDetails() {
    const p = this.pitch;
    const skinMats = SKINS.slice(1, 5).map((color) => this.own(new MeshLambertMaterial({ color })));
    const coat = this.own(new MeshLambertMaterial({ color: '#29322b' }));
    const pants = this.own(new MeshLambertMaterial({ color: '#1a211d' }));
    const hair = this.own(new MeshLambertMaterial({ color: '#1b1c1a' }));
    const dugout = this.own(new MeshLambertMaterial({ color: '#202923' }));
    const canopy = this.own(new MeshBasicMaterial({ color: '#c4d7c7', transparent: true, opacity: 0.22, side: DoubleSide, depthWrite: false }));
    const torsoG = this.own(new CylinderGeometry(0.16, 0.2, 0.64, 8));
    const headG = this.own(new SphereGeometry(0.15, 9, 7));
    const capG = this.own(new SphereGeometry(0.155, 9, 6, 0, Math.PI * 2, 0, Math.PI * 0.48));
    const limbG = this.own(new CylinderGeometry(0.065, 0.074, 0.68, 7));
    const armG = this.own(new CylinderGeometry(0.065, 0.055, 0.48, 7));
    const roofG = this.own(new BoxGeometry(5.4, 0.11, 1.8));
    const seatG = this.own(new BoxGeometry(4.8, 0.15, 0.65));
    const backG = this.own(new BoxGeometry(5.4, 2.15, 0.12));

    for (let team = 0; team < 2; team++) {
      const x = (team === 0 ? -1 : 1) * p.L * 0.23;
      const z = p.W / 2 + 1.0;
      const shirt = this.own(new MeshLambertMaterial({ color: this.teamColors[team] }));
      this.staffShirts.push(shirt);

      // Transparent dugout with bench and vertical back panel.
      const bench = new Mesh(seatG, dugout);
      bench.position.set(x, 0.43, z + 1.05);
      const roof = new Mesh(roofG, canopy);
      roof.position.set(x, 2.48, z + 1.05);
      const back = new Mesh(backG, canopy);
      back.position.set(x, 1.35, z + 1.94);
      this.scene.add(bench, roof, back);

      const makeStaff = (atX: number, atZ: number, coach: boolean, index: number) => {
        const root = new Group();
        root.position.set(atX, 0, atZ);
        root.rotation.y = Math.PI; // face the pitch from the near touchline
        const skin = skinMats[(team + index) % skinMats.length];
        const topMat = coach ? coat : shirt;
        const body = new Mesh(torsoG, topMat);
        body.position.y = 1.16;
        const head = new Mesh(headG, skin);
        head.position.y = 1.68;
        const cap = new Mesh(capG, hair);
        cap.position.y = 1.74;
        root.add(body, head, cap);
        for (const s of [-1, 1]) {
          const leg = new Mesh(limbG, pants);
          leg.position.set(s * 0.105, 0.36, 0);
          root.add(leg);
        }
        const arm = (side: number) => {
          const pivot = new Group();
          pivot.position.set(side * 0.225, 1.4, 0);
          const sleeve = new Mesh(armG, topMat);
          sleeve.position.y = -0.25;
          pivot.add(sleeve);
          root.add(pivot);
          return pivot;
        };
        const left = arm(-1);
        const right = arm(1);
        this.staff.push({ root, left, right, phase: index * 2 + team, coach });
        this.scene.add(root);
      };
      makeStaff(x, z - 0.08, true, 0);
      const reserves = this.q.crowdSpacing > 2 ? 1 : 2;
      for (let i = 0; i < reserves; i++) {
        makeStaff(x + (i - (reserves - 1) / 2) * 1.65, z + 1.1, false, i + 1);
      }
    }

    // Supporter banners in the far stand, rather than effects floating above the pitch.
    const flagG = this.own(new PlaneGeometry(1.05, 0.65));
    const poleG = this.own(new CylinderGeometry(0.025, 0.025, 1.35, 5));
    const poleMat = this.own(new MeshLambertMaterial({ color: '#b7b9a8' }));
    for (let i = 0; i < 6; i++) {
      const team = i % 2;
      const x = (i - 2.5) * (p.L / 8.2);
      const z = -(p.boardZ + 1.2 + 5.0);
      const y = 3.7;
      const pole = new Mesh(poleG, poleMat);
      pole.position.set(x, y, z);
      const mat = this.own(new MeshBasicMaterial({ color: this.teamColors[team], side: DoubleSide }));
      this.flagMats.push(mat);
      const cloth = new Mesh(flagG, mat);
      cloth.position.set(x + 0.52, y + 0.37, z);
      this.flags.push({ cloth, phase: i * 1.7, team });
      this.scene.add(pole, cloth);
    }

    // One small live screen facing the pitch; updated only when its displayed second changes.
    const { c } = canvas(512, 128);
    const tex = this.own(new CanvasTexture(c));
    tex.colorSpace = SRGBColorSpace;
    this.scoreboard = tex;
    const sbZ = -(p.boardZ + 1.2 + ROWS * STEP_D + 0.13);
    const frame = new Mesh(this.own(new BoxGeometry(14.3, 3.6, 0.35)), dugout);
    frame.position.set(0, 11.8, sbZ - 0.18);
    const screen = new Mesh(this.own(new PlaneGeometry(13.9, 3.16)), this.own(new MeshBasicMaterial({ map: tex, toneMapped: false })));
    screen.position.set(0, 11.8, sbZ + 0.04);
    this.scene.add(frame, screen);
    this.setScoreboard('HOME', 'AWAY', 0, 0, '00:00');
  }

  setScoreboard(home: string, away: string, h: number, a: number, clock: string) {
    if (!this.scoreboard) return;
    const key = `${home}|${away}|${h}|${a}|${clock}|${this.teamColors.join('|')}`;
    if (key === this.scoreboardKey) return;
    this.scoreboardKey = key;
    const c = this.scoreboard.image as HTMLCanvasElement;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#101714';
    ctx.fillRect(0, 0, 512, 128);
    ctx.fillStyle = this.teamColors[0];
    ctx.fillRect(0, 0, 10, 128);
    ctx.fillStyle = this.teamColors[1];
    ctx.fillRect(502, 0, 10, 128);
    ctx.fillStyle = '#b6bfae';
    ctx.font = '600 18px Barlow, Arial, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('SIDENET  /  MATCHDAY', 256, 25);
    ctx.font = '700 57px Barlow Condensed, Arial Narrow, sans-serif';
    ctx.fillStyle = '#f3f2e9';
    ctx.fillText(`${home.slice(0, 4)}  ${h} - ${a}  ${away.slice(0, 4)}`, 256, 88);
    ctx.fillStyle = '#d5dd75';
    ctx.font = '600 19px Barlow, Arial, sans-serif';
    ctx.fillText(clock, 256, 116);
    this.scoreboard.needsUpdate = true;
  }

  // ---------------------------------------------------------------- per-frame
  update(dt: number, focus: Vector3) {
    this.sun.position.set(focus.x - 18, 42, focus.z + 24);
    this.sun.target.position.set(focus.x, 0, focus.z);
    this.sun.target.updateMatrixWorld();
    this.excite = Math.max(0, this.excite - dt * 0.35);
    this.fx.update(dt);
    for (const t of this.boardTex) t.offset.x = (t.offset.x + dt * 0.015) % 1;
    this.crowdT += dt;
    for (const s of this.staff) {
      const wave = Math.sin(this.crowdT * (s.coach ? 2.1 : 1.3) + s.phase);
      const cheer = Math.min(1, this.excite);
      s.left.rotation.x = (s.coach ? -0.14 : 0.1) + wave * (0.12 + cheer * 0.26);
      s.right.rotation.x = -0.17 - wave * (0.16 + cheer * 0.38);
      s.root.rotation.z = wave * 0.018;
    }
    for (const flag of this.flags) flag.cloth.rotation.y = Math.sin(this.crowdT * 2 + flag.phase) * (0.12 + Math.min(1, this.excite) * 0.25);
    const im = this.crowd;
    if (!im) return;
    this.crowdAcc += dt;
    const idle = this.q.crowdAnim;
    if (this.crowdAcc < 1 / 14) return;
    if (!idle && this.excite < 0.05) {
      this.crowdAcc = 0;
      return;
    }
    this.crowdAcc = 0;
    const arr = im.instanceMatrix.array as Float32Array;
    const harr = this.heads ? (this.heads.instanceMatrix.array as Float32Array) : null;
    const ex = Math.min(1, this.excite);
    const T = this.crowdT;
    const amp = (idle ? 0.025 : 0) + ex * 0.32;
    const sp = 3 + ex * 7;
    for (let i = 0; i < this.crowdN; i++) {
      const o = i * 16;
      const bob = Math.abs(Math.sin(T * sp + this.crowdPhase[i])) * amp;
      const y = this.crowdBase[i * 3 + 1] + bob;
      arr[o + 13] = y;
      if (harr) harr[o + 13] = y + 0.43;
    }
    im.instanceMatrix.needsUpdate = true;
    if (this.heads) this.heads.instanceMatrix.needsUpdate = true;
  }

  dispose() {
    this.scene.traverse((o: Object3D) => {
      const m = o as Mesh;
      if (m.isMesh) {
        const mat = m.material as Material | Material[];
        if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
      }
    });
    this.fx.dispose();
    this.crowd?.dispose();
    this.heads?.dispose();
    this.owned.forEach((o) => o.dispose());
    this.owned = [];
    this.scene.clear();
  }
}

export { Vector3 };
