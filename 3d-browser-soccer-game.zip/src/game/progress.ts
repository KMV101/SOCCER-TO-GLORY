import { TEAMS, UNLOCKS, getTeam, levelFromXp, type UnlockDef } from './config';
import { ensureDaily, getSave, updateSave, type DailyProgress, type TMatch, type TournamentState } from './save';

// ------------------------------------------------------------------ rewards
export interface Rewards { xp: number; coins: number; levelBefore: number; levelAfter: number }

export function grantRewards(result: 'win' | 'draw' | 'loss', goalsFor: number, goalsAgainst: number, bonus = 0): Rewards {
  const xp = (result === 'win' ? 60 : result === 'draw' ? 30 : 15) + goalsFor * 10 + (goalsAgainst === 0 ? 15 : 0) + bonus;
  const coins = (result === 'win' ? 90 : result === 'draw' ? 40 : 20) + goalsFor * 15 + Math.floor(bonus / 2);
  const before = levelFromXp(getSave().xp).level;
  updateSave((d) => {
    d.xp += xp;
    d.coins += coins;
    d.stats.played++;
    if (result === 'win') d.stats.won++;
    else if (result === 'draw') d.stats.drawn++;
    else d.stats.lost++;
    d.stats.goals += goalsFor;
    d.stats.conceded += goalsAgainst;
  });
  return { xp, coins, levelBefore: before, levelAfter: levelFromXp(getSave().xp).level };
}

export function isUnlocked(u: UnlockDef | undefined): boolean {
  return !u || getSave().unlocked.includes(u.id);
}
export function canBuy(u: UnlockDef): boolean {
  const s = getSave();
  return !s.unlocked.includes(u.id) && levelFromXp(s.xp).level >= u.level && s.coins >= u.cost;
}
export function buy(u: UnlockDef): boolean {
  if (!canBuy(u)) return false;
  updateSave((d) => {
    d.coins -= u.cost;
    d.unlocked.push(u.id);
  });
  return true;
}
export const allUnlocks = () => UNLOCKS;

export function teamUnlocked(teamId: string): boolean {
  const u = UNLOCKS.find((x) => x.type === 'team' && x.ref === teamId);
  return isUnlocked(u);
}
export function stadiumUnlocked(id: string): boolean {
  const u = UNLOCKS.find((x) => x.type === 'stadium' && x.ref === id);
  return isUnlocked(u);
}

// ------------------------------------------------------------------ tournament
function shuffle<T>(a: T[]): T[] {
  const r = [...a];
  for (let i = r.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [r[i], r[j]] = [r[j], r[i]];
  }
  return r;
}

export function createTournament(teamId: string): TournamentState {
  const ids = shuffle(TEAMS.map((t) => t.id));
  const rounds: TMatch[][] = [[], [], []];
  for (let i = 0; i < 8; i += 2) rounds[0].push({ a: ids[i], b: ids[i + 1] });
  return { teamId, rounds, round: 0, status: 'active' };
}

/** Simulate a match between two AI teams based on ratings. */
export function simulateMatch(m: TMatch): TMatch {
  const A = getTeam(m.a);
  const B = getTeam(m.b);
  const lam = (att: number, def: number, gk: number) => 1.5 * Math.pow(att / (def * 0.6 + gk * 0.4), 4);
  const poisson = (l: number) => {
    let L = Math.exp(-l);
    let k = 0;
    let p = 1;
    do {
      k++;
      p *= Math.random();
    } while (p > L && k < 9);
    return k - 1;
  };
  const ga = poisson(lam(A.attack, B.defense, B.goalkeeper));
  const gb = poisson(lam(B.attack, A.defense, A.goalkeeper));
  let winner = ga > gb ? A.id : gb > ga ? B.id : '';
  let pens: string | undefined;
  if (!winner) {
    const pa = A.rating / (A.rating + B.rating);
    const aWins = Math.random() < pa;
    winner = aWins ? A.id : B.id;
    pens = aWins ? '5-4 pens' : '4-5 pens';
  }
  return { ...m, ga, gb, winner, pens };
}

export function userMatchIndex(t: TournamentState): number {
  return t.rounds[t.round].findIndex((m) => m.a === t.teamId || m.b === t.teamId);
}

export function currentTournamentMatch(t: TournamentState): TMatch | null {
  if (t.status !== 'active') return null;
  const i = userMatchIndex(t);
  return i >= 0 ? t.rounds[t.round][i] : null;
}

/** Record the player's result, simulate the other fixtures, advance the bracket. */
export function recordTournamentResult(userGoals: number, oppGoals: number, wonOnPens: boolean | null) {
  updateSave((d) => {
    const t = d.tournament;
    if (!t || t.status !== 'active') return;
    const idx = userMatchIndex(t);
    if (idx < 0) return;
    const m = t.rounds[t.round][idx];
    const userIsA = m.a === t.teamId;
    m.ga = userIsA ? userGoals : oppGoals;
    m.gb = userIsA ? oppGoals : userGoals;
    const userWon = userGoals > oppGoals || (userGoals === oppGoals && wonOnPens === true);
    m.winner = userWon ? t.teamId : userIsA ? m.b : m.a;
    if (userGoals === oppGoals) m.pens = 'pens';
    t.rounds[t.round] = t.rounds[t.round].map((x, i) => (i === idx || x.winner ? x : simulateMatch(x)));
    // complete the rest of the bracket
    for (let r = t.round; r < 3; r++) {
      const ws = t.rounds[r].map((x) => x.winner as string);
      if (r < 2) {
        if (t.rounds[r + 1].length === 0) {
          for (let i = 0; i < ws.length; i += 2) t.rounds[r + 1].push({ a: ws[i], b: ws[i + 1] });
        }
      }
      if (r === t.round && !userWon) {
        // eliminated: simulate the rest for display
        t.status = 'eliminated';
        for (let rr = r + 1; rr < 3; rr++) {
          t.rounds[rr] = t.rounds[rr].map((x) => (x.winner ? x : simulateMatch(x)));
          if (rr < 2 && t.rounds[rr + 1].length === 0) {
            const w2 = t.rounds[rr].map((x) => x.winner as string);
            for (let i = 0; i < w2.length; i += 2) t.rounds[rr + 1].push({ a: w2[i], b: w2[i + 1] });
          }
        }
        return;
      }
      break;
    }
    if (userWon) {
      if (t.round === 2) {
        t.status = 'champion';
        d.stats.tournaments++;
      } else t.round++;
    }
  });
}

export const ROUND_NAMES = ['Quarterfinal', 'Semifinal', 'Final'];

// ------------------------------------------------------------------ daily objectives
export interface DailyObjective {
  id: 'play' | 'goals' | 'street';
  title: string;
  detail: string;
  target: number;
  xp: number;
  coins: number;
}
export const DAILY_OBJECTIVES: DailyObjective[] = [
  { id: 'play', title: 'Show up', detail: 'Finish any match', target: 1, xp: 45, coins: 50 },
  { id: 'goals', title: 'Find the net', detail: 'Score 3 goals in matches', target: 3, xp: 65, coins: 75 },
  { id: 'street', title: 'Five-a-side fever', detail: 'Win a Street Soccer match', target: 1, xp: 90, coins: 100 },
];
export function dailyValue(p: DailyProgress, id: DailyObjective['id']) {
  if (id === 'play') return p.matches;
  if (id === 'goals') return p.goals;
  return p.streetWins;
}
export const getDaily = () => getSave().daily;

/** Progress is local and resets by the player's local calendar day. */
export function recordDailyMatch(goals: number, win: boolean, street: boolean) {
  ensureDaily();
  updateSave((d) => {
    d.daily.matches++;
    d.daily.goals += Math.max(0, goals);
    if (street && win) d.daily.streetWins++;
  });
}

export function claimDailyObjective(id: DailyObjective['id']): boolean {
  ensureDaily();
  const objective = DAILY_OBJECTIVES.find((x) => x.id === id);
  if (!objective) return false;
  const daily = getSave().daily;
  if (daily.claimed.includes(id) || dailyValue(daily, id) < objective.target) return false;
  updateSave((d) => {
    if (d.daily.claimed.includes(id)) return;
    d.daily.claimed.push(id);
    d.coins += objective.coins;
    d.xp += objective.xp;
  });
  return true;
}
