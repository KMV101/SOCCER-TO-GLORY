import { Mesh, MeshBasicMaterial, PlaneGeometry, Quaternion, Vector3 } from 'three';
import type { PitchSpec } from './config';
import { blobShadowTexture, createBallMesh } from './models';
import type { Footballer } from './entities';

export type BallEvent = 'bounce' | 'post' | 'net' | 'wall';

export const GRAVITY = 17;

export class Ball {
  readonly r = 0.24;
  pos = new Vector3(0, 0.24, 0);
  vel = new Vector3();
  spin = new Vector3();
  mesh: Mesh;
  shadow: Mesh;
  owner: Footballer | null = null;
  lastTouch: Footballer | null = null;
  /** increments each time the ball is kicked – lets the keeper decide once per shot */
  shotId = 0;
  lastKickTeam = -1;
  lastKickTime = 0;
  onEvent: ((e: BallEvent, strength: number) => void) | null = null;
  private q = new Quaternion();
  private axis = new Vector3();
  private px = 0;

  constructor() {
    this.mesh = createBallMesh(this.r);
    this.shadow = new Mesh(
      new PlaneGeometry(1, 1).rotateX(-Math.PI / 2),
      new MeshBasicMaterial({ map: blobShadowTexture(), transparent: true, opacity: 0.54, depthWrite: false }),
    );
    this.shadow.position.y = 0.03;
    this.shadow.renderOrder = 1;
    this.shadow.userData.shared = true; // shares the module-level blob geometry/material
  }

  reset(x: number, z: number) {
    if (this.owner) {
      this.owner.hasBall = false;
      this.owner.holding = false;
    }
    this.pos.set(x, this.r, z);
    this.vel.set(0, 0, 0);
    this.spin.set(0, 0, 0);
    this.owner = null;
    this.lastTouch = null;
    this.lastKickTeam = -1;
    this.lastKickTime = 0;
    this.syncMesh();
  }

  get speed() {
    return Math.hypot(this.vel.x, this.vel.z);
  }
  get onGround() {
    return this.pos.y <= this.r + 0.02;
  }

  step(dt: number, p: PitchSpec) {
    const r = this.r;
    const v = this.vel;
    const pos = this.pos;
    this.px = pos.x;
    v.y -= GRAVITY * dt;

    // air drag (quadratic) + magnus
    const sp = v.length();
    if (sp > 0.01) {
      const drag = 0.0042 * sp * dt;
      v.multiplyScalar(Math.max(0, 1 - drag));
      if (!this.onGround) {
        // magnus: a = k * (spin x v)
        const k = 0.014;
        const s = this.spin;
        const ax = (s.y * v.z - s.z * v.y) * k * dt;
        const ay = (s.z * v.x - s.x * v.z) * k * dt;
        const az = (s.x * v.y - s.y * v.x) * k * dt;
        v.x += ax;
        v.y += ay * 0.3;
        v.z += az;
        s.multiplyScalar(1 - 0.25 * dt);
      }
    }

    pos.addScaledVector(v, dt);

    // ground
    if (pos.y < r) {
      pos.y = r;
      if (v.y < -1.4) {
        const imp = -v.y;
        v.y = imp * 0.6;
        v.x *= 0.93;
        v.z *= 0.93;
        this.onEvent?.('bounce', Math.min(1, imp / 12));
      } else if (v.y < 0) v.y = 0;
    }
    if (this.onGround && v.y <= 0.05) {
      v.y = Math.max(v.y, 0);
      const h = Math.hypot(v.x, v.z);
      if (h > 0) {
        const dec = (1.4 + 0.45 * h) * dt;
        const nh = Math.max(0, h - dec);
        const f = nh / h;
        v.x *= f;
        v.z *= f;
        if (nh < 0.06) {
          v.x = 0;
          v.z = 0;
        }
      }
      // rolling spin
      this.spin.x += (v.z / r - this.spin.x) * Math.min(1, 12 * dt);
      this.spin.z += (-v.x / r - this.spin.z) * Math.min(1, 12 * dt);
      this.spin.y *= Math.max(0, 1 - 4 * dt);
    }

    this.collide(p);
    this.syncMesh(dt);
  }

  private hit(e: BallEvent, s: number) {
    this.onEvent?.(e, s);
  }

  private collide(p: PitchSpec) {
    const r = this.r;
    const pos = this.pos;
    const v = this.vel;
    const hl = p.L / 2;
    const gw = p.goalW / 2;

    // --- goal frame posts (vertical cylinders) and crossbar
    const sx = pos.x >= 0 ? 1 : -1;
    const ax = Math.abs(pos.x);
    if (ax > hl - 1 && ax < hl + p.goalD + 1) {
      // posts
      if (pos.y < p.goalH + r) {
        for (const sz of [-1, 1]) {
          const dx = ax - hl;
          const dz = pos.z - sz * gw;
          const d = Math.hypot(dx, dz);
          const min = r + 0.07;
          if (d < min && d > 1e-4) {
            const nx = (dx / d) * sx; // world-space normal
            const nz = dz / d;
            const vn = v.x * nx + v.z * nz;
            if (vn < 0) {
              v.x -= 1.65 * vn * nx;
              v.z -= 1.65 * vn * nz;
              this.hit('post', Math.min(1, -vn / 15));
            }
            pos.x = sx * (hl + (dx / d) * min);
            pos.z = sz * gw + nz * min;
          }
        }
      }
      // crossbar
      if (Math.abs(pos.z) < gw + 0.07) {
        const dx = ax - hl;
        const dy = pos.y - p.goalH;
        const d = Math.hypot(dx, dy);
        const min = r + 0.07;
        if (d < min && d > 1e-4) {
          const nx = dx / d;
          const ny = dy / d;
          const vn = v.x * nx * sx + v.y * ny;
          if (vn < 0) {
            v.x -= 1.6 * vn * nx * sx;
            v.y -= 1.6 * vn * ny;
            this.hit('post', Math.min(1, -vn / 15));
          }
          pos.x = sx * (hl + nx * min);
          pos.y = p.goalH + ny * min;
        }
      }
      // side nets (planes at z = ±gw, x in net depth)
      if (ax > hl + 0.02 && ax < hl + p.goalD + r && pos.y < p.goalH + 0.05) {
        for (const sz of [-1, 1]) {
          const dz = pos.z - sz * gw;
          if (Math.abs(dz) < r) {
            const side = dz === 0 ? (v.z * sz > 0 ? 1 : -1) : Math.sign(dz);
            pos.z = sz * gw + side * r;
            if (v.z * side < 0) {
              v.z *= -0.2;
              v.x *= 0.7;
              this.hit('net', 0.3);
            }
          }
        }
      }
      // back net + roof net (side aware: only act on the side the ball came from)
      const back = hl + p.goalD;
      if (Math.abs(pos.z) < gw && pos.y < p.goalH + r * 2) {
        const wasInside = Math.abs(this.px) <= back;
        if (wasInside && ax > back - r) {
          pos.x = sx * (back - r);
          if (v.x * sx > 0) {
            this.hit('net', Math.min(1, Math.abs(v.x) / 20));
            v.x *= -0.15;
            v.z *= 0.5;
            v.y *= 0.5;
          }
        } else if (!wasInside && ax < back + r) {
          pos.x = sx * (back + r);
          if (v.x * sx < 0) v.x *= -0.3;
        }
        if (ax > hl && ax < back) {
          if (pos.y + r > p.goalH && pos.y < p.goalH && v.y > 0) {
            pos.y = p.goalH - r;
            v.y *= -0.2;
            v.x *= 0.8;
          } else if (pos.y - r < p.goalH && pos.y > p.goalH && v.y < 0) {
            pos.y = p.goalH + r;
            v.y *= -0.35;
          }
        }
      }
    }

    // --- boards (invisible walls keep the ball in play – arcade futsal style)
    const bx = p.boardX - r;
    const bz = p.boardZ - r;
    const wb = p.wallBounce ?? 0.55;
    if (pos.x > bx || pos.x < -bx) {
      pos.x = Math.sign(pos.x) * bx;
      this.hit('wall', 0.4 + (p.street ? 0.4 : 0));
      v.x *= -wb;
      v.z *= p.street ? 0.97 : 0.9;
    }
    if (pos.z > bz || pos.z < -bz) {
      pos.z = Math.sign(pos.z) * bz;
      this.hit('wall', 0.4 + (p.street ? 0.4 : 0));
      v.z *= -wb;
      v.x *= p.street ? 0.97 : 0.9;
    }
    // ceiling (stadium roof line) – prevents the ball leaving the arena
    if (pos.y > 16) {
      pos.y = 16;
      if (v.y > 0) v.y *= -0.4;
    }
  }

  private syncMesh(dt = 0) {
    this.mesh.position.copy(this.pos);
    const height = Math.max(0, this.pos.y - this.r);
    const scale = 0.72 + Math.min(1.2, height * 0.085);
    this.shadow.position.set(this.pos.x, 0.03, this.pos.z);
    this.shadow.scale.set(scale, 1, scale);
    (this.shadow.material as MeshBasicMaterial).opacity = Math.max(0.06, 0.54 - height * 0.055);
    this.shadow.visible = height < 9;
    const w = this.spin.length();
    if (w > 0.01 && dt > 0) {
      this.axis.copy(this.spin).divideScalar(w);
      this.q.setFromAxisAngle(this.axis, w * dt);
      this.mesh.quaternion.premultiply(this.q);
    }
  }
}
