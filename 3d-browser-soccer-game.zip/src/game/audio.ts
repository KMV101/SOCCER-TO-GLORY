// Fully procedural audio (WebAudio) – no external assets, nothing copyrighted.

type SfxName = 'kick' | 'pass' | 'bounce' | 'tackle' | 'whistle' | 'whistleLong' | 'goal' | 'click' | 'hover' | 'save' | 'post' | 'net' | 'cheer' | 'groan' | 'tick' | 'powerKick' | 'timedGreen' | 'whoosh';

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private master!: GainNode;
  private musicBus!: GainNode;
  private sfxBus!: GainNode;
  private crowdBus!: GainNode;
  private crowdGain!: GainNode;
  private noise!: AudioBuffer;
  private crowdSrc: AudioBufferSourceNode | null = null;
  private musicTimer: number | null = null;
  private step = 0;
  private vols = { master: 0.8, music: 0.4, sfx: 0.9, crowd: 0.7 };
  private lastBounce = 0;
  private extMute = false;
  private cheerUntil = 0;
  private nextCrowdUpdate = 0;
  private lastCrowdLevel = -1;

  /** Forced mute (CrazyGames SDK muteAudio / ad playing). Takes priority over the volume sliders. */
  setExternalMute(m: boolean) {
    this.extMute = m;
    this.applyVolumes();
  }

  unlock() {
    if (this.ctx) {
      if (this.ctx.state !== 'running') void this.ctx.resume().catch(() => {});
      return;
    }
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AC();
    } catch {
      return;
    }
    const c = this.ctx;
    this.master = c.createGain();
    this.master.connect(c.destination);
    this.musicBus = c.createGain();
    this.sfxBus = c.createGain();
    this.crowdBus = c.createGain();
    this.musicBus.connect(this.master);
    this.sfxBus.connect(this.master);
    this.crowdBus.connect(this.master);
    this.crowdGain = c.createGain();
    this.crowdGain.gain.value = 0;
    this.crowdGain.connect(this.crowdBus);
    const len = c.sampleRate * 2;
    this.noise = c.createBuffer(1, len, c.sampleRate);
    const d = this.noise.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      last = (last + 0.06 * w) / 1.06; // soft (brown-ish) noise
      d[i] = last * 3.2;
    }
    this.applyVolumes();
  }

  setVolumes(v: { master: number; music: number; sfx: number; crowd: number }) {
    this.vols = v;
    this.applyVolumes();
  }
  private applyVolumes() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.extMute ? 0 : this.vols.master, t, 0.05);
    this.musicBus.gain.setTargetAtTime(this.vols.music * 0.5, t, 0.05);
    this.sfxBus.gain.setTargetAtTime(this.vols.sfx, t, 0.05);
    this.crowdBus.gain.setTargetAtTime(this.vols.crowd, t, 0.05);
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, bus: GainNode, slideTo?: number, delay = 0) {
    const c = this.ctx;
    if (!c) return;
    const t = c.currentTime + delay;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(bus);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private burst(dur: number, vol: number, filterType: BiquadFilterType, freq: number, bus: GainNode, delay = 0) {
    const c = this.ctx;
    if (!c) return;
    const t = c.currentTime + delay;
    const s = c.createBufferSource();
    s.buffer = this.noise;
    const f = c.createBiquadFilter();
    f.type = filterType;
    f.frequency.value = freq;
    const g = c.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f);
    f.connect(g);
    g.connect(bus);
    s.start(t, Math.random());
    s.stop(t + dur + 0.02);
  }

  play(name: SfxName, intensity = 1) {
    const c = this.ctx;
    if (!c) return;
    const i = Math.max(0.1, Math.min(1.5, intensity));
    const b = this.sfxBus;
    switch (name) {
      case 'kick':
        this.burst(0.07, 0.9 * i, 'highpass', 900, b);
        this.tone(150, 0.12, 'sine', 0.8 * i, b, 55);
        break;
      case 'powerKick':
        // heavy booming leather strike with sub-bass resonance
        this.burst(0.12, 1.3 * i, 'bandpass', 520, b);
        this.tone(95, 0.22, 'triangle', 1.0 * i, b, 35);
        this.tone(55, 0.28, 'sine', 0.9 * i, b, 28);
        break;
      case 'timedGreen':
        // Crisp feedback for a clean contact.
        this.tone(880, 0.09, 'sine', 0.7 * i, b, 1320);
        this.tone(1760, 0.07, 'triangle', 0.5 * i, b, 2200, 0.02);
        break;
      case 'whoosh':
        // charging whoosh
        this.burst(0.24, 0.65 * i, 'bandpass', 450, b);
        this.tone(180, 0.22, 'sine', 0.35 * i, b, 90);
        break;
      case 'pass':
        this.burst(0.05, 0.5 * i, 'highpass', 1200, b);
        this.tone(130, 0.09, 'sine', 0.45 * i, b, 60);
        break;
      case 'bounce': {
        const now = c.currentTime;
        if (now - this.lastBounce < 0.07) return;
        this.lastBounce = now;
        this.tone(110, 0.1, 'sine', 0.5 * i, b, 55);
        break;
      }
      case 'tackle':
        this.burst(0.18, 0.8, 'bandpass', 500, b);
        this.tone(90, 0.15, 'sine', 0.6, b, 50);
        break;
      case 'whistle':
      case 'whistleLong': {
        const dur = name === 'whistle' ? 0.35 : 0.9;
        const t = c.currentTime;
        const o = c.createOscillator();
        const lfo = c.createOscillator();
        const lg = c.createGain();
        const g = c.createGain();
        o.type = 'sine';
        o.frequency.value = 2850;
        lfo.frequency.value = 32;
        lg.gain.value = 90;
        lfo.connect(lg);
        lg.connect(o.frequency);
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(0.35, t + 0.03);
        g.gain.setValueAtTime(0.35, t + dur - 0.1);
        g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        o.connect(g);
        g.connect(b);
        o.start(t);
        lfo.start(t);
        o.stop(t + dur + 0.05);
        lfo.stop(t + dur + 0.05);
        break;
      }
      case 'goal':
        [220, 277, 330].forEach((f) => this.tone(f, 1.3, 'sawtooth', 0.12, b, f * 1.01));
        this.tone(110, 1.3, 'square', 0.1, b);
        this.cheer(1);
        break;
      case 'click':
        this.tone(620, 0.07, 'triangle', 0.35, b, 900);
        break;
      case 'hover':
        this.tone(420, 0.04, 'sine', 0.12, b);
        break;
      case 'tick':
        this.tone(880, 0.08, 'square', 0.12, b);
        break;
      case 'save':
        this.burst(0.12, 0.7, 'bandpass', 700, b);
        this.tone(100, 0.12, 'sine', 0.7, b, 60);
        break;
      case 'post':
        this.tone(980, 0.35, 'sine', 0.5, b);
        this.tone(1470, 0.25, 'triangle', 0.25, b);
        break;
      case 'net':
        this.burst(0.35, 0.5, 'lowpass', 1500, b);
        break;
      case 'cheer':
        this.cheer(i);
        break;
      case 'groan':
        this.groan();
        break;
    }
  }

  private cheer(level: number) {
    const c = this.ctx;
    if (!c) return;
    const t = c.currentTime;
    this.cheerUntil = t + 2.3;
    this.crowdGain.gain.cancelScheduledValues(t);
    this.crowdGain.gain.setTargetAtTime(0.9 * level, t, 0.15);
    this.crowdGain.gain.setTargetAtTime(0.28, t + 2.2, 0.8);
  }
  private groan() {
    const c = this.ctx;
    if (!c) return;
    const t = c.currentTime;
    this.crowdGain.gain.setTargetAtTime(0.5, t, 0.1);
    this.crowdGain.gain.setTargetAtTime(0.28, t + 0.8, 0.5);
  }

  startCrowd() {
    const c = this.ctx;
    if (!c || this.crowdSrc) return;
    const s = c.createBufferSource();
    s.buffer = this.noise;
    s.loop = true;
    const bp = c.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 650;
    bp.Q.value = 0.4;
    s.connect(bp);
    bp.connect(this.crowdGain);
    s.start();
    this.crowdSrc = s;
    this.crowdGain.gain.setTargetAtTime(0.28, c.currentTime, 0.5);
  }
  stopCrowd() {
    const c = this.ctx;
    if (!c || !this.crowdSrc) return;
    this.crowdGain.gain.setTargetAtTime(0, c.currentTime, 0.2);
    const s = this.crowdSrc;
    this.crowdSrc = null;
    this.cheerUntil = 0;
    this.lastCrowdLevel = -1;
    setTimeout(() => {
      try {
        s.stop();
      } catch {
        /* already stopped */
      }
    }, 800);
  }
  /** 0..1 excitement based on ball proximity to goal */
  setCrowdLevel(l: number) {
    if (!this.ctx || !this.crowdSrc) return;
    const now = this.ctx.currentTime;
    if (now < this.cheerUntil || now < this.nextCrowdUpdate) return;
    const level = 0.2 + Math.max(0, Math.min(1, l)) * 0.25;
    this.nextCrowdUpdate = now + 0.12;
    if (Math.abs(level - this.lastCrowdLevel) < 0.025) return;
    this.lastCrowdLevel = level;
    this.crowdGain.gain.setTargetAtTime(level, now, 0.4);
  }

  // ----- simple procedural menu music (chill four-chord groove)
  startMusic() {
    if (!this.ctx || this.musicTimer !== null) return;
    const roots = [110, 87.31, 130.81, 98];
    const chords = [[220, 261.63, 329.63], [174.61, 220, 261.63], [261.63, 329.63, 392], [196, 246.94, 293.66]];
    this.step = 0;
    this.musicTimer = window.setInterval(() => {
      if (!this.ctx) return;
      const bar = Math.floor(this.step / 16) % 4;
      const s = this.step % 16;
      const b = this.musicBus;
      if (s % 4 === 0) this.tone(55, 0.25, 'sine', 0.5, b, 40); // kick
      if (s === 4 || s === 12) this.burst(0.1, 0.25, 'highpass', 2500, b); // snare-ish
      if (s % 2 === 1) this.burst(0.03, 0.08, 'highpass', 7000, b); // hat
      if ([0, 3, 6, 10, 12].includes(s)) this.tone(roots[bar], 0.22, 'square', 0.12, b);
      if (s % 2 === 0) this.tone(chords[bar][(s / 2) % 3] * 2, 0.18, 'triangle', 0.07, b);
      this.step++;
    }, 132);
  }
  stopMusic() {
    if (this.musicTimer !== null) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }
}

export const audio = new AudioEngine();
