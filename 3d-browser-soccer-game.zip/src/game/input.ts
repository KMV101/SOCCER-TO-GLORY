// Unified keyboard / mouse / gamepad input with per-frame edge detection.

export type Action = 'shoot' | 'pass' | 'through' | 'tackle' | 'slide' | 'switch' | 'sprint' | 'lob' | 'low' | 'pause' | 'reset' | 'skill' | 'powershot' | 'finesse' | 'diveLeft' | 'diveRight' | 'diveHigh' | 'diveLow';
const ACTIONS: Action[] = ['shoot', 'pass', 'through', 'tackle', 'slide', 'switch', 'sprint', 'lob', 'low', 'pause', 'reset', 'skill', 'powershot', 'finesse', 'diveLeft', 'diveRight', 'diveHigh', 'diveLow'];

const KEYMAP: Record<Action, string[]> = {
  shoot: [],
  pass: ['KeyQ'],
  through: [],
  tackle: ['KeyE'],
  slide: [],
  switch: ['Space'],
  sprint: ['ShiftLeft', 'ShiftRight'],
  lob: ['KeyR'],
  low: ['KeyX'],
  finesse: ['KeyF'],
  powershot: ['KeyV'],
  pause: ['Escape', 'KeyP'],
  reset: ['KeyB'],
  skill: ['KeyC'],
  diveLeft: [],
  diveRight: [],
  diveHigh: [],
  diveLow: [],
};

export class Input {
  keys = new Set<string>();
  mouseLeft = false;
  mouseRight = false;
  enabled = false;
  useGamepad = true;
  /** screen-space movement: x = right, y = forward (up on screen) */
  moveX = 0;
  moveY = 0;
  usingPad = false;

  down: Record<Action, boolean> = {} as Record<Action, boolean>;
  prev: Record<Action, boolean> = {} as Record<Action, boolean>;
  pressed: Record<Action, boolean> = {} as Record<Action, boolean>;
  released: Record<Action, boolean> = {} as Record<Action, boolean>;
  holdTime: Record<Action, number> = {} as Record<Action, number>;
  /** hold duration of the last completed press */
  lastHold: Record<Action, number> = {} as Record<Action, number>;

  private canvas: HTMLElement | null = null;
  private padDown: Record<Action, boolean> = {} as Record<Action, boolean>;
  /** On-screen controls share the same action state on mouse and touch devices. */
  touchX = 0;
  touchY = 0;
  private touchDown: Record<Action, boolean> = {} as Record<Action, boolean>;
  private virtualPress = new Set<Action>();
  private virtualRelease = new Set<Action>();
  private pausePadHeld = false;

  setTouchMove(x: number, y: number) {
    this.touchX = x;
    this.touchY = y;
  }
  setTouchBtn(a: Action, v: boolean) {
    if (this.touchDown[a] === v) return;
    this.touchDown[a] = v;
    if (v) this.virtualPress.add(a);
    else this.virtualRelease.add(a);
  }

  /** Release held UI controls when the overlay unmounts or gameplay pauses. */
  clearVirtual() {
    this.touchX = this.touchY = 0;
    this.virtualPress.clear();
    this.virtualRelease.clear();
    for (const a of ACTIONS) {
      this.touchDown[a] = false;
      this.down[a] = this.prev[a] = this.pressed[a] = this.released[a] = false;
      this.holdTime[a] = this.lastHold[a] = 0;
    }
  }

  constructor() {
    for (const a of ACTIONS) {
      this.down[a] = this.prev[a] = this.pressed[a] = this.released[a] = this.padDown[a] = this.touchDown[a] = false;
      this.holdTime[a] = this.lastHold[a] = 0;
    }
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mouseup', this.onMouseUp);
    window.addEventListener('blur', this.releaseAll);
    window.addEventListener('contextmenu', this.onContext);
  }

  attach(canvas: HTMLElement) {
    this.canvas = canvas;
  }

  dispose() {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('mousedown', this.onMouseDown);
    window.removeEventListener('mouseup', this.onMouseUp);
    window.removeEventListener('blur', this.releaseAll);
    window.removeEventListener('contextmenu', this.onContext);
  }

  /** Drop held physical and on-screen inputs so releasing a key after pause cannot fire a shot. */
  suspend() {
    this.releaseAll();
  }

  private releaseAll = () => {
    this.keys.clear();
    this.mouseLeft = this.mouseRight = false;
    this.clearVirtual();
  };

  private onContext = (e: Event) => {
    if (this.enabled && e.target === this.canvas) e.preventDefault();
  };

  private onKeyDown = (e: KeyboardEvent) => {
    const tag = (e.target as HTMLElement | null)?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || (tag === 'BUTTON' && (e.code === 'Space' || e.code === 'Enter'))) return;
    if (this.enabled && (e.code === 'Space' || e.code.startsWith('Arrow') || e.code === 'Tab')) e.preventDefault();
    if (!this.keys.has(e.code)) {
      for (const a of ACTIONS) if (KEYMAP[a].includes(e.code)) this.virtualPress.add(a);
    }
    this.keys.add(e.code);
  };
  private onKeyUp = (e: KeyboardEvent) => {
    if (this.keys.has(e.code)) {
      for (const a of ACTIONS) if (KEYMAP[a].includes(e.code)) this.virtualRelease.add(a);
    }
    this.keys.delete(e.code);
  };
  private onMouseDown = (e: MouseEvent) => {
    if (!this.enabled || e.target !== this.canvas) return;
    if (e.button === 0) {
      if (!this.mouseLeft) this.virtualPress.add('shoot');
      this.mouseLeft = true;
    }
    if (e.button === 2) {
      if (!this.mouseRight) this.virtualPress.add('through');
      this.mouseRight = true;
    }
    e.preventDefault();
  };
  private onMouseUp = (e: MouseEvent) => {
    if (e.button === 0) {
      if (this.mouseLeft) this.virtualRelease.add('shoot');
      this.mouseLeft = false;
    }
    if (e.button === 2) {
      if (this.mouseRight) this.virtualRelease.add('through');
      this.mouseRight = false;
    }
  };

  /** Call once per rendered frame BEFORE game logic. */
  update(dt: number) {
    const k = this.keys;
    let mx = (k.has('KeyD') || k.has('ArrowRight') ? 1 : 0) - (k.has('KeyA') || k.has('ArrowLeft') ? 1 : 0);
    let my = (k.has('KeyW') || k.has('ArrowUp') ? 1 : 0) - (k.has('KeyS') || k.has('ArrowDown') ? 1 : 0);
    for (const a of ACTIONS) this.padDown[a] = false;
    this.usingPad = false;
    let padConnected = false;
    if (this.useGamepad && navigator.getGamepads) {
      const pads = navigator.getGamepads();
      for (const pad of pads) {
        if (!pad || !pad.connected) continue;
        padConnected = true;
        const ax = pad.axes[0] ?? 0;
        const ay = pad.axes[1] ?? 0;
        const mag = Math.hypot(ax, ay);
        if (mag > 0.2) {
          const s = Math.min(1, (mag - 0.2) / 0.8) / mag;
          mx += ax * s;
          my += -ay * s;
          this.usingPad = true;
        }
        const b = (i: number) => !!pad.buttons[i]?.pressed;
        if (b(12)) my += 1;
        if (b(13)) my -= 1;
        if (b(14)) mx -= 1;
        if (b(15)) mx += 1;
        this.padDown.pass ||= b(0);
        this.padDown.shoot ||= b(1);
        this.padDown.tackle ||= b(2) && !(b(5) || b(7));
        this.padDown.slide ||= b(2) && (b(5) || b(7));
        this.padDown.through ||= b(3);
        this.padDown.switch ||= b(4) && !b(1);
        this.padDown.sprint ||= b(5) || b(7);
        this.padDown.lob ||= b(6) && !b(1);
        this.padDown.low ||= b(8);
        const pauseDown = b(9);
        this.padDown.pause ||= pauseDown && !this.pausePadHeld;
        this.pausePadHeld = pauseDown;
        this.padDown.reset ||= false;
        this.padDown.skill ||= b(11) || b(10);
        this.padDown.powershot ||= b(1) && b(4) && b(5);
        this.padDown.finesse ||= b(1) && b(6);
        break;
      }
    }
    if (!padConnected) this.pausePadHeld = false;
    mx += this.touchX;
    my += this.touchY;
    const len = Math.hypot(mx, my);
    if (len > 1) {
      mx /= len;
      my /= len;
    }
    this.moveX = mx;
    this.moveY = my;

    for (const a of ACTIONS) {
      let d = this.padDown[a] || this.touchDown[a] || KEYMAP[a].some((c) => k.has(c));
      if (a === 'shoot') d ||= this.mouseLeft;
      if (a === 'through') d ||= this.mouseRight;
      const wasDown = this.down[a];
      const quickTap = this.virtualPress.has(a) && this.virtualRelease.has(a) && !d && !wasDown;
      this.prev[a] = wasDown;
      this.down[a] = d;
      this.pressed[a] = (d && !wasDown) || quickTap;
      this.released[a] = (!d && wasDown) || quickTap;
      if (d) this.holdTime[a] = wasDown ? this.holdTime[a] + dt : dt;
      if (this.released[a]) this.lastHold[a] = Math.max(this.holdTime[a], dt);
      if (!d) this.holdTime[a] = 0;
    }
    this.virtualPress.clear();
    this.virtualRelease.clear();
  }

  /** Clear one-shot flags so they are not seen twice (used after a fixed sub-step consumed them). */
  consume(a: Action) {
    this.pressed[a] = false;
    this.released[a] = false;
  }
}
