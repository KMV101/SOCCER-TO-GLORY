import {
  BoxGeometry, BufferAttribute, BufferGeometry, CanvasTexture, CapsuleGeometry, Color, ConeGeometry, CylinderGeometry, Euler, Group,
  IcosahedronGeometry, Matrix4, Mesh, MeshBasicMaterial, MeshLambertMaterial, MeshStandardMaterial, PlaneGeometry, Quaternion,
  SphereGeometry, SRGBColorSpace, Vector3,
} from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { HAIR_COLORS, HAIR_STYLES } from './config';

export { HAIR_STYLES };

export interface KitSpec {
  primary: string;
  secondary: string;
  shorts: string;
  socks: string;
  boots: string;
  skin: string;
  hairColor: string;
  hair: number;
  number: number;
  /** 0 solid · 1 vertical stripes · 2 hoops · 3 sash · 4 split */
  pattern?: number;
  gloves?: string;
  silhouette?: boolean;
  /** small per-player variation so faces are not identical */
  seed?: number;
}

// The rig is authored in metres (hip height 0.95, head top 1.85) so it matches the
// 2.44 m goal and the ball radius. No extra scale, otherwise players look like giants.
export const PLAYER_SCALE = 1.0;

// ------------------------------------------------------------ materials
const LIMB_MAT = new MeshLambertMaterial({ vertexColors: true });
const SIL_MAT = new MeshBasicMaterial({ color: 0x080c14 });
let HIGH_QUALITY = false;
const LIMB_MAT_HQ = new MeshStandardMaterial({ vertexColors: true, roughness: 0.82, metalness: 0.02 });

/** Characters use the cheaper Lambert material on LOW, standard shading on MEDIUM/HIGH. */
export function setCharacterQuality(high: boolean) {
  HIGH_QUALITY = high;
}
const limbMat = () => (HIGH_QUALITY ? LIMB_MAT_HQ : LIMB_MAT);

// ------------------------------------------------------------ geometry library
const BASE = {
  chest: new CapsuleGeometry(0.175, 0.28, 6, 16),
  abdomen: new CapsuleGeometry(0.145, 0.14, 5, 14),
  hips: new CylinderGeometry(0.175, 0.19, 0.3, 16),
  shoulder: new SphereGeometry(0.088, 12, 9),
  neck: new CylinderGeometry(0.046, 0.052, 0.1, 10),
  collar: new CylinderGeometry(0.062, 0.07, 0.055, 14),
  skull: new SphereGeometry(0.126, 26, 20),
  jaw: new SphereGeometry(0.075, 14, 10),
  cheek: new SphereGeometry(0.05, 10, 8),
  nose: new ConeGeometry(0.026, 0.055, 8),
  ear: new SphereGeometry(0.028, 8, 6),
  thigh: new CapsuleGeometry(0.076, 0.26, 5, 12),
  knee: new SphereGeometry(0.072, 12, 9),
  calf: new CapsuleGeometry(0.062, 0.2, 5, 12),
  shin: new CapsuleGeometry(0.054, 0.26, 5, 12),
  sockFold: new CylinderGeometry(0.074, 0.07, 0.045, 12),
  ankle: new SphereGeometry(0.055, 10, 8),
  boot: new SphereGeometry(0.058, 12, 9),
  toe: new SphereGeometry(0.042, 10, 8),
  sole: new BoxGeometry(0.108, 0.038, 0.29),
  stud: new ConeGeometry(0.016, 0.03, 6),
  upperArm: new CapsuleGeometry(0.052, 0.19, 5, 12),
  sleeve: new CylinderGeometry(0.058, 0.056, 0.12, 12),
  foreArm: new CapsuleGeometry(0.044, 0.19, 5, 12),
  hand: new SphereGeometry(0.052, 10, 8),
  hairCap: new SphereGeometry(0.132, 18, 14, 0, Math.PI * 2, 0, Math.PI * 0.62),
  hairMass: new SphereGeometry(0.15, 16, 12),
  box: new BoxGeometry(1, 1, 1),
  sphere: new SphereGeometry(1, 12, 9),
};

const _m = new Matrix4();
const _q = new Quaternion();
const _e = new Euler();
const _v = new Vector3();
const _s = new Vector3();
const _c = new Color();
const _c2 = new Color();

type ColorFn = (x: number, y: number, z: number) => string;
type Mat = MeshLambertMaterial | MeshStandardMaterial | MeshBasicMaterial;

function part(geo: BufferGeometry, color: string, x = 0, y = 0, z = 0, sx = 1, sy = 1, sz = 1, rx = 0, ry = 0, rz = 0, fn?: ColorFn): BufferGeometry {
  const c = geo.clone();
  _e.set(rx, ry, rz);
  _q.setFromEuler(_e);
  _m.compose(_v.set(x, y, z), _q, _s.set(sx, sy, sz));
  c.applyMatrix4(_m);
  _c.set(color);
  const n = c.attributes.position.count;
  const arr = new Float32Array(n * 3);
  const pos = c.attributes.position;
  for (let i = 0; i < n; i++) {
    if (fn) _c2.set(fn(pos.getX(i), pos.getY(i), pos.getZ(i)));
    else _c2.copy(_c);
    arr[i * 3] = _c2.r;
    arr[i * 3 + 1] = _c2.g;
    arr[i * 3 + 2] = _c2.b;
  }
  c.setAttribute('color', new BufferAttribute(arr, 3));
  return c;
}
function merge(parts: BufferGeometry[]): BufferGeometry {
  const g = mergeGeometries(parts, false) as BufferGeometry;
  parts.forEach((p) => p.dispose());
  return g;
}
function shade(hex: string, f: number): string {
  const c = new Color(hex);
  c.multiplyScalar(f);
  return `#${c.getHexString()}`;
}

/** Baked ambient occlusion: darkens lower areas so the low-poly body reads with depth. */
const ao = (base: string, depth = 0.22): ColorFn => {
  const c = new Color(base);
  return (_x, y) => {
    const t = Math.max(0, Math.min(1, (y + 0.55) / 1.1));
    const f = 1 - depth * (1 - t) * (1 - t);
    return `#${c.clone().multiplyScalar(f).getHexString()}`;
  };
};

// ------------------------------------------------------------ textures
function cv(w: number, h: number) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  return { c, x: c.getContext('2d')! };
}
const jerseyCache = new Map<string, CanvasTexture>();
const faceCache = new Map<string, CanvasTexture>();
const numTexCache = new Map<string, CanvasTexture>();
const numMatCache = new Map<string, MeshBasicMaterial>();

/** Kit surface: pattern + fabric weave, drawn once per kit and cached. */
function jerseyTexture(primary: string, secondary: string, pattern: number): CanvasTexture {
  const key = `${primary}|${secondary}|${pattern}`;
  const hit = jerseyCache.get(key);
  if (hit) return hit;
  const W = 128;
  const H = 128;
  const { c, x } = cv(W, H);
  x.fillStyle = primary;
  x.fillRect(0, 0, W, H);
  x.fillStyle = secondary;
  if (pattern === 1) for (let i = 0; i < 8; i += 2) x.fillRect(i * (W / 8), 0, W / 8, H);
  else if (pattern === 2) for (let i = 0; i < 6; i += 2) x.fillRect(0, i * (H / 6), W, H / 6);
  else if (pattern === 3) {
    x.beginPath();
    x.moveTo(0, H * 0.34);
    x.lineTo(W, H * 0.06);
    x.lineTo(W, H * 0.26);
    x.lineTo(0, H * 0.54);
    x.closePath();
    x.fill();
  } else if (pattern === 4) x.fillRect(W / 2, 0, W / 2, H);
  for (let i = 0; i < 2400; i++) {
    x.fillStyle = Math.random() > 0.5 ? 'rgba(255,255,255,0.035)' : 'rgba(0,0,0,0.045)';
    x.fillRect(Math.random() * W, Math.random() * H, 1.6, 1.6);
  }
  const tex = new CanvasTexture(c);
  tex.colorSpace = SRGBColorSpace;
  jerseyCache.set(key, tex);
  return tex;
}

/** Painted face: skin shading, eyes with irises, brows, nose and mouth. Cached per skin tone. */
function faceTexture(skin: string, seed: number): CanvasTexture {
  const key = `${skin}|${seed}`;
  const hit = faceCache.get(key);
  if (hit) return hit;
  const W = 256;
  const H = 256;
  const { c, x } = cv(W, H);
  x.fillStyle = skin;
  x.fillRect(0, 0, W, H);
  const grad = x.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, 'rgba(0,0,0,0.2)');
  grad.addColorStop(0.45, 'rgba(0,0,0,0)');
  grad.addColorStop(1, 'rgba(0,0,0,0.32)');
  x.fillStyle = grad;
  x.fillRect(0, 0, W, H);
  for (const cx of [48, 208]) {
    const g = x.createRadialGradient(cx, 132, 2, cx, 132, 26);
    g.addColorStop(0, 'rgba(214,120,96,0.2)');
    g.addColorStop(1, 'rgba(214,120,96,0)');
    x.fillStyle = g;
    x.fillRect(cx - 26, 106, 52, 52);
  }
  let s = seed * 9301 + 49297;
  const rnd = () => ((s = (s * 9301 + 49297) % 233280) / 233280);
  const eyeY = 112 + rnd() * 6;
  const eyeDX = 62 + rnd() * 5;
  const iris = ['#4a2f1d', '#2e4a2a', '#3b2a1a', '#2a3a52'][Math.floor(rnd() * 4)];
  x.lineCap = 'round';
  x.strokeStyle = 'rgba(20,14,10,0.75)';
  x.lineWidth = 5;
  for (const sx of [-1, 1]) {
    x.beginPath();
    x.moveTo(128 + sx * eyeDX - 12, eyeY - 21);
    x.quadraticCurveTo(128 + sx * eyeDX, eyeY - 26, 128 + sx * eyeDX + 12, eyeY - 21);
    x.stroke();
  }
  for (const sx of [-1, 1]) {
    const ex = 128 + sx * eyeDX;
    x.fillStyle = '#efe9e2';
    x.beginPath();
    x.ellipse(ex, eyeY, 12, 7.5, 0, 0, Math.PI * 2);
    x.fill();
    x.fillStyle = iris;
    x.beginPath();
    x.arc(ex + sx * 1.2, eyeY + 0.5, 5.2, 0, Math.PI * 2);
    x.fill();
    x.fillStyle = '#0d0a08';
    x.beginPath();
    x.arc(ex + sx * 1.2, eyeY + 0.5, 2.4, 0, Math.PI * 2);
    x.fill();
    x.fillStyle = 'rgba(255,255,255,0.85)';
    x.beginPath();
    x.arc(ex + sx * 1.2 - 2, eyeY - 2, 1.5, 0, Math.PI * 2);
    x.fill();
    x.strokeStyle = 'rgba(20,14,10,0.5)';
    x.lineWidth = 2;
    x.beginPath();
    x.ellipse(ex, eyeY, 12, 7.5, 0, Math.PI * 1.05, Math.PI * 1.95);
    x.stroke();
  }
  x.strokeStyle = 'rgba(90,55,40,0.4)';
  x.lineWidth = 3.4;
  x.beginPath();
  x.moveTo(127, eyeY + 8);
  x.quadraticCurveTo(124, eyeY + 26, 130, eyeY + 28);
  x.stroke();
  x.fillStyle = 'rgba(60,35,25,0.3)';
  x.beginPath();
  x.ellipse(127, eyeY + 29, 7, 4.4, 0, 0, Math.PI * 2);
  x.fill();
  x.strokeStyle = 'rgba(120,58,52,0.85)';
  x.lineWidth = 3.6;
  x.beginPath();
  x.moveTo(112, eyeY + 45);
  x.quadraticCurveTo(127, eyeY + 50, 142, eyeY + 45);
  x.stroke();
  const g2 = x.createRadialGradient(127, eyeY + 66, 2, 127, eyeY + 66, 24);
  g2.addColorStop(0, 'rgba(0,0,0,0.22)');
  g2.addColorStop(1, 'rgba(0,0,0,0)');
  x.fillStyle = g2;
  x.fillRect(103, eyeY + 42, 48, 48);
  const tex = new CanvasTexture(c);
  tex.colorSpace = SRGBColorSpace;
  faceCache.set(key, tex);
  return tex;
}

function numberTexture(n: number, color: string): CanvasTexture {
  const key = `${n}|${color}`;
  const hit = numTexCache.get(key);
  if (hit) return hit;
  const { c, x } = cv(64, 64);
  x.font = '900 44px Arial Black, Arial, sans-serif';
  x.textAlign = 'center';
  x.textBaseline = 'middle';
  x.lineWidth = 6;
  x.strokeStyle = 'rgba(0,0,0,0.4)';
  x.strokeText(String(n), 32, 34);
  x.fillStyle = color;
  x.fillText(String(n), 32, 34);
  const t = new CanvasTexture(c);
  t.colorSpace = SRGBColorSpace;
  numTexCache.set(key, t);
  return t;
}

// ------------------------------------------------------------ pose
export interface Pose {
  legLx: number; legRx: number; legLz: number; legRz: number; kneeL: number; kneeR: number;
  armLx: number; armRx: number; armLz: number; armRz: number; elbowL: number; elbowR: number;
  lean: number; roll: number; bodyY: number; bodyRotX: number; twist: number; headX: number;
}
export const newPose = (): Pose => ({
  legLx: 0, legRx: 0, legLz: 0, legRz: 0, kneeL: 0, kneeR: 0, armLx: 0, armRx: 0, armLz: 0.1, armRz: -0.1,
  elbowL: -0.2, elbowR: -0.2, lean: 0, roll: 0, bodyY: 0.95, bodyRotX: 0, twist: 0, headX: 0,
});
const POSE_KEYS = Object.keys(newPose()) as (keyof Pose)[];

export interface PlayerRig {
  root: Group;
  body: Group;
  torso: Group;
  head: Group;
  legL: Group; legR: Group; shinL: Group; shinR: Group;
  armL: Group; armR: Group; foreL: Group; foreR: Group;
  cur: Pose;
  target: Pose;
  geos: BufferGeometry[];
  mats: { dispose(): void }[];
  kitKey: string;
}

function hairGeometries(hair: number, color: string): BufferGeometry[] {
  const c = color;
  switch (hair) {
    case 0:
      return [
        part(BASE.hairCap, c, 0, 0.014, -0.008, 1.0, 1.08, 1.05, -0.3),
        part(BASE.box, c, 0.104, -0.012, -0.006, 0.026, 0.062, 0.085),
        part(BASE.box, c, -0.104, -0.012, -0.006, 0.026, 0.062, 0.085),
        part(BASE.sphere, c, 0, -0.062, -0.108, 0.075, 0.05, 0.05),
      ];
    case 1:
      return [part(BASE.hairCap, c, 0, 0.006, -0.004, 0.95, 1.0, 0.98, -0.22)];
    case 2:
      return [
        part(BASE.hairCap, c, 0, 0.018, -0.016, 1.02, 1.12, 1.06, -0.34),
        part(BASE.hairMass, c, 0, -0.06, -0.11, 1.02, 1.18, 0.86),
        part(BASE.box, c, 0.107, -0.03, -0.03, 0.03, 0.16, 0.1),
        part(BASE.box, c, -0.107, -0.03, -0.03, 0.03, 0.16, 0.1),
      ];
    case 3:
      return [
        part(BASE.hairCap, shade(c, 0.75), 0, -0.004, 0, 0.9, 0.88, 0.9, -0.1),
        part(BASE.box, c, 0, 0.128, -0.014, 0.05, 0.11, 0.26),
        part(BASE.box, c, 0, 0.075, -0.126, 0.055, 0.05, 0.05),
      ];
    case 4:
      return [part(BASE.hairMass, c, 0, 0.052, -0.05, 1.06, 1.02, 1.02)];
    default:
      return [];
  }
}

export function createPlayerModel(kit: KitSpec): PlayerRig {
  const geos: BufferGeometry[] = [];
  const mats: { dispose(): void }[] = [];
  const mk = (parts: BufferGeometry[]) => {
    const g = merge(parts);
    geos.push(g);
    return g;
  };
  const lm = limbMat();
  const mesh = (g: BufferGeometry, parent: Group, material: Mat = lm, x = 0, y = 0, z = 0) => {
    const m = new Mesh(g, material);
    m.position.set(x, y, z);
    m.castShadow = true;
    parent.add(m);
    return m;
  };
  const sil = !!kit.silhouette;
  // Silhouette (menu background) players must stay a flat dark colour, so skip shading.
  const AO = (base: string, depth: number) => (sil ? undefined : ao(base, depth));
  const pfn = sil ? undefined : kit.pattern === 1
    ? (x: number) => (Math.floor((x + 0.25) / 0.062) % 2 ? kit.secondary : kit.primary)
    : kit.pattern === 2
      ? (_x: number, y: number) => (Math.floor((y + 0.1) / 0.085) % 2 ? kit.secondary : kit.primary)
      : kit.pattern === 3
        ? (x: number, y: number) => (Math.abs(x + (y - 0.3) * 0.85) < 0.062 ? kit.secondary : kit.primary)
        : kit.pattern === 4 ? (x: number) => (x > 0.004 ? kit.secondary : kit.primary) : undefined;

  const root = new Group();
  root.scale.setScalar(PLAYER_SCALE);
  const body = new Group();
  body.rotation.order = 'ZXY';
  root.add(body);
  const torso = new Group();
  body.add(torso);

  // ---------------- torso
  const jerseyMat = sil ? SIL_MAT : new MeshLambertMaterial({ map: jerseyTexture(kit.primary, kit.secondary, kit.pattern ?? 0), vertexColors: true });
  if (!sil) mats.push(jerseyMat);
  // The shirt surface carries the kit texture. Shorts, collar and neck stay vertex
  // coloured in a second mesh so they never sample the jersey pattern.
  const torsoGeo = mk([
    part(BASE.chest, '#ffffff', 0, 0.34, 0, 1.28, 1.0, 0.78),
    part(BASE.shoulder, '#ffffff', 0.235, 0.46, 0, 1, 1, 0.9),
    part(BASE.shoulder, '#ffffff', -0.235, 0.46, 0, 1, 1, 0.9),
    part(BASE.abdomen, '#ffffff', 0, 0.16, 0, 1.06, 1, 0.74),
  ]);
  mesh(torsoGeo, torso, jerseyMat);
  const detailGeo = mk([
    part(BASE.hips, sil ? '#0b0f16' : kit.shorts, 0, 0, 0, 1.02, 1, 0.8),
    part(BASE.neck, sil ? '#0b0f16' : kit.skin, 0, 0.6, 0, 1.0, 2.2, 1.0),
    part(BASE.collar, sil ? '#0b0f16' : kit.secondary, 0, 0.632, 0, 1, 1, 1, 0, 0, 0, AO(kit.secondary, 0.15)),
    part(BASE.box, sil ? '#0b0f16' : kit.secondary, 0.085, 0.47, 0.115, 0.052, 0.062, 0.014),
    part(BASE.box, sil ? '#0b0f16' : kit.secondary, 0.17, 0.5, 0, 0.07, 0.03, 0.2),
    part(BASE.box, sil ? '#0b0f16' : kit.secondary, -0.17, 0.5, 0, 0.07, 0.03, 0.2),
  ]);
  mesh(detailGeo, torso, lm);

  // ---------------- head with painted face
  const head = new Group();
  head.position.set(0, 0.77, 0);
  torso.add(head);
  const faceMat = sil ? SIL_MAT : new MeshLambertMaterial({ map: faceTexture(kit.skin, kit.seed ?? 1) });
  if (!sil) mats.push(faceMat);
  const headGeo = mk([
    part(BASE.skull, sil ? '#0b0f16' : '#ffffff', 0, 0, 0, 0.94, 1.06, 1.0),
  ]);
  mesh(headGeo, head, faceMat);
  // Facial geometry keeps the plain skin material – it must not sample the face texture.
  const faceGeo = mk([
    part(BASE.jaw, sil ? '#0b0f16' : kit.skin, 0, -0.08, 0.022, 0.95, 0.82, 1.0, 0, 0, 0, AO(kit.skin, 0.12)),
    part(BASE.cheek, sil ? '#0b0f16' : kit.skin, 0.052, -0.045, 0.086, 1, 0.85, 0.9),
    part(BASE.cheek, sil ? '#0b0f16' : kit.skin, -0.052, -0.045, 0.086, 1, 0.85, 0.9),
    part(BASE.nose, sil ? '#0b0f16' : shade(kit.skin, 0.96), 0, -0.028, 0.11, 1, 1.15, 1.25, Math.PI / 2.2),
    part(BASE.ear, sil ? '#0b0f16' : shade(kit.skin, 0.86), 0.112, -0.004, -0.004),
    part(BASE.ear, sil ? '#0b0f16' : shade(kit.skin, 0.86), -0.112, -0.004, -0.004),
    part(BASE.neck, sil ? '#0b0f16' : kit.skin, 0, -0.13, -0.01, 1, 0.8, 1),
  ]);
  mesh(faceGeo, head, lm);
  if (!sil) {
    const hair = hairGeometries(kit.hair, kit.hairColor);
    if (hair.length) mesh(mk(hair), head, lm);
  }

  // ---------------- arms
  const gloves = sil ? '#0b0f16' : kit.gloves ?? kit.skin;
  const makeArm = (side: 1 | -1) => {
    const arm = new Group();
    arm.position.set(side * 0.245, 0.5, 0);
    torso.add(arm);
    mesh(
      mk([
        part(BASE.upperArm, sil ? '#0b0f16' : kit.skin, 0, -0.15, 0, 1, 0.98, 1, 0, 0, 0, AO(kit.skin, 0.1)),
        part(BASE.sleeve, sil ? '#0b0f16' : kit.primary, 0, -0.05, 0, 1.12, 1.1, 1.12, 0, 0, 0, pfn),
        part(BASE.sleeve, sil ? '#0b0f16' : kit.secondary, 0, -0.09, 0, 1.15, 0.3, 1.15),
      ]),
      arm,
      lm,
    );
    const fore = new Group();
    fore.position.set(0, -0.3, 0);
    arm.add(fore);
    mesh(
      mk([
        part(BASE.foreArm, sil ? '#0b0f16' : kit.skin, 0, -0.13, 0, 1, 0.98, 1, 0, 0, 0, AO(kit.skin, 0.12)),
        part(BASE.hand, gloves, 0, -0.29, 0, 1, 1.1, 0.85),
      ]),
      fore,
      lm,
    );
    return { arm, fore };
  };
  const aL = makeArm(1);
  const aR = makeArm(-1);

  // ---------------- legs
  const makeLeg = (side: 1 | -1) => {
    const leg = new Group();
    leg.position.set(side * 0.105, 0.03, 0);
    body.add(leg);
    mesh(
      mk([
        part(BASE.thigh, sil ? '#0b0f16' : kit.skin, 0, -0.26, 0, 1, 0.98, 1, 0, 0, 0, AO(kit.skin, 0.14)),
        part(BASE.knee, sil ? '#0b0f16' : kit.skin, 0, -0.44, 0.004, 1, 0.95, 1),
      ]),
      leg,
      lm,
    );
    const shin = new Group();
    shin.position.set(0, -0.44, 0);
    leg.add(shin);
    mesh(
      mk([
        part(BASE.calf, sil ? '#0b0f16' : kit.skin, 0, -0.1, -0.03, 1, 1, 1, 0, 0, 0, AO(kit.skin, 0.16)),
        part(BASE.shin, sil ? '#0b0f16' : kit.socks, 0, -0.26, 0, 1, 0.98, 1, 0, 0, 0, AO(kit.socks, 0.16)),
        part(BASE.sockFold, sil ? '#0b0f16' : kit.secondary, 0, 0.02, 0),
        part(BASE.ankle, sil ? '#0b0f16' : kit.socks, 0, -0.38, 0),
        part(BASE.boot, sil ? '#0b0f16' : kit.boots, 0, -0.45, 0.045, 1.05, 1, 1.15),
        part(BASE.toe, sil ? '#0b0f16' : kit.boots, 0, -0.47, 0.15, 1, 0.92, 1),
        part(BASE.box, sil ? '#0b0f16' : shade(kit.boots, 0.6), 0, -0.45, 0.13, 0.05, 0.02, 0.05),
        part(BASE.sole, sil ? '#0b0f16' : '#eceff4', 0, -0.49, 0.06),
        part(BASE.stud, sil ? '#0b0f16' : '#eceff4', 0.035, -0.52, 0.13, 1, 1, 1, Math.PI),
        part(BASE.stud, sil ? '#0b0f16' : '#eceff4', -0.035, -0.52, 0.13, 1, 1, 1, Math.PI),
      ]),
      shin,
      lm,
    );
    return { leg, shin };
  };
  const lL = makeLeg(1);
  const lR = makeLeg(-1);

  // ---------------- shirt numbers
  if (!sil) {
    const key = `${kit.number}|${kit.secondary}`;
    let nm = numMatCache.get(key);
    if (!nm) {
      nm = new MeshBasicMaterial({ map: numberTexture(kit.number, kit.secondary), transparent: true, depthWrite: false });
      numMatCache.set(key, nm);
    }
    const back = new Mesh(new PlaneGeometry(0.24, 0.24), nm);
    back.position.set(0, 0.35, -0.145);
    back.rotation.y = Math.PI;
    torso.add(back);
    const front = new Mesh(new PlaneGeometry(0.15, 0.15), nm);
    front.position.set(0.02, 0.29, 0.142);
    torso.add(front);
  }

  return {
    root, body, torso, head,
    legL: lL.leg, legR: lR.leg, shinL: lL.shin, shinR: lR.shin,
    armL: aL.arm, armR: aR.arm, foreL: aL.fore, foreR: aR.fore,
    cur: newPose(), target: newPose(), geos, mats,
    kitKey: `${kit.primary}${kit.number}`,
  };
}

export function disposeRig(r: PlayerRig) {
  r.geos.forEach((g) => g.dispose());
  r.mats.forEach((m) => m.dispose());
  r.root.removeFromParent();
}

export function applyPose(r: PlayerRig, dt: number, rate = 16) {
  const k = 1 - Math.exp(-rate * dt);
  const c = r.cur;
  const t = r.target;
  for (const key of POSE_KEYS) c[key] += (t[key] - c[key]) * k;
  r.body.position.y = c.bodyY;
  r.body.rotation.x = c.bodyRotX + c.lean;
  r.body.rotation.z = c.roll;
  r.torso.rotation.y = c.twist;
  r.head.rotation.x = c.headX - c.lean * 0.6;
  r.legL.rotation.x = c.legLx;
  r.legR.rotation.x = c.legRx;
  r.legL.rotation.z = c.legLz;
  r.legR.rotation.z = c.legRz;
  r.shinL.rotation.x = c.kneeL;
  r.shinR.rotation.x = c.kneeR;
  r.armL.rotation.x = c.armLx;
  r.armR.rotation.x = c.armRx;
  r.armL.rotation.z = c.armLz;
  r.armR.rotation.z = c.armRz;
  r.foreL.rotation.x = c.elbowL;
  r.foreR.rotation.x = c.elbowR;
}

// ------------------------------------------------------------ ball
export function createBallMesh(radius: number): Mesh {
  const geo = new IcosahedronGeometry(radius, 2);
  const pos = geo.attributes.position;
  const n = pos.count;
  const colors = new Float32Array(n * 3);
  const phi = (1 + Math.sqrt(5)) / 2;
  // dodecahedron face centres → pentagon panels
  const verts: Vector3[] = [];
  for (const a of [-1, 1]) for (const b of [-phi, phi]) {
    verts.push(new Vector3(0, a, b).normalize(), new Vector3(a, b, 0).normalize(), new Vector3(b, 0, a).normalize());
  }
  const c = new Vector3();
  const tri = new Vector3();
  const dark = new Color('#171b24');
  const white = new Color('#f6f7f9');
  const accent = new Color('#d5dd75');
  for (let i = 0; i < n; i += 3) {
    c.set(0, 0, 0);
    for (let j = 0; j < 3; j++) c.add(tri.set(pos.getX(i + j), pos.getY(i + j), pos.getZ(i + j)));
    c.normalize();
    let best = -1;
    for (const v of verts) best = Math.max(best, c.dot(v));
    const col = best > 0.93 ? dark : best > 0.86 ? accent : white;
    for (let j = 0; j < 3; j++) {
      colors[(i + j) * 3] = col.r;
      colors[(i + j) * 3 + 1] = col.g;
      colors[(i + j) * 3 + 2] = col.b;
    }
  }
  geo.setAttribute('color', new BufferAttribute(colors, 3));
  const m = new Mesh(geo, new MeshStandardMaterial({ vertexColors: true, roughness: 0.42, metalness: 0.05, flatShading: true }));
  m.castShadow = true;
  return m;
}

// ------------------------------------------------------------ blob shadow
let blobTex: CanvasTexture | null = null;
export function blobShadowTexture(): CanvasTexture {
  if (blobTex) return blobTex;
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const x = c.getContext('2d')!;
  const g = x.createRadialGradient(32, 32, 2, 32, 32, 30);
  g.addColorStop(0, 'rgba(0,0,0,0.55)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  x.fillStyle = g;
  x.fillRect(0, 0, 64, 64);
  blobTex = new CanvasTexture(c);
  return blobTex;
}
const BLOB_GEO = new PlaneGeometry(1, 1).rotateX(-Math.PI / 2);
let blobMat: MeshBasicMaterial | null = null;
export function createBlobShadow(size: number): Mesh {
  if (!blobMat) blobMat = new MeshBasicMaterial({ map: blobShadowTexture(), transparent: true, depthWrite: false });
  const m = new Mesh(BLOB_GEO, blobMat);
  m.scale.set(size, 1, size);
  m.position.y = 0.02;
  m.renderOrder = 1;
  m.userData.shared = true; // geometry & material are module-level – never dispose per match
  return m;
}

// ------------------------------------------------------------ kit helpers
export const hairColorFor = (i: number) => HAIR_COLORS[i % HAIR_COLORS.length];

function lum(hex: string) {
  const c = new Color(hex);
  return 0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b;
}
export function contrastColor(hex: string) {
  return lum(hex) > 0.35 ? '#12151c' : '#f6f7fb';
}
const GK_COLORS = ['#ffe81f', '#2bf08a', '#ff7a1a', '#c04dff', '#19c7ff'];
export function gkColor(avoid: string[]): string {
  const ac = avoid.map((a) => new Color(a));
  let best = GK_COLORS[0];
  let bestD = -1;
  for (const g of GK_COLORS) {
    const gc = new Color(g);
    const d = Math.min(...ac.map((a) => Math.abs(a.r - gc.r) + Math.abs(a.g - gc.g) + Math.abs(a.b - gc.b)));
    if (d > bestD) {
      bestD = d;
      best = g;
    }
  }
  return best;
}
