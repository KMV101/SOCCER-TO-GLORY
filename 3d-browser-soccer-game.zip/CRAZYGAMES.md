# SideNet – CrazyGames deployment guide

## Build & upload
1. `npm run build` – produces **`dist/index.html`** plus the local `dist/images/` folder. JS and CSS are inlined; fonts are bundled; the menu photo is a local relative asset.
2. Zip the **contents** of `dist/` so `index.html` is at the root and keep `images/sidenet-matchday.jpg` at its generated relative path, then upload as an *HTML5* game at https://developer.crazygames.com.
3. The build is about 1.48 MB plus the ~111 KB menu image (about 1.59 MB total, well below the 20 MB mobile homepage limit).

## Game modes (for the listing)
Quick Match (clubs & nations, 1v1–5v5) · **Street Soccer** (caged court, no keepers, bouncy walls, first to N goals) · **National League** (8 clubs, round robin table) · **International Cup** (8 nations, groups → semis → final) · Knockout Cup · **Free Kick Challenge** (curve it over the wall) · Penalty Shootout · Training.
Camera presets: Broadcast (side-on TV view, default), Behind, Close, Wide. Skill moves on **C**. In a match, both laptop and mobile players see an on-screen directional pad, action buttons and selectable strike styles. The same pointer controls also cover penalty taking, goalkeeping dives and free-kick aim/curve. Keyboard, mouse and gamepad remain available at the same time.

## Interface direction
The UI is SideNet's own matchday editorial system, not a recreation of another game's UI. We reviewed the CrazyGames pages for [Soccer Bros](https://www.crazygames.com/game/soccer-bros), [Soccer Legends 2026](https://www.crazygames.com/game/soccer-legends-2021), [Free Kick Classic](https://www.crazygames.com/game/free-kick-classic), and [RocketGoal.io](https://www.crazygames.com/game/rocketgoal-io). The practical lessons were one-step entry to play, a visible choice of match format, clear mode-specific controls, and a score that can be read at a glance. SideNet expresses those lessons through one full-bleed matchday image, one Kick Off action, a browseable modes drawer, team-selection rows and a quiet broadcast HUD. No artwork or interface assets were copied from those games.

## SDK integration (already done – `src/game/crazy.ts`)
| Requirement | Where |
|---|---|
| SDK v3 script loaded at runtime, `SDK.init()` with timeout + graceful fallback (game runs without it) | `crazy.init()` |
| `loadingStart` / `loadingStop` | `App.tsx` mount / `crazy.init()` |
| `gameplayStart` / `gameplayStop` – only while a match, penalty or training is actually running (not menus, pause, results) | `App.tsx` effect |
| `muteAudio` setting + listener (takes priority over in-game volume) | `audio.setExternalMute` |
| Midgame ads – only between matches (result screen buttons) | `afterAd()` in `App.tsx` |
| Rewarded ad – "Watch ad · +coins" button on the result screen (only visible on CrazyGames) | `ResultScreen` |
| `happytime()` – on victories | `finish()` in `App.tsx` |
| Game pauses (without reporting gameplayStop) when focus is lost | `App.tsx` blur handler |

Test locally with `?` URL params from the CrazyGames docs (e.g. `?muteAudio=true`) or via the CrazyGames QA tool.

## Technical checklist
- ✅ HTML5 / WebGL (three.js), keyboard + mouse + gamepad
- ✅ Only relative / inlined assets
- ✅ Works inside an iframe; `localStorage` failure falls back to in-memory progress
- ✅ Space / arrow keys / right-click do not scroll or open menus
- ✅ Audio starts only after the first user interaction; fully procedural (no copyrighted assets)
- ✅ Original teams, crests, kits and players – no real-world IP
- ✅ Adaptive quality: if the frame rate stays far below target for ~5 s the graphics preset is lowered automatically
- ✅ Quality presets (Low / Medium / High), 75 % / 100 % resolution scale, 30 / 60 FPS cap

## Store assets you still need to upload in the dashboard
CrazyGames requires cover images, which are submitted separately from the build:
- 16:9 – 1920×1080
- 2:3 – 800×1200
- 1:1 – 800×800
Use screenshots of the stadium + the SIDENET wordmark (see `Logo` in `src/ui/common.tsx`). The menu key art is `public/images/sidenet-matchday.jpg` and is included in the build.

## Suggested listing text
**SideNet** – small-sided football after dark. Pick a side, take a quick match, play cage football, work through a local league or cup, and try to bend a free kick around the wall.

Controls: WASD move (screen-relative in Broadcast camera) · Shift sprint · Hold and release left mouse to strike (clean-contact charge window is highlighted) · F + strike to bend · V + strike for a planted heavy hit · R + strike to chip · X + strike to keep it low · Q pass · Q while charging a strike to cancel with a feint · Right mouse through ball · E tackle · C skill move · Space switch player · Esc pause. Gamepad: left stick move, A pass, B strike, X tackle, Y through, LB switch, RB sprint, LB+RB+B heavy hit, LT+B bending hit.

Pointer controls: hold a direction in the left pad; diagonals work with multi-touch. Select Normal / Bend / Drive / Chip / Low above the right-side actions, then hold and release Strike. Pass, Through, Skill, Tackle, Slide, Switch and Sprint are separate buttons. Training has Reset Ball. Penalties show Aim + Hold to Strike or four directional keeper dives and Stay Centre. Free kicks show Aim, Curve Left, Curve Right, Hold to Strike. Controls are hidden while play is frozen (kickoff, goal, half-time and full-time); the pause and second-half buttons remain available. Short clicks are captured even if they begin and end between animation frames.

## Visuals and manual QA

The game uses original low-poly, articulated footballers, a procedurally textured pitch, instanced supporters, animated flags, a few sideline coaches and reserves, and a small scoreboard texture that changes only when its displayed values change. LOW disables cast shadows and simplifies the crowd. These are deliberate constraints for integrated graphics; this is not an EA SPORTS FC port and does not include its assets, licensed likenesses, branded UI, or full simulation rulebook.

Before submitting, **play-test** on Chrome and Edge at desktop, Chromebook, phone and tablet sizes. Verify: desktop mouse clicking every match button and the d-pad; mobile multi-touch diagonals while holding Strike, Pass and Sprint; tap-versus-hold for Strike and Pass at 30 and 60 FPS; the Normal/Bend/Drive/Chip/Low selectors; Switch hidden in 1v1; Slide and Reset Ball; penalty keeper high/low/centre dives and their one-dive limit; free-kick aim and both curve buttons; pausing mid-charge without firing a shot on resume; focus loss; a full match through half-time and full-time; a high cross being headed; throw-ins and corners restarting; a goal celebration and return to kickoff; the score and clock on the stadium screen; controller pause and resume; and LOW/MEDIUM/HIGH quality. Confirm SDK gameplay events and optional ads in CrazyGames' QA tool. A successful build alone does not verify these runtime cases.
